translate italian strings:
# Files Created By OneClick HERMES 4.2

    old "# Math nerds might realize I'm not offsetting the transform."
    new "# Gli appassionati di matematica potrebbero rendersi conto che non sto compensando la trasformazione."

    old "# Rotations on x axis"
    new "# Rotazioni sull'asse x"

    old "# Template tag function to copy off of."
    new "# Funzione tag modello da cui copiare."

    old "# The real place to apply the offset is in your final blit. Which is what we'll calculate here"
    new "# Il vero punto in cui applicare l'offset è nel blit finale. Questo è ciò che calcoleremo qui"

    old "# This applies the rotation to our child's render."
    new "# Questo applica la rotazione al rendering di nostro figlio."

    old "# Try moving it around and seeing what happens."
    new "# Prova a spostarlo e a vedere cosa succede."

    old "# Which parameter you put the 'angle' into will affect which axis the render rotates on."
    new "# Il parametro in cui inserisci l''angolo' influenzerà l'asse su cui ruota il rendering."

    old "## Setup"
    new "## Impostare"

    old "3D art: Eón\n"
    new "Arte 3D: Eón\n"

    old "Designs: Eón, Dakno\n"
    new "Disegni: Eón, Dakno\n"

    old "False Hope"
    new "Falsa speranza"

    old "Français"
    new "Francese"

    old "{a=https://discord.com/invite/XuZHYQxVd3}{color=#ff81d5}DISCORD{/color}{/a}"
    new "{a=https://discord.com/invite/XuZHYQxVd3}{color=#ff81d5}DISCORD{/color}{/a}"

    old "{a=https://store.steampowered.com/app/4058160/Fiction_Paradox__Chapter_1/}{color=#ff81d5}STEAM{/color}{/a}  /  {a=https://saikeystudios.com/product/fiction-paradox-chapter-1/}{color=#ff81d5}SAIKEY{/color}{/a}{#end-of-release-0.1}"
    new "{a=https://store.steampowered.com/app/4058160/Fiction_Paradox__Chapter_1/}{color=#ff81d5}VAPORE{/color}{/a} / {a=https://saikeystudios.com/product/fiction-paradox-chapter-1/}{color=#ff81d5}SAIKEY{/color}{/a}{#end-of-release-0.1}"

    old "{a=https://subscribestar.adult/naventu}{color=#ff81d5}SUBSCRIBESTAR{/color}{/a}\n"
    new "{a=https://subscribestar.adult/naventu}{color=#ff81d5}ISCRIVITISTAR{/color}{/a}\n"

    old "{a=https://www.patreon.com/naventu}{color=#ff81d5}PATREON{/color}{/a}  /  {a=https://subscribestar.adult/naventu}{color=#ff81d5}SUBSCRIBESTAR{/color}{/a}"
    new "{a=https://www.patreon.com/naventu}{color=#ff81d5}PATREON{/color}{/a} / {a=https://subscribestar.adult/naventu}{color=#ff81d5}ISCRIVITISTAR{/color}{/a}"

# Created By Bad75 Renpy Translate 2026