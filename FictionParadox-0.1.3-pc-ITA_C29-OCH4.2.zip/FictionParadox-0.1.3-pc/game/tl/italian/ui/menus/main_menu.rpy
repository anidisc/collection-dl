﻿
translate italian strings:

    # game/ui/menus/main_menu.rpy:145
    old "???{#main-menu}"
    new "???{#main-menu}"

    # game/ui/menus/main_menu.rpy:150
    old "{alpha=*0.5}Universe [current_universe_slot.number]{/alpha}{#title-screen}"
    new "{alpha=*0.5}Universo [current_universe_slot.number]{/alpha}{#title-screen}"

    # game/ui/menus/main_menu.rpy:155
    old "Universe [current_universe_slot.number]{#title-screen}"
    new "Universo [current_universe_slot.number]{#title-screen}"

    # game/ui/menus/main_menu.rpy:203
    old "CONTINUE{#title-screen}"
    new "CONTINUA{#title-screen}"

    # game/ui/menus/main_menu.rpy:211
    old "START{#title-screen}"
    new "INIZIO{#title-screen}"

    # game/ui/menus/main_menu.rpy:306
    old "Written by Dakno{#title-screen}"
    new "Scritto da Dakno{#title-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
