﻿
translate italian strings:

    # game/ui/menus/game_menu.rpy:52
    old "CONTINUE{#ingame-menu}"
    new "CONTINUA{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:56
    old "END REPLAY{#ingame-menu}"
    new "FINE RIPETIZIONE{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:59
    old "SAVE{#ingame-menu}"
    new "SALVA{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:63
    old "LOAD{#ingame-menu}"
    new "CARICA{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:67
    old "PREFERENCES{#ingame-menu}"
    new "PREFERENZE{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:71
    old "MAIN MENU{#ingame-menu}"
    new "MENÙ PRINCIPALE{#ingame-menu}"

    # game/ui/menus/game_menu.rpy:76
    old "QUIT GAME{#ingame-menu}"
    new "ESCI DAL GIOCO{#ingame-menu}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
