﻿
translate italian strings:

    # game/ui/menus/language_preferences.rpy:12
    old "Language{#preferences-screen}"
    new "Lingua{#preferences-screen}"

    # game/ui/menus/language_preferences.rpy:27
    old "Game title{#preferences-screen}"
    new "Titolo del gioco{#preferences-screen}"

    # game/ui/menus/language_preferences.rpy:30
    old "Fiction Paradox- ITA_Cep29 OneClick ULTIMATE{#game-title}"
    new "Paradosso della narrativa- ITA_Cep29 OneClick ULTIMATE{#game-title}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/menus/language_preferences.rpy:29
    old "Fiction Paradox{#game-title}"
    new "Paradosso della narrativa{#game-title}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
