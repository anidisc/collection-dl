﻿
translate italian strings:

    # game/ui/menus/load_save.rpy:153
    old "SAVE GAME{#load-screen}"
    new "SALVA PARTITA{#load-screen}"

    # game/ui/menus/load_save.rpy:158
    old "LOAD GAME{#load-screen}"
    new "CARICA GIOCO{#load-screen}"

    # game/ui/menus/load_save.rpy:425
    old "BACK TO GAME{#load-screen}"
    new "TORNA AL GIOCO{#load-screen}"

    # game/ui/menus/load_save.rpy:432
    old "CHANGE UNIVERSE{#load-screen}"
    new "CAMBIA UNIVERSO{#load-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
