﻿
translate italian strings:

    # game/ui/menus/support_us.rpy:36
    old "You can support the game in:{#support-screen}"
    new "Puoi supportare il gioco in:{#support-screen}"

    # game/ui/menus/support_us.rpy:38
    old "Join our Discord!{#support-screen}"
    new "Unisciti al nostro Discord!{#support-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
