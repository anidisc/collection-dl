﻿
translate italian strings:

    # game/ui/menus/splashscreen.rpy:2
    old "All the characters in the story are fictional and over the age of 18. Any resemblance to real life people or events is entirely coincidental.\n\nThis game contains explicit depictions of nudity, sex, violence and sensitive topics. By selecting CONTINUE, you certify that you meet the legal age of your jurisdiction to consume this kind of material.\n\n"
    new "Tutti i personaggi della storia sono immaginari e hanno più di 18 anni. Qualsiasi somiglianza con persone o eventi della vita reale è del tutto casuale.\n\nQuesto gioco contiene rappresentazioni esplicite di nudità, sesso, violenza e argomenti delicati. Selezionando CONTINUA, dichiari di soddisfare l'età legale prevista dalla tua giurisdizione per consumare questo tipo di materiale.\n\n"

    # game/ui/menus/splashscreen.rpy:74
    old "Which title do you prefer for the game?{#splashscreen}"
    new "Quale titolo preferisci per il gioco?{#splashscreen}"

    # game/ui/menus/splashscreen.rpy:76
    old "(you can change it in Preferences){#splashscreen}"
    new "(puoi modificarlo in Preferenze){#splashscreen}"

    # game/ui/menus/splashscreen.rpy:82
    old "Original (Fiction Paradox){#splashscreen}"
    new "Originale (Paradosso della narrativa){#splashscreen}"

    # game/ui/menus/splashscreen.rpy:88
    old "Translated (Fiction Paradox){#splashscreen}"
    new "Tradotto (Paradosso della narrativa){#splashscreen}"

    # game/ui/menus/splashscreen.rpy:148
    old "CONTINUE{#splashscreen}"
    new "CONTINUA{#splashscreen}"

    # game/ui/menus/splashscreen.rpy:151
    old "EXIT GAME{#splashscreen}"
    new "ESCI DAL GIOCO{#splashscreen}"

    # game/ui/menus/splashscreen.rpy:160
    old "Don't show this screen again.{#splashscreen}"
    new "Non mostrare più questa schermata.{#splashscreen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/menus/splashscreen.rpy:101
    old "ORIGINAL{#splashscreen-title-logo}"
    new "ORIGINALE{#splashscreen-title-logo}"

    # game/ui/menus/splashscreen.rpy:110
    old "TRANSLATED{#splashscreen-title-logo}"
    new "TRADOTTO{#splashscreen-title-logo}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
