﻿
translate italian strings:

    # game/ui/menus/delete_universe.rpy:65
    old "DELETE UNIVERSE{#delete-universe-screen}"
    new "ELIMINA UNIVERSO{#delete-universe-screen}"

    # game/ui/menus/delete_universe.rpy:114
    old "PAGE [universe_current_page_number]"
    new "PAGINA [universe_current_page_number]"

    # game/ui/menus/delete_universe.rpy:147
    old "Are you sure you want to delete this universe?\nYou will lose ALL your saves!{#delete-universe-screen}"
    new "Vuoi eliminare questo universo?\nPerderai TUTTI i tuoi salvataggi!{#delete-universe-screen}"

    # game/ui/menus/delete_universe.rpy:198
    old "???{#load-screen}"
    new "???{#load-screen}"

    # game/ui/menus/delete_universe.rpy:225
    old "Woman{#load-screen}"
    new "Donna{#load-screen}"

    # game/ui/menus/delete_universe.rpy:228
    old "Man{#load-screen}"
    new "Uomo{#load-screen}"

    # game/ui/menus/delete_universe.rpy:233
    old "Lesbian{#load-screen}"
    new "Lesbiche{#load-screen}"

    # game/ui/menus/delete_universe.rpy:236
    old "Straight{#male}{#load-screen}"
    new "Dritto{#male}{#load-screen}"

    # game/ui/menus/delete_universe.rpy:239
    old "Straight{#female}{#load-screen}"
    new "Dritto{#female}{#load-screen}"

    # game/ui/menus/delete_universe.rpy:242
    old "Gay{#load-screen}"
    new "Gay{#load-screen}"

    # game/ui/menus/delete_universe.rpy:246
    old "Includes explicit content{#load-screen}"
    new "Include contenuti espliciti{#load-screen}"

    # game/ui/menus/delete_universe.rpy:251
    old "Game mode{#load-screen}"
    new "Modalità gioco{#load-screen}"

    # game/ui/menus/delete_universe.rpy:254
    old "Novel mode{#load-screen}"
    new "Modalità romanzo{#load-screen}"

    # game/ui/menus/delete_universe.rpy:275
    old "BACK{#delete-universe-screen}"
    new "INDIETRO{#delete-universe-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
