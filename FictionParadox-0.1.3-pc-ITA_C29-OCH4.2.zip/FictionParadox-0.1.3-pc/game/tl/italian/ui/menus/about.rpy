﻿
translate italian strings:

    # game/ui/menus/about.rpy:4
    old "Direction: Dakno\n\nWriting: Dakno\n\n3D art: Eón, Lumen\n\n3D animations: Lumen\n\nDesigns: Eón, Lumen, Dakno\n\nProgramming: Dakno"
    new "Direzione: Dakno\n\nScrittura: Dakno\n\nArte 3D: Eón, Lumen\n\nAnimazioni 3D: Lumen\n\nDisegni: Eón, Lumen, Dakno\n\nProgrammazione: Dakno"

    # game/ui/menus/about.rpy:41
    old "Fiction Paradox{#translated}{#credits}"
    new "Paradosso della narrativa{#translated}{#credits}"

    # game/ui/menus/about.rpy:46
    old "Version [config.version!t]\n\n{#credits-screen}"
    new "Versione [config.version!t]\n\n{#credits-screen}"

    # game/ui/menus/about.rpy:55
    old "Developed by Naventu{#credits-screen}"
    new "Sviluppato da Naventu{#credits-screen}"

    # game/ui/menus/about.rpy:57
    old "OST by Koko Nomad\n\n\n{#credits-screen}"
    new "OST di Koko Nomad\n\n\n{#credits-screen}"

    # game/ui/menus/about.rpy:59
    old "{size=28}Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]{/size}{#credits-screen}"
    new "{size=28}Realizzato con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]{/size}{#credits-screen}"

    # game/ui/menus/about.rpy:62
    old "Some visual and audio elements in this project were sourced from royalty-free or public-domain materials.\n{#credits-screen}"
    new "Alcuni elementi visivi e audio di questo progetto provengono da materiali esenti da royalty o di pubblico dominio.\n{#credits-screen}"

    # game/ui/menus/about.rpy:63
    old "All other content, including the soundtrack, story, and art, was created exclusively for Fiction Paradox.{#credits-screen}"
    new "Tutti gli altri contenuti, inclusa la colonna sonora, la storia e la grafica, sono stati creati esclusivamente per Fiction Paradox.{#credits-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/menus/about.rpy:4
    old "Direction: Dakno\n\nWriting: Dakno\n\n3D art: Eón\n\nDesigns: Eón, Dakno\n\nProgramming: Dakno"
    new "Direzione: Dakno\n\nScrittura: Dakno\n\n3D art: Eón\n\nDisegni: Eón, Dakno\n\nProgrammazione: Dakno"

    # game/ui/menus/about.rpy:70
    old "OST by Nela Ruiz\n{#credits-screen}"
    new "OST di Nela Ruiz\n{#credits-screen}"

    # game/ui/menus/about.rpy:71
    old "Thanks to Lumen for the first animations (Chapter 1) and some UI designs.\n{#credits-screen}"
    new "Grazie a Lumen per le prime animazioni (Capitolo 1) e alcuni progetti di interfaccia utente.\n{#credits-screen}"

    # game/ui/menus/about.rpy:74
    old "{size=*0.9}Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]{/size}{#credits-screen}"
    new "{size=*0.9}Realizzato con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]{/size}{#credits-screen}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
