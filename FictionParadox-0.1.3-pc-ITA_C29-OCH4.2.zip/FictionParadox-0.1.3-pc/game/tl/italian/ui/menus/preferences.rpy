﻿
translate italian strings:

    # game/ui/menus/preferences.rpy:23
    old "Skip{#preferences-screen}"
    new "Salta{#preferences-screen}"

    # game/ui/menus/preferences.rpy:24
    old "Unseen dialogues{#preferences-screen}"
    new "Dialoghi invisibili{#preferences-screen}"

    # game/ui/menus/preferences.rpy:26
    old "After choices{#preferences-screen}"
    new "Dopo le scelte{#preferences-screen}"

    # game/ui/menus/preferences.rpy:28
    old "Transitions{#preferences-screen}"
    new "Transizioni{#preferences-screen}"

    # game/ui/menus/preferences.rpy:39
    old "Display{#preferences-screen}"
    new "Visualizza{#preferences-screen}"

    # game/ui/menus/preferences.rpy:40
    old "Window{#preferences-screen}"
    new "Finestra{#preferences-screen}"

    # game/ui/menus/preferences.rpy:42
    old "Fullscreen{#preferences-screen}"
    new "Schermo intero{#preferences-screen}"

    # game/ui/menus/preferences.rpy:52
    old "Built-in walkthrough{#preferences-screen}"
    new "Procedura dettagliata integrata{#preferences-screen}"

    # game/ui/menus/preferences.rpy:53
    old "Enabled{#preferences-screen-walkthrough}"
    new "Abilitato{#preferences-screen-walkthrough}"

    # game/ui/menus/preferences.rpy:55
    old "Disabled{#preferences-screen-walkthrough}"
    new "Disabilitato{#preferences-screen-walkthrough}"

    # game/ui/menus/preferences.rpy:60
    old "Save reminder{#preferences-screen}"
    new "Salva promemoria{#preferences-screen}"

    # game/ui/menus/preferences.rpy:61
    old "Enabled (after each event){#preferences-screen}"
    new "Abilitato (dopo ogni evento){#preferences-screen}"

    # game/ui/menus/preferences.rpy:63
    old "Disabled{#preferences-screen}"
    new "Disabilitato{#preferences-screen}"

    # game/ui/menus/preferences.rpy:68
    old "Initial +18 warning{#preferences-screen}"
    new "Avviso +18 iniziale{#preferences-screen}"

    # game/ui/menus/preferences.rpy:69
    old "Enabled{#preferences-screen-initial-warning}"
    new "Abilitato{#preferences-screen-initial-warning}"

    # game/ui/menus/preferences.rpy:71
    old "Disabled{#preferences-screen-initial-warning}"
    new "Disabilitato{#preferences-screen-initial-warning}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
