﻿
translate italian strings:

    # game/ui/menus/confirm.rpy:41
    old "YES{#confirm-screen}"
    new "SÌ{#confirm-screen}"

    # game/ui/menus/confirm.rpy:41
    old "NO{#confirm-screen}"
    new "NO{#confirm-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
