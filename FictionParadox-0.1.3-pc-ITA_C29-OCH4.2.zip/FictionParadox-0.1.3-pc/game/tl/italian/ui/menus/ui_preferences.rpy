﻿
translate italian strings:

    # game/ui/menus/ui_preferences.rpy:12
    old "Dialogue text speed{#preferences-screen}"
    new "Velocità del testo del dialogo{#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:17
    old "Auto-forward time{#preferences-screen}"
    new "Orario di avanzamento automatico{#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:22
    old "Rollback side{#preferences-screen}"
    new "Lato arretrabile{#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:23
    old "Disabled{#preferences-screen-rollback-side}"
    new "Disabilitato{#preferences-screen-rollback-side}"

    # game/ui/menus/ui_preferences.rpy:24
    old "Left{#preferences-screen-rollback-side}"
    new "Sinistra{#preferences-screen-rollback-side}"

    # game/ui/menus/ui_preferences.rpy:25
    old "Right{#preferences-screen-rollback-side}"
    new "Destra{#preferences-screen-rollback-side}"

    # game/ui/menus/ui_preferences.rpy:30
    old "Dialogue textbox opacity ([percent_value]%){#preferences-screen}"
    new "Opacità della casella di testo del dialogo ([percent_value]%){#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:39
    old "Set to default{#preferences-screen}"
    new "Imposta su predefinito{#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:49
    old "Dialogue text size ([persistent.dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"
    new "Dimensioni del testo del dialogo ([persistent.dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:68
    old "Dialogue text outline ([persistent.dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"
    new "Struttura del testo del dialogo ([persistent.dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/menus/ui_preferences.rpy:50
    old "Dialogue text size ([persistent.small_screen_dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"
    new "Dimensioni del testo del dialogo ([persistent.small_screen_dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:67
    old "Dialogue text size ([persistent.big_screen_dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"
    new "Dimensioni del testo del dialogo ([persistent.big_screen_dialogue_text_size]/[gui.max_text_size]){#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:87
    old "Dialogue text outline ([persistent.small_screen_dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"
    new "Struttura del testo del dialogo ([persistent.small_screen_dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"

    # game/ui/menus/ui_preferences.rpy:104
    old "Dialogue text outline ([persistent.big_screen_dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"
    new "Struttura del testo del dialogo ([persistent.big_screen_dialogue_text_outlines_value]/[gui.max_dialogue_text_outlines_value]){#preferences-screen}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
