﻿
translate italian strings:

    # game/ui/menus/preferences_menu.rpy:89
    old "PREFERENCES{#preferences-menu}"
    new "PREFERENZE{#preferences-menu}"

    # game/ui/menus/preferences_menu.rpy:103
    old "GENERAL{#preferences-menu}"
    new "GENERALE{#preferences-menu}"

    # game/ui/menus/preferences_menu.rpy:114
    old "AUDIO{#preferences-menu}"
    new "AUDIO{#preferences-menu}"

    # game/ui/menus/preferences_menu.rpy:127
    old "CONTROLS{#preferences-screen}"
    new "COMANDI{#preferences-screen}"

    # game/ui/menus/preferences_menu.rpy:138
    old "INTERFACE{#preferences-menu}"
    new "INTERFACCIA{#preferences-menu}"

    # game/ui/menus/preferences_menu.rpy:149
    old "LANGUAGE{#preferences-menu}"
    new "LINGUA{#preferences-menu}"

    # game/ui/menus/preferences_menu.rpy:164
    old "CREDITS{#preferences-screen}"
    new "CREDITI{#preferences-screen}"

    # game/ui/menus/preferences_menu.rpy:176
    old "SUPPORT US!{#preferences-screen}"
    new "SOSTIENICI!{#preferences-screen}"

    # game/ui/menus/preferences_menu.rpy:189
    old "BACK TO GAME{#preferences-screen}"
    new "TORNA AL GIOCO{#preferences-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
