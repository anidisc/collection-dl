﻿
translate italian strings:

    # game/ui/menus/help.rpy:50
    old "Enter{#controls-screen}"
    new "Inserisci{#controls-screen}"

    # game/ui/menus/help.rpy:51
    old "Advances dialogue and activates the interface.{#controls-screen}"
    new "Avanza nel dialogo e attiva l'interfaccia.{#controls-screen}"

    # game/ui/menus/help.rpy:54
    old "Space{#controls-screen}"
    new "Spazio{#controls-screen}"

    # game/ui/menus/help.rpy:55
    old "Advances dialogue without selecting choices.{#controls-screen}"
    new "Avanza nel dialogo senza selezionare le scelte.{#controls-screen}"

    # game/ui/menus/help.rpy:58
    old "Arrow Keys{#controls-screen}"
    new "Tasti freccia{#controls-screen}"

    # game/ui/menus/help.rpy:59
    old "Navigate the interface.{#controls-screen}"
    new "Navigare nell'interfaccia.{#controls-screen}"

    # game/ui/menus/help.rpy:62
    old "Escape{#controls-screen}"
    new "Fuga{#controls-screen}"

    # game/ui/menus/help.rpy:63
    old "Accesses the game menu.{#controls-screen}"
    new "Accede al menu di gioco.{#controls-screen}"

    # game/ui/menus/help.rpy:66
    old "Ctrl{#controls-screen}"
    new "Ctrl{#controls-screen}"

    # game/ui/menus/help.rpy:67
    old "Skips dialogue while held down.{#controls-screen}"
    new "Salta il dialogo quando viene tenuto premuto.{#controls-screen}"

    # game/ui/menus/help.rpy:70
    old "Tab{#controls-screen}"
    new "Scheda{#controls-screen}"

    # game/ui/menus/help.rpy:71
    old "Toggles dialogue skipping.{#controls-screen}"
    new "Attiva/disattiva il salto dei dialoghi.{#controls-screen}"

    # game/ui/menus/help.rpy:74
    old "Page Up{#controls-screen}"
    new "Pagina su{#controls-screen}"

    # game/ui/menus/help.rpy:75
    old "Rolls back to earlier dialogue.{#controls-screen}"
    new "Torna al dialogo precedente.{#controls-screen}"

    # game/ui/menus/help.rpy:78
    old "Page Down{#controls-screen}"
    new "Pagina giù{#controls-screen}"

    # game/ui/menus/help.rpy:79
    old "Rolls forward to later dialogue.{#controls-screen}"
    new "Passa al dialogo successivo.{#controls-screen}"

    # game/ui/menus/help.rpy:83
    old "Hides the user interface.{#controls-screen}"
    new "Nasconde l'interfaccia utente.{#controls-screen}"

    # game/ui/menus/help.rpy:87
    old "Takes a screenshot.{#controls-screen}"
    new "Acquisisce uno screenshot.{#controls-screen}"

    # game/ui/menus/help.rpy:91
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}.{#controls-screen}"
    new "Attiva/disattiva l'assistenza {a=https://www.renpy.org/l/voicing}auto-voce{/a}.{#controls-screen}"

    # game/ui/menus/help.rpy:95
    old "Opens the accessibility menu.{#controls-screen}"
    new "Apre il menu di accessibilità.{#controls-screen}"

    # game/ui/menus/help.rpy:99
    old "Left Click{#controls-screen}"
    new "Clic sinistro{#controls-screen}"

    # game/ui/menus/help.rpy:103
    old "Middle Click{#controls-screen}"
    new "Clic centrale{#controls-screen}"

    # game/ui/menus/help.rpy:107
    old "Right Click{#controls-screen}"
    new "Clic destro{#controls-screen}"

    # game/ui/menus/help.rpy:111
    old "Mouse Wheel Up{#controls-screen}"
    new "Rotellina del mouse su{#controls-screen}"

    # game/ui/menus/help.rpy:115
    old "Mouse Wheel Down{#controls-screen}"
    new "Rotellina del mouse giù{#controls-screen}"

    # game/ui/menus/help.rpy:120
    old "Right Trigger,\nA/Bottom Button{#controls-screen}"
    new "Grilletto destro,\nPulsante A/In basso{#controls-screen}"

    # game/ui/menus/help.rpy:124
    old "Left Trigger,\nLeft Shoulder{#controls-screen}"
    new "Grilletto sinistro,\nSpalla sinistra{#controls-screen}"

    # game/ui/menus/help.rpy:128
    old "Right Shoulder{#controls-screen}"
    new "Spalla Destra{#controls-screen}"

    # game/ui/menus/help.rpy:132
    old "D-Pad, Sticks{#controls-screen}"
    new "Tastierino direzionale, levette{#controls-screen}"

    # game/ui/menus/help.rpy:136
    old "Start, Guide,\nB/Right Button{#controls-screen}"
    new "Avvio, Guida,\nPulsante B/Destra{#controls-screen}"

    # game/ui/menus/help.rpy:140
    old "Y/Top Button{#controls-screen}"
    new "Y/Pulsante superiore{#controls-screen}"

    # game/ui/menus/help.rpy:143
    old "Calibrate{#controls-screen}"
    new "Calibra{#controls-screen}"

    # game/ui/menus/help.rpy:159
    old "KEYBOARD{#preferences-menu}"
    new "TASTIERA{#preferences-menu}"

    # game/ui/menus/help.rpy:170
    old "MOUSE{#preferences-menu}"
    new "MOUSE{#preferences-menu}"

    # game/ui/menus/help.rpy:182
    old "GAMEPAD{#preferences-menu}"
    new "GIOCO{#preferences-menu}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
