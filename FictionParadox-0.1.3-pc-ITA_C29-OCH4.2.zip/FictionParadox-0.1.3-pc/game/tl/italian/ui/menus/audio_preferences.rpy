﻿
translate italian strings:

    # game/ui/menus/audio_preferences.rpy:28
    old "Music volume{#preferences-screen}"
    new "Volume della musica{#preferences-screen}"

    # game/ui/menus/audio_preferences.rpy:34
    old "Sound effects volume{#preferences-screen}"
    new "Volume degli effetti sonori{#preferences-screen}"

    # game/ui/menus/audio_preferences.rpy:36
    old "Test sound{#preferences-screen}"
    new "Prova suono{#preferences-screen}"

    # game/ui/menus/audio_preferences.rpy:42
    old "Voice volume{#preferences-screen}"
    new "Volume della voce{#preferences-screen}"

    # game/ui/menus/audio_preferences.rpy:47
    old "Mute all{#preferences-screen}"
    new "Disattiva tutto{#preferences-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
