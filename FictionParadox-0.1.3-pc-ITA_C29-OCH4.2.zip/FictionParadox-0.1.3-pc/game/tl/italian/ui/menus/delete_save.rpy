﻿
translate italian strings:

    # game/ui/menus/delete_save.rpy:94
    old "DELETE GAME{#load-screen}"
    new "ELIMINA GIOCO{#load-screen}"

    # game/ui/menus/delete_save.rpy:106
    old "[selected_universe_slot.data.mc_name!t] - Universe [selected_universe_slot.number]{#load-screen}"
    new "[selected_universe_slot.data.mc_name!t] - Universo [selected_universe_slot.number]{#load-screen}"

    # game/ui/menus/delete_save.rpy:112
    old "??? - Universe [selected_universe_slot.number]{#load-screen}"
    new "??? - Universo [selected_universe_slot.number]{#load-screen}"

    # game/ui/menus/delete_save.rpy:118
    old "Universe [selected_universe_slot.number]{#load-screen}"
    new "Universo [selected_universe_slot.number]{#load-screen}"

    # game/ui/menus/delete_save.rpy:167
    old "PAGE [game_slot_current_page_number]"
    new "PAGINA [game_slot_current_page_number]"

    # game/ui/menus/delete_save.rpy:281
    old "START NEW GAME{#load-screen}"
    new "INIZIA UNA NUOVA PARTITA{#load-screen}"

    # game/ui/menus/delete_save.rpy:287
    old "(empty){#load-screen}"
    new "(vuoto){#load-screen}"

    # game/ui/menus/delete_save.rpy:329
    old "Chapter [game_slot.data.current_chapter]{#game-slot}"
    new "Capitolo [game_slot.data.current_chapter]{#game-slot}"

    # game/ui/menus/delete_save.rpy:334
    old "Book II - Chapter [game_slot.data.current_chapter]{#game-slot}"
    new "Libro II - Capitolo [game_slot.data.current_chapter]{#game-slot}"

    # game/ui/menus/delete_save.rpy:339
    old "Book III - Chapter [game_slot.data.current_chapter]{#game-slot}"
    new "Libro III - Capitolo [game_slot.data.current_chapter]{#game-slot}"

    # game/ui/menus/delete_save.rpy:353
    old "BACK{#delete-save-screen}"
    new "INDIETRO{#delete-save-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
