﻿
translate italian strings:

    # game/ui/end_of_release/version01.rpy:36
    old "Thanks for playing!{#end-of-release-0.1}"
    new "Grazie per aver giocato!{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:43
    old "See you in chapter 2...{#end-of-release-0.1}"
    new "Ci vediamo al capitolo 2...{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:50
    old "That's all!?{#end-of-release-0.1}"
    new "Questo è tutto!?{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:57
    old "Yes, that's all.{#end-of-release-0.1}"
    new "Sì, questo è tutto.{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:64
    old "Art takes time, you know.{#end-of-release-0.1}"
    new "L'arte richiede tempo, lo sai.{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:71
    old "So if you want this...{#end-of-release-0.1}"
    new "Quindi, se vuoi questo...{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:98
    old "Support us!{#end-of-release-0.1}"
    new "Sostienici!{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:103
    old "You can subscribe here:{#end-of-release-0.1}"
    new "Puoi iscriverti qui:{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:135
    old "Special thanks to our first subscribers:{#end-of-release-0.1}"
    new "Un ringraziamento speciale ai nostri primi abbonati:{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:152
    old "Until next time!{#end-of-release-0.1}"
    new "Alla prossima volta!{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:233
    old "Go to title screen{#end-of-release-0.1}"
    new "Vai alla schermata del titolo{#end-of-release-0.1}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/end_of_release/version01.rpy:124
    old "Or buy the game on:{#end-of-release-0.1}"
    new "Oppure acquista il gioco su:{#end-of-release-0.1}"

    # game/ui/end_of_release/version01.rpy:168
    old "See you in the next chapter!{#end-of-release-0.1}"
    new "Ci vediamo al prossimo capitolo!{#end-of-release-0.1}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
