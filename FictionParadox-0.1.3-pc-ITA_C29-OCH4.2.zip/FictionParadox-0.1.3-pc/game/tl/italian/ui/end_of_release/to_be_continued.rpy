﻿
translate italian strings:

    # game/ui/end_of_release/to_be_continued.rpy:12
    old "TO BE CONTINUED{#end-of-release}"
    new "CONTINUA{#end-of-release}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
