﻿
translate italian strings:

    # game/ui/ingame/character_profile.rpy:54
    old "Acquaintance{#bond}"
    new "Conoscente{#bond}"

    # game/ui/ingame/character_profile.rpy:56
    old "Affinity{#bond}"
    new "Affinità{#bond}"

    # game/ui/ingame/character_profile.rpy:58
    old "Friendship{#bond}"
    new "Amicizia{#bond}"

    # game/ui/ingame/character_profile.rpy:60
    old "Love{#bond}"
    new "Amore{#bond}"

    # game/ui/ingame/character_profile.rpy:62
    old "Trust{#bond}"
    new "Fiducia{#bond}"

    # game/ui/ingame/character_profile.rpy:64
    old "Devotion{#bond}"
    new "Devozione{#bond}"

    # game/ui/ingame/character_profile.rpy:92
    old "AGE{#profile-screen}"
    new "ETÀ{#profile-screen}"

    # game/ui/ingame/character_profile.rpy:102
    old "ORIGIN{#profile-screen}"
    new "ORIGINE{#profile-screen}"

    # game/ui/ingame/character_profile.rpy:112
    old "HEIGHT{#profile-screen}"
    new "ALTEZZA{#profile-screen}"

    # game/ui/ingame/character_profile.rpy:122
    old "WEIGHT{#profile-screen}"
    new "PESO{#profile-screen}"

    # game/ui/ingame/character_profile.rpy:146
    old "Bond:  [character_bond_with_mc!tu]{#profile-screen}"
    new "Vincolo: [character_bond_with_mc!tu]{#profile-screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
