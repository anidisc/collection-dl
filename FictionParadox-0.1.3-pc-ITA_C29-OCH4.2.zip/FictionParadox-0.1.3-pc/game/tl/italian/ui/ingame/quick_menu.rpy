﻿
translate italian strings:

    # game/ui/ingame/quick_menu.rpy:169
    old "Previous dialogue{#quick-menu}"
    new "Dialogo precedente{#quick-menu}"

    # game/ui/ingame/quick_menu.rpy:184
    old "Skip dialogues{#quick-menu}"
    new "Salta dialoghi{#quick-menu}"

    # game/ui/ingame/quick_menu.rpy:199
    old "Auto-forward{#quick-menu}"
    new "Inoltro automatico{#quick-menu}"

    # game/ui/ingame/quick_menu.rpy:215
    old "Hide interface{#quick-menu}"
    new "Nascondi interfaccia{#quick-menu}"

    # game/ui/ingame/quick_menu.rpy:231
    old "Game menu{#quick-menu}"
    new "Menù di gioco{#quick-menu}"

    # game/ui/ingame/quick_menu.rpy:248
    old "Hide quick menu{#quick-menu}"
    new "Nascondi menu rapido{#quick-menu}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
