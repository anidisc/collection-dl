﻿
translate italian strings:

    # game/ui/ingame/save_reminder.rpy:94
    old "Would you like to save your progress here?{#save-reminder}"
    new "Vuoi salvare i tuoi progressi qui?{#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:100
    old "YES\n{size=*0.4}(overwrite){/size}{#save-reminder}"
    new "SÌ\n{size=*0.4}(sovrascrivi){/size}{#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:109
    old "YES{#save-reminder}"
    new "SÌ{#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:120
    old "NO{#save-reminder}"
    new "NO{#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:131
    old "CHOOSE ANOTHER SLOT{#save-reminder}"
    new "SCEGLI UN ALTRO SLOT{#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:157
    old "(empty slot){#save-reminder}"
    new "(slot vuoto){#save-reminder}"

    # game/ui/ingame/save_reminder.rpy:234
    old "%Y-%m-%d - %I:%M %p{#load-screen}"
    new "%Y-%m-%d - %I:%M %p{#load-screen}"

    # game/ui/ingame/save_reminder.rpy:248
    old "Prologue{#game-slot}"
    new "Prologo{#game-slot}"

    # game/ui/ingame/save_reminder.rpy:254
    old "Chapter [current_game_slot.data.current_chapter]{#game-slot}"
    new "Capitolo [current_game_slot.data.current_chapter]{#game-slot}"

    # game/ui/ingame/save_reminder.rpy:259
    old "Book II - Chapter [current_game_slot.data.current_chapter]{#game-slot}"
    new "Libro II - Capitolo [current_game_slot.data.current_chapter]{#game-slot}"

    # game/ui/ingame/save_reminder.rpy:264
    old "Book III - Chapter [current_game_slot.data.current_chapter]{#game-slot}"
    new "Libro III - Capitolo [current_game_slot.data.current_chapter]{#game-slot}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
