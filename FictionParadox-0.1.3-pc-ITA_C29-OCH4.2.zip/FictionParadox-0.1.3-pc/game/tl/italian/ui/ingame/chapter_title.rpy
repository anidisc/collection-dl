﻿
translate italian strings:

    # game/ui/ingame/chapter_title.rpy:18
    old "Chapter 1{#chapter}"
    new "Capitolo 1{#chapter}"

    # game/ui/ingame/chapter_title.rpy:20
    old "Awakening{#chapter}"
    new "Risveglio{#chapter}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
