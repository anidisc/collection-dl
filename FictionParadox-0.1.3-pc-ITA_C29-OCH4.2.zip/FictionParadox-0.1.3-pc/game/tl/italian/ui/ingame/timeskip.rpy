﻿
translate italian strings:

    # game/ui/ingame/timeskip.rpy:14
    old "A FEW MINUTES LATER...{#timeskip}"
    new "POCHI MINUTI DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:20
    old "A LITTLE WHILE LATER...{#timeskip}"
    new "POCO DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:26
    old "LATER, AT HOME...{#timeskip}"
    new "DOPO, A CASA...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:32
    old "LATER, AT WORK...{#timeskip}"
    new "DOPO, AL LAVORO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:38
    old "MEANWHILE...{#timeskip}"
    new "INTANTO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:44
    old "ONE HOUR LATER...{#timeskip}"
    new "UN'ORA DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:50
    old "ONE WEEK LATER...{#timeskip}"
    new "UNA SETTIMANA DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:56
    old "SINCE THAT DAY...{#timeskip}"
    new "DA QUEL GIORNO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:62
    old "SOME TIME LATER...{#timeskip}"
    new "QUALCHE TEMPO DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:68
    old "THE NEXT DAY...{#timeskip}"
    new "IL GIORNO DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:74
    old "THE NEXT MONTH...{#timeskip}"
    new "IL PROSSIMO MESE...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:80
    old "THE NEXT MORNING...{#timeskip}"
    new "LA MATTINA DOPO...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:86
    old "THE NEXT WEEK...{#timeskip}"
    new "LA PROSSIMA SETTIMANA...{#timeskip}"

    # game/ui/ingame/timeskip.rpy:92
    old "THE NEXT YEAR...{#timeskip}"
    new "L'ANNO PROSSIMO...{#timeskip}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
