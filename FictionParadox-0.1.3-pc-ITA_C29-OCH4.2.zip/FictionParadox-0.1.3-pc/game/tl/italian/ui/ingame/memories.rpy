﻿
translate italian strings:

    # game/ui/ingame/memories.rpy:84
    old "MEMORIES{#memories-screen}"
    new "MEMORIE{#memories-screen}"

    # game/ui/ingame/memories.rpy:137
    old "Prologue{#memories-screen}"
    new "Prologo{#memories-screen}"

    # game/ui/ingame/memories.rpy:140
    old "Chapter [chapter.number]\n{size=*0.5}[chapter.title!t]{/size}{#memories-screen}"
    new "Capitolo [chapter.number]\n{size=*0.5}[chapter.title!t]{/size}{#memories-screen}"

    # game/ui/ingame/memories.rpy:143
    old "Chapter [chapter.number]{#memories-screen}"
    new "Capitolo [chapter.number]{#memories-screen}"

    # game/ui/ingame/memories.rpy:249
    old "[scene.number]. [scene.title!t]"
    new "[scene.number]. [scene.title!t]"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/ui/ingame/memories.rpy:251
    old "[memories_ui_scene_number]. [scene.title!t]"
    new "[memories_ui_scene_number]. [scene.title!t]"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
