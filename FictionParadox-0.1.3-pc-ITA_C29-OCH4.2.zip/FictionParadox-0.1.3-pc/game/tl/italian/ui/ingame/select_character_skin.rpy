﻿
translate italian strings:

    # game/ui/ingame/select_character_skin.rpy:71
    old "Apply always last skin{#select-character-skin}"
    new "Applicare sempre l'ultima pelle{#select-character-skin}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
