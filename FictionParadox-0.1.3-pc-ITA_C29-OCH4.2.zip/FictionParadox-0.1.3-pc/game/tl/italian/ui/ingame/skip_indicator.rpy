﻿
translate italian strings:

    # game/ui/ingame/skip_indicator.rpy:61
    old "Skipping{#skip-indicator}"
    new "Saltare{#skip-indicator}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
