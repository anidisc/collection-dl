﻿
translate italian strings:

    # renpy/common/000statements.rpy:28
    old "Click to play the video."
    new "Fare clic per riprodurre il video."

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Auto-voce disabilitata."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Voci negli appunti abilitate. "

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Auto-voce abilitata. "

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "barra"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "selezionato"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "vista"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "scorrimento orizzontale"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "scorrimento verticale"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "attivare"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "disattivare"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentare"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "diminuire"

    # renpy/common/00accessibility.rpy:134
    old "Self-Voicing"
    new "Auto-voce"

    # renpy/common/00accessibility.rpy:137
    old "Self-voicing support is limited when using a touch screen."
    new "Il supporto della voce automatica è limitato quando si utilizza un touch screen."

    # renpy/common/00accessibility.rpy:139
    old "Off"
    new "Spento"

    # renpy/common/00accessibility.rpy:143
    old "Text-to-speech"
    new "Sintesi vocale"

    # renpy/common/00accessibility.rpy:147
    old "Clipboard"
    new "Appunti"

    # renpy/common/00accessibility.rpy:151
    old "Debug"
    new "Debug"

    # renpy/common/00accessibility.rpy:155
    old "Voice Volume"
    new "Volume della voce"

    # renpy/common/00accessibility.rpy:163
    old "Reset"
    new "Ripristina"

    # renpy/common/00accessibility.rpy:167
    old "Self-Voicing Volume Drop"
    new "Calo del volume delle voci automatiche"

    # renpy/common/00accessibility.rpy:180
    old "Mono Audio"
    new "Audio mono"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "Abilita"

    # renpy/common/00accessibility.rpy:186
    old "Disable"
    new "Disabilita"

    # renpy/common/00accessibility.rpy:198
    old "Font Override"
    new "Sostituzione carattere"

    # renpy/common/00accessibility.rpy:200
    old "Default"
    new "Predefinito"

    # renpy/common/00accessibility.rpy:204
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:208
    old "Opendyslexic"
    new "Dislessico aperto"

    # renpy/common/00accessibility.rpy:212
    old "High Contrast Text"
    new "Testo ad alto contrasto"

    # renpy/common/00accessibility.rpy:224
    old "Text Size Scaling"
    new "Ridimensionamento della dimensione del testo"

    # renpy/common/00accessibility.rpy:235
    old "Line Spacing Scaling"
    new "Ridimensionamento dell'interlinea"

    # renpy/common/00accessibility.rpy:246
    old "Kerning"
    new "Crenatura"

    # renpy/common/00accessibility.rpy:267
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menù di accessibilità. Utilizza le frecce su e giù per navigare e Invio per attivare pulsanti e barre."

    # renpy/common/00accessibility.rpy:288
    old "Self-Voicing and Audio"
    new "Auto-voce e audio"

    # renpy/common/00accessibility.rpy:292
    old "Text"
    new "Testo"

    # renpy/common/00accessibility.rpy:296
    old "Return"
    new "Ritorno"

    # renpy/common/00accessibility.rpy:306
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Le opzioni di questo menu hanno lo scopo di migliorare l'accessibilità. Potrebbero non funzionare con tutti i giochi e alcune combinazioni di opzioni potrebbero rendere il gioco ingiocabile. Questo non è un problema con il gioco o il motore. Per ottenere i migliori risultati quando si modificano i caratteri, provare a mantenere la dimensione del testo uguale a quella originale."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Lunedì"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Martedì"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Mercoledì"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Giovedì"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Venerdì"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Sabato"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Domenica"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Mer"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Gio"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Ven"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Sab"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Domenica"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Gennaio"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Febbraio"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Marzo"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Aprile"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Maggio"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Giugno"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Luglio"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Settembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Ottobre"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Novembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Dicembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Gen"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Febbraio"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Marzo"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Apr"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}Maggio"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Giu"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Lug"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Agosto"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Sett"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Ott"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Novembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Dic"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Slot di salvataggio %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Slot di caricamento %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Elimina slot [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Pagina del file automatica"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Pagina del file veloce"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Pagina del file [text]"

    # renpy/common/00action_file.rpy:675
    old "Page {}"
    new "Pagina {}"

    # renpy/common/00action_file.rpy:675
    old "Automatic saves"
    new "Salvataggi automatici"

    # renpy/common/00action_file.rpy:675
    old "Quick saves"
    new "Salvataggi rapidi"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Pagina del file successivo."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Pagina del file precedente."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Salvataggio rapido completato."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Salvataggio rapido."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Caricamento rapido."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Lingua [text]"

    # renpy/common/00action_other.rpy:786
    old "Open [text] directory."
    new "Apri la directory [text]."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "Il direttore interattivo non è abilitato qui."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "Fatto"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(dichiarazione)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(etichetta)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(attributi)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(trasformare)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transizione)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(canale)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(nome file)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Cambiare"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Aggiungi"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Annulla"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Rimuovi"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Dichiarazione:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Etichetta:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Attributi:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Fare clic per attivare/disattivare l'attributo, fare clic con il pulsante destro del mouse per attivare/disattivare l'attributo negativo."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "trasforma:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Fare clic per impostare la trasformazione, fare clic con il pulsante destro del mouse per aggiungere all'elenco delle trasformazioni."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Personalizza director.transforms per aggiungere più trasformazioni."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Dietro:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Fare clic per impostare, fare clic con il pulsante destro del mouse per aggiungere all'elenco precedente."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Transizione:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Fare clic per impostare."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Personalizza director.transitions per aggiungere più transizioni."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Canale:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Personalizza director.audio_channels per aggiungere più canali."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Nome file audio:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "Sei sicuro?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "Sei sicuro di voler eliminare questo salvataggio?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "Sei sicuro di voler sovrascrivere il tuo salvataggio?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Il caricamento perderà i progressi non salvati.\nSei sicuro di volerlo fare?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "Sei sicuro di voler uscire?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Sei sicuro di voler tornare al menu principale?\nI progressi non salvati verranno persi."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "Sei sicuro di voler continuare da dove avevi interrotto?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "Sei sicuro di voler terminare il replay?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "Sei sicuro di voler iniziare a saltare?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "Sei sicuro di voler passare alla scelta successiva?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Sei sicuro di voler saltare i dialoghi invisibili alla scelta successiva?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Questo salvataggio è stato creato su un dispositivo diverso. I file di salvataggio creati in modo dannoso possono danneggiare il tuo computer. Ti fidi del creatore di questo salvataggio e di tutti coloro che potrebbero aver modificato il file?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Ti fidi del dispositivo su cui è stato creato il salvataggio? Dovresti scegliere sì solo se sei l'unico utente del dispositivo."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "Impossibile salvare lo screenshot come %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Screenshot salvato come %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Modalità Salta"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Questo programma contiene software gratuito con una serie di licenze, tra cui la licenza MIT e la licenza pubblica generica minore GNU. Un elenco completo del software, inclusi i collegamenti al codice sorgente completo, è disponibile {a=https://www.renpy.org/l/license}qui{/a}."

    # renpy/common/00preferences.rpy:295
    old "display"
    new "visualizzazione"

    # renpy/common/00preferences.rpy:315
    old "transitions"
    new "transizioni"

    # renpy/common/00preferences.rpy:324
    old "skip transitions"
    new "saltare le transizioni"

    # renpy/common/00preferences.rpy:326
    old "video sprites"
    new "sprite video"

    # renpy/common/00preferences.rpy:335
    old "show empty window"
    new "mostra la finestra vuota"

    # renpy/common/00preferences.rpy:344
    old "text speed"
    new "velocità del testo"

    # renpy/common/00preferences.rpy:352
    old "joystick"
    new "joystick"

    # renpy/common/00preferences.rpy:352
    old "joystick..."
    new "joystick..."

    # renpy/common/00preferences.rpy:359
    old "skip"
    new "salta"

    # renpy/common/00preferences.rpy:362
    old "skip unseen [text]"
    new "salta senza essere visto [text]"

    # renpy/common/00preferences.rpy:367
    old "skip unseen text"
    new "saltare il testo non visualizzato"

    # renpy/common/00preferences.rpy:369
    old "begin skipping"
    new "iniziare a saltare"

    # renpy/common/00preferences.rpy:373
    old "after choices"
    new "dopo le scelte"

    # renpy/common/00preferences.rpy:380
    old "skip after choices"
    new "saltare dopo le scelte"

    # renpy/common/00preferences.rpy:382
    old "auto-forward time"
    new "tempo di avanzamento automatico"

    # renpy/common/00preferences.rpy:396
    old "auto-forward"
    new "inoltro automatico"

    # renpy/common/00preferences.rpy:403
    old "Auto forward"
    new "Avanzamento automatico"

    # renpy/common/00preferences.rpy:406
    old "auto-forward after click"
    new "avanzamento automatico dopo il clic"

    # renpy/common/00preferences.rpy:415
    old "automatic move"
    new "spostamento automatico"

    # renpy/common/00preferences.rpy:424
    old "wait for voice"
    new "aspetta la voce"

    # renpy/common/00preferences.rpy:433
    old "voice sustain"
    new "sostegno della voce"

    # renpy/common/00preferences.rpy:442
    old "self voicing"
    new "auto-voce"

    # renpy/common/00preferences.rpy:445
    old "self voicing enable"
    new "abilitare l'auto-voce"

    # renpy/common/00preferences.rpy:447
    old "self voicing disable"
    new "disabilitazione della voce automatica"

    # renpy/common/00preferences.rpy:451
    old "self voicing volume drop"
    new "calo del volume della voce propria"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing"
    new "voce degli appunti"

    # renpy/common/00preferences.rpy:462
    old "clipboard voicing enable"
    new "abilitazione della voce negli appunti"

    # renpy/common/00preferences.rpy:464
    old "clipboard voicing disable"
    new "disabilitazione della voce negli appunti"

    # renpy/common/00preferences.rpy:468
    old "debug voicing"
    new "eseguire il debug della voce"

    # renpy/common/00preferences.rpy:471
    old "debug voicing enable"
    new "abilitare il debug della voce"

    # renpy/common/00preferences.rpy:473
    old "debug voicing disable"
    new "eseguire il debug della disabilitazione della voce"

    # renpy/common/00preferences.rpy:477
    old "emphasize audio"
    new "enfatizzare l'audio"

    # renpy/common/00preferences.rpy:486
    old "rollback side"
    new "lato di rollback"

    # renpy/common/00preferences.rpy:496
    old "gl powersave"
    new "glpowersave"

    # renpy/common/00preferences.rpy:502
    old "gl framerate"
    new "frequenza fotogrammi gl"

    # renpy/common/00preferences.rpy:505
    old "gl tearing"
    new "gl strappo"

    # renpy/common/00preferences.rpy:508
    old "font transform"
    new "trasformazione del carattere"

    # renpy/common/00preferences.rpy:511
    old "font size"
    new "dimensione del carattere"

    # renpy/common/00preferences.rpy:519
    old "font line spacing"
    new "interlinea del carattere"

    # renpy/common/00preferences.rpy:527
    old "system cursor"
    new "cursore di sistema"

    # renpy/common/00preferences.rpy:536
    old "renderer menu"
    new "menu del renderer"

    # renpy/common/00preferences.rpy:539
    old "accessibility menu"
    new "menu di accessibilità"

    # renpy/common/00preferences.rpy:542
    old "high contrast text"
    new "testo ad alto contrasto"

    # renpy/common/00preferences.rpy:551
    old "audio when minimized"
    new "audio quando ridotto a icona"

    # renpy/common/00preferences.rpy:560
    old "audio when unfocused"
    new "audio quando non è focalizzato"

    # renpy/common/00preferences.rpy:569
    old "web cache preload"
    new "precarico della cache Web"

    # renpy/common/00preferences.rpy:584
    old "voice after game menu"
    new "voce dopo il menu di gioco"

    # renpy/common/00preferences.rpy:593
    old "restore window position"
    new "ripristinare la posizione della finestra"

    # renpy/common/00preferences.rpy:602
    old "mono audio"
    new "audio mono"

    # renpy/common/00preferences.rpy:611
    old "font kerning"
    new "crenatura dei caratteri"

    # renpy/common/00preferences.rpy:619
    old "reset"
    new "resettare"

    # renpy/common/00preferences.rpy:632
    old "main volume"
    new "volume principale"

    # renpy/common/00preferences.rpy:633
    old "music volume"
    new "volume della musica"

    # renpy/common/00preferences.rpy:634
    old "sound volume"
    new "volume del suono"

    # renpy/common/00preferences.rpy:635
    old "voice volume"
    new "volume della voce"

    # renpy/common/00preferences.rpy:636
    old "mute main"
    new "principale muto"

    # renpy/common/00preferences.rpy:637
    old "mute music"
    new "musica muta"

    # renpy/common/00preferences.rpy:638
    old "mute sound"
    new "suono muto"

    # renpy/common/00preferences.rpy:639
    old "mute voice"
    new "voce muta"

    # renpy/common/00preferences.rpy:640
    old "mute all"
    new "disattiva tutto"

    # renpy/common/00preferences.rpy:723
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Voci negli appunti abilitate. Premere 'MAIUSC+C' per disabilitare."

    # renpy/common/00preferences.rpy:725
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "La voce propria direbbe \' [renpy.display.tts.last] \'. Premi 'alt+shift+V' per disabilitare."

    # renpy/common/00preferences.rpy:727
    old "Self-voicing enabled. Press 'v' to disable."
    new "Auto-voce abilitata. Premi 'v' per disabilitare."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Editor di fumetti"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(nascondi)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(bolle trasparenti trattenute)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Sincronizzazione scaricata."

    # renpy/common/00sync.rpy:184
    old "Could not connect to the Ren'Py Sync server."
    new "Impossibile connettersi al server Ren'Py Sync."

    # renpy/common/00sync.rpy:186
    old "The Ren'Py Sync server timed out."
    new "Il server Ren'Py Sync è scaduto."

    # renpy/common/00sync.rpy:188
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Si è verificato un errore sconosciuto durante la connessione al server Ren'Py Sync."

    # renpy/common/00sync.rpy:204
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Il server Ren'Py Sync non ha una copia di questa sincronizzazione. L'ID di sincronizzazione potrebbe non essere valido o potrebbe essere scaduto."

    # renpy/common/00sync.rpy:305
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Inserisci l'ID di sincronizzazione che hai generato.\nNon inserire mai un ID di sincronizzazione che non hai creato tu stesso."

    # renpy/common/00sync.rpy:324
    old "The sync ID is not in the correct format."
    new "L'ID di sincronizzazione non è nel formato corretto."

    # renpy/common/00sync.rpy:344
    old "The sync could not be decrypted."
    new "Non è stato possibile decifrare la sincronizzazione."

    # renpy/common/00sync.rpy:367
    old "The sync belongs to a different game."
    new "La sincronizzazione appartiene a un gioco diverso."

    # renpy/common/00sync.rpy:372
    old "The sync contains a file with an invalid name."
    new "La sincronizzazione contiene un file con un nome non valido."

    # renpy/common/00sync.rpy:425
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "In questo modo i tuoi salvataggi verranno caricati sul {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nVuoi continuare?"

    # renpy/common/00sync.rpy:433
    old "Yes"
    new "Sì"

    # renpy/common/00sync.rpy:434
    old "No"
    new "No"

    # renpy/common/00sync.rpy:457
    old "Enter Sync ID"
    new "Inserisci l'ID di sincronizzazione"

    # renpy/common/00sync.rpy:468
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Questo contatterà il {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."

    # renpy/common/00sync.rpy:498
    old "Sync Success"
    new "Sincronizzazione riuscita"

    # renpy/common/00sync.rpy:501
    old "The Sync ID is:"
    new "L'ID di sincronizzazione è:"

    # renpy/common/00sync.rpy:507
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puoi utilizzare questo ID per scaricare il salvataggio su un altro dispositivo.\nQuesta sincronizzazione scadrà tra un'ora.\nLa sincronizzazione di Ren'Py è supportata da {a=https://www.renpy.org/sponsors.html}Sponsor di Ren'Py{/a}."

    # renpy/common/00sync.rpy:511
    old "Continue"
    new "Continua"

    # renpy/common/00sync.rpy:536
    old "Sync Error"
    new "Errore di sincronizzazione"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Identificatore della traduzione: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " traduce [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copiato negli appunti.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Contatto con l'App Store\nAttendere..."

    # renpy/common/00updater.rpy:415
    old "No update methods found."
    new "Nessun metodo di aggiornamento trovato."

    # renpy/common/00updater.rpy:462
    old "Could not download file list: "
    new "Impossibile scaricare l'elenco dei file: "

    # renpy/common/00updater.rpy:465
    old "File list digest does not match."
    new "Il digest dell'elenco dei file non corrisponde."

    # renpy/common/00updater.rpy:675
    old "An error is being simulated."
    new "Viene simulato un errore."

    # renpy/common/00updater.rpy:863
    old "Either this project does not support updating, or the update status file was deleted."
    new "Questo progetto non supporta l'aggiornamento oppure il file di stato dell'aggiornamento è stato eliminato."

    # renpy/common/00updater.rpy:877
    old "This account does not have permission to perform an update."
    new "Questo account non dispone dell'autorizzazione per eseguire un aggiornamento."

    # renpy/common/00updater.rpy:880
    old "This account does not have permission to write the update log."
    new "Questo account non dispone dell'autorizzazione per scrivere il registro degli aggiornamenti."

    # renpy/common/00updater.rpy:966
    old "Could not verify update signature."
    new "Impossibile verificare la firma dell'aggiornamento."

    # renpy/common/00updater.rpy:1289
    old "The update file was not downloaded."
    new "Il file di aggiornamento non è stato scaricato."

    # renpy/common/00updater.rpy:1307
    old "The update file does not have the correct digest - it may have been corrupted."
    new "Il file di aggiornamento non ha il digest corretto: potrebbe essere stato danneggiato."

    # renpy/common/00updater.rpy:1457
    old "While unpacking {}, unknown type {}."
    new "Durante il disimballaggio {}, tipo sconosciuto {}."

    # renpy/common/00updater.rpy:1928
    old "Updater"
    new "Aggiornamento"

    # renpy/common/00updater.rpy:1935
    old "An error has occurred:"
    new "Si è verificato un errore:"

    # renpy/common/00updater.rpy:1937
    old "Checking for updates."
    new "Controllo degli aggiornamenti."

    # renpy/common/00updater.rpy:1939
    old "This program is up to date."
    new "Questo programma è aggiornato."

    # renpy/common/00updater.rpy:1941
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] è disponibile. Vuoi installarlo?"

    # renpy/common/00updater.rpy:1943
    old "Preparing to download the updates."
    new "Preparazione al download degli aggiornamenti."

    # renpy/common/00updater.rpy:1945
    old "Downloading the updates."
    new "Download degli aggiornamenti."

    # renpy/common/00updater.rpy:1947
    old "Unpacking the updates."
    new "Disimballaggio degli aggiornamenti."

    # renpy/common/00updater.rpy:1949
    old "Finishing up."
    new "Finendo."

    # renpy/common/00updater.rpy:1951
    old "The updates have been installed. The program will restart."
    new "Gli aggiornamenti sono stati installati. Il programma verrà riavviato."

    # renpy/common/00updater.rpy:1953
    old "The updates have been installed."
    new "Gli aggiornamenti sono stati installati."

    # renpy/common/00updater.rpy:1955
    old "The updates were cancelled."
    new "Gli aggiornamenti sono stati cancellati."

    # renpy/common/00updater.rpy:1970
    old "Proceed"
    new "Procedi"

    # renpy/common/00updater.rpy:1986
    old "Preparing to download the game data."
    new "Preparazione al download dei dati di gioco."

    # renpy/common/00updater.rpy:1988
    old "Downloading the game data."
    new "Download dei dati di gioco."

    # renpy/common/00updater.rpy:1990
    old "The game data has been downloaded."
    new "I dati del gioco sono stati scaricati."

    # renpy/common/00updater.rpy:1992
    old "An error occurred when trying to download game data:"
    new "Si è verificato un errore durante il tentativo di scaricare i dati di gioco:"

    # renpy/common/00updater.rpy:1997
    old "This game cannot be run until the game data has been downloaded."
    new "Questo gioco non può essere eseguito finché i dati del gioco non sono stati scaricati."

    # renpy/common/00updater.rpy:2004
    old "Retry"
    new "Riprova"

    # renpy/common/00compat.rpy:456
    old "Fullscreen"
    new "Schermo intero"

    # renpy/common/00gallery.rpy:676
    old "Image [index] of [count] locked."
    new "Immagine [index] di [count] bloccata."

    # renpy/common/00gallery.rpy:696
    old "prev"
    new "prec"

    # renpy/common/00gallery.rpy:697
    old "next"
    new "successivo"

    # renpy/common/00gallery.rpy:698
    old "slideshow"
    new "presentazione"

    # renpy/common/00gallery.rpy:699
    old "return"
    new "ritorno"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "Render"

    # renpy/common/00gltest.rpy:91
    old "Automatically Choose"
    new "Scegli automaticamente"

    # renpy/common/00gltest.rpy:96
    old "Force GL2 Renderer"
    new "Forza il renderer GL2"

    # renpy/common/00gltest.rpy:101
    old "Force ANGLE2 Renderer"
    new "Forza il renderer ANGLE2"

    # renpy/common/00gltest.rpy:106
    old "Force GLES2 Renderer"
    new "Forza il renderer GLES2"

    # renpy/common/00gltest.rpy:110
    old "Gamepad"
    new "Pannello di gioco"

    # renpy/common/00gltest.rpy:112
    old "Enable (No Blocklist)"
    new "Abilita (nessuna lista bloccata)"

    # renpy/common/00gltest.rpy:126
    old "Calibrate"
    new "Calibrare"

    # renpy/common/00gltest.rpy:135
    old "Powersave"
    new "Risparmio energetico"

    # renpy/common/00gltest.rpy:145
    old "Framerate"
    new "Frequenza fotogrammi"

    # renpy/common/00gltest.rpy:147
    old "Screen"
    new "Schermo"

    # renpy/common/00gltest.rpy:151
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:155
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:159
    old "Tearing"
    new "Strappo"

    # renpy/common/00gltest.rpy:171
    old "Changes will take effect the next time this program is run."
    new "Le modifiche avranno effetto alla successiva esecuzione del programma."

    # renpy/common/00gltest.rpy:178
    old "Quit"
    new "Esci"

    # renpy/common/00gltest.rpy:207
    old "Performance Warning"
    new "Avviso sulle prestazioni"

    # renpy/common/00gltest.rpy:212
    old "This computer is using software rendering."
    new "Questo computer utilizza il rendering software."

    # renpy/common/00gltest.rpy:214
    old "This game requires use of GL2 that can't be initialised."
    new "Questo gioco richiede l'uso di GL2 che non può essere inizializzato."

    # renpy/common/00gltest.rpy:216
    old "This computer has a problem displaying graphics: [problem]."
    new "Questo computer presenta un problema nella visualizzazione della grafica: [problem]."

    # renpy/common/00gltest.rpy:220
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "I suoi driver grafici potrebbero non essere aggiornati o non funzionare correttamente. Ciò può portare a una visualizzazione grafica lenta o errata."

    # renpy/common/00gltest.rpy:224
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "Il file {a=edit:1:log.txt}log.txt{/a} può contenere informazioni che ti aiutano a determinare cosa c'è che non va nel tuo computer."

    # renpy/common/00gltest.rpy:229
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Maggiori dettagli su come risolvere questo problema sono disponibili nella documentazione {a=[url]}{/a}."

    # renpy/common/00gltest.rpy:234
    old "Continue, Show this warning again"
    new "Continua, mostra di nuovo questo avviso"

    # renpy/common/00gltest.rpy:238
    old "Continue, Don't show warning again"
    new "Continua, non mostrare più l'avviso"

    # renpy/common/00gltest.rpy:246
    old "Change render options"
    new "Modifica le opzioni di rendering"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Seleziona il gamepad da calibrare"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "Nessun gamepad disponibile"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Calibrazione [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Premere o spostare '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Salta (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Indietro (B)"

    # renpy/common/_errorhandling.rpym:757
    old "Open"
    new "Aperto"

    # renpy/common/_errorhandling.rpym:759
    old "Opens the traceback.txt file in a text editor."
    new "Apre il file traceback.txt in un editor di testo."

    # renpy/common/_errorhandling.rpym:761
    old "Copy BBCode"
    new "Copia il BBCode"

    # renpy/common/_errorhandling.rpym:763
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia il file traceback.txt negli appunti come BBcode per forum come https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:765
    old "Copy Markdown"
    new "Copia Markdown"

    # renpy/common/_errorhandling.rpym:767
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia il file traceback.txt negli appunti come Markdown per Discord."

    # renpy/common/_errorhandling.rpym:799
    old "An exception has occurred."
    new "Si è verificata un'eccezione."

    # renpy/common/_errorhandling.rpym:828
    old "Rollback"
    new "Rollback"

    # renpy/common/_errorhandling.rpym:830
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Tenta di tornare a un momento precedente, consentendoti di salvare o scegliere una scelta diversa."

    # renpy/common/_errorhandling.rpym:833
    old "Ignore"
    new "Ignora"

    # renpy/common/_errorhandling.rpym:837
    old "Ignores the exception, allowing you to continue."
    new "Ignora l'eccezione, consentendoti di continuare."

    # renpy/common/_errorhandling.rpym:839
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora l'eccezione, consentendoti di continuare. Ciò porta spesso a ulteriori errori."

    # renpy/common/_errorhandling.rpym:843
    old "Reload"
    new "Ricarica"

    # renpy/common/_errorhandling.rpym:845
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Ricarica il gioco dal disco, salvando e ripristinando lo stato del gioco, se possibile."

    # renpy/common/_errorhandling.rpym:848
    old "Console"
    new "Consolle"

    # renpy/common/_errorhandling.rpym:850
    old "Opens a console to allow debugging the problem."
    new "Apre una console per consentire il debug del problema."

    # renpy/common/_errorhandling.rpym:863
    old "Quits the game."
    new "Esce dal gioco."

    # renpy/common/_errorhandling.rpym:885
    old "Parsing the script failed."
    new "L'analisi dello script non è riuscita."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
