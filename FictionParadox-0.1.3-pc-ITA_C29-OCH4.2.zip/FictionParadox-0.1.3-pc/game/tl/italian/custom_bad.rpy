translate italian strings:
# Files Created By Renpy Translate 2025 OneClick Version 2.3 Ultimate

    old "- [universe_slot.number] -"
    new "-[universe_slot.number]-"

    old "/color"
    new "/colore"

    old "3D animations: Lumen\n"
    new "Animazioni 3D: Lumen\n"

    old "3D art: Eón, Lumen\n"
    new "Arte 3D: Eón, Lumen\n"

    old "<silence .4>"
    new "<silenzio .4>"

    old "<silence 2.0>"
    new "<silenzio 2.0>"

    old "AS IS"
    new "COSÌ COM'È"

    old "All the characters in the story are fictional and over the age of 18. Any resemblance to real life people or events is entirely coincidental.\n"
    new "Tutti i personaggi della storia sono di fantasia e hanno più di 18 anni. Qualsiasi somiglianza con persone o eventi della vita reale è del tutto casuale.\n"

    old "Are you sure{#female}? This choice will be permanent."
    new "Sei sicuro{#female}? Questa scelta sarà permanente."

    old "Are you sure{#male}? This choice will be permanent."
    new "Sei sicuro{#male}? Questa scelta sarà permanente."

    old "Auto{#screen}"
    new "Automatico{#screen}"

    old "Back{#screen}"
    new "Indietro{#screen}"

    old "Book I - Chapter [current_game_slot.data.current_chapter]{#game-slot}"
    new "Libro I - Capitolo [current_game_slot.data.current_chapter]{#game-slot}"

    old "Book I - Chapter [game_slot.data.current_chapter]{#game-slot}"
    new "Libro I - Capitolo [game_slot.data.current_chapter]{#game-slot}"

    old "Designs: Eón, Lumen, Dakno\n"
    new "Disegni: Eón, Lumen, Dakno\n"

    old "Direction: Dakno\n"
    new "Direzione: Dakno\n"

    old "ENGLISH"
    new "INGLESE"

    old "ERROR!"
    new "ERRORE!"

    old "English"
    new "Inglese"

    old "Eón"
    new "Eone"

    old "Fiction Paradox"
    new "Paradosso della narrativa- ITA_Cep29 OneClick ULTIMATE"

    old "Koko Nomad"
    new "Koko Nomade"

    old "Licensing"
    new "Licenza"

    old "Lumen"
    new "Lume"

    old "Menu{#screen}"
    new "Menù{#screen}"

    old "Mithile AlitaRaia\nclaimant32\nApex Spectral\nCarlos\nTwisted Karma\nkriptosok"
    new "Mithile AlitaRaia\nrichiedente32\nApex Spectral\nCarlos\nKarma contorto\nkriptosok"

    old "Monetization"
    new "Monetizzazione"

    old "Monetize"
    new "Monetizzare"

    old "Programming: Dakno"
    new "Programmazione: Dakno"

    old "ROT"
    new "MARCIRE"

    old "Shift+A"
    new "Maiusc+A"

    old "Skip{#screen}"
    new "Salta{#screen}"

    old "Then, tell me again."
    new "Allora dimmelo ancora."

    old "This game contains explicit depictions of nudity, sex, violence and sensitive topics. By selecting CONTINUE, you certify that you meet the legal age of your jurisdiction to consume this kind of material.\n"
    new "Questo gioco contiene rappresentazioni esplicite di nudità, sesso, violenza e argomenti delicati. Selezionando CONTINUA, confermi di soddisfare l'età legale prevista dalla tua giurisdizione per consumare questo tipo di materiale.\n"

    old "True"
    new "VERO"

    old "Writing: Dakno\n"
    new "Scrittura: Dakno\n"

    old "Yes, I like men{#q: Is this the body you are most attracted to?}"
    new "Sì, mi piacciono gli uomini{#q: Is this the body you are most attracted to?}"

    old "Yes, I like women{#q: Is this the body you are most attracted to?}"
    new "Sì, mi piacciono le donne{#q: Is this the body you are most attracted to?}"

    old "\n[renpy.license!t]\n\n\n"
    new "\n [renpy.license!t] \n \n \n"

    old "{a=https://discord.com/invite/XuZHYQxVd3}{color=#ff81d5}DISCORD{/color}{/a}\n"
    new "{a=https://discord.com/invite/XuZHYQxVd3}{color=#ff81d5}DISCORDA{/color}{/a}\n"

    old "{a=https://store.steampowered.com/app/4058160/Fiction_Paradox__Chapter_1/}{color=#ff81d5}STEAM{/color}{/a}\n"
    new "{a=https://store.steampowered.com/app/4058160/Fiction_Paradox__Chapter_1/}{color=#ff81d5}VAPORE{/color}{/a}\n"

    old "{a=https://subscribestar.adult/naventu}{color=#ff81d5}SUBSCRIBESTAR ADULT{/color}{/a}\n"
    new "{a=https://subscribestar.adult/naventu}{color=#ff81d5}ISCRIVITISTAR ADULTO{/color}{/a}\n"

    old "{a=https://subscribestar.adult/naventu}{color=#ff81d5}SUBSCRIBESTAR{/color}{/a}{#end-of-release-0.1}"
    new "{a=https://subscribestar.adult/naventu}{color=#ff81d5}ISCRIVITISTAR{/color}{/a}{#end-of-release-0.1}"

# Created By Bad75 Renpy Translate 2025#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
