﻿
translate italian strings:

    # game/characters/main/tt.rpy:25
    old "1.61 m{#height}"
    new "1,61 mt{#height}"

    # game/characters/main/tt.rpy:28
    old "Tashia{#character}"
    new "Tashia{#character}"

    # game/characters/main/tt.rpy:31
    old "50 kg{#weight}"
    new "50 kg{#weight}"

    # game/characters/main/tt.rpy:36
    old "1.79 m{#height}"
    new "1,79 mt{#height}"

    # game/characters/main/tt.rpy:39
    old "Taiwo{#character}"
    new "Taiwo{#character}"

    # game/characters/main/tt.rpy:42
    old "75 kg{#weight}"
    new "75 kg{#weight}"

    # game/characters/main/tt.rpy:47
    old "Nigeria{#country}"
    new "Nigeria{#country}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
