﻿
translate italian strings:

    # game/characters/main/ll.rpy:26
    old "1.59 m{#height}"
    new "1,59 mt{#height}"

    # game/characters/main/ll.rpy:29
    old "Lu{#character}"
    new "Lu{#character}"

    # game/characters/main/ll.rpy:32
    old "52 kg{#weight}"
    new "52 kg{#weight}"

    # game/characters/main/ll.rpy:37
    old "1.72 m{#height}"
    new "1,72 mt{#height}"

    # game/characters/main/ll.rpy:40
    old "Ling{#character}"
    new "Ling{#character}"

    # game/characters/main/ll.rpy:43
    old "73 kg{#weight}"
    new "73 kg{#weight}"

    # game/characters/main/ll.rpy:48
    old "China{#country}"
    new "Cina{#country}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
