﻿
translate italian strings:

    # game/characters/main/dd.rpy:26
    old "1.71 m{#height}"
    new "1,71 mt{#height}"

    # game/characters/main/dd.rpy:29
    old "Diana{#character}"
    new "Diana{#character}"

    # game/characters/main/dd.rpy:32
    old "66 kg{#weight}"
    new "66 kg{#weight}"

    # game/characters/main/dd.rpy:37
    old "1.81 m{#height}"
    new "1,81 mt{#height}"

    # game/characters/main/dd.rpy:40
    old "Daniel{#character}"
    new "Daniel{#character}"

    # game/characters/main/dd.rpy:43
    old "77 kg{#weight}"
    new "77 kg{#weight}"

    # game/characters/main/dd.rpy:48
    old "Argentina{#country}"
    new "Argentina{#country}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
