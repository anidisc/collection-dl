﻿
translate italian strings:

    # game/characters/main/mc.rpy:36
    old "Waker{#character}"
    new "Waker{#character}"

    # game/characters/main/mc.rpy:41
    old "Evelyn{#character}"
    new "Evelyn{#character}"

    # game/characters/main/mc.rpy:44
    old "1.65 m{#height}"
    new "1,65 mt{#height}"

    # game/characters/main/mc.rpy:47
    old "48 kg{#weight}"
    new "48 kg{#weight}"

    # game/characters/main/mc.rpy:50
    old "55 kg{#weight}"
    new "55 kg{#weight}"

    # game/characters/main/mc.rpy:55
    old "Evan{#character}"
    new "Evan{#character}"

    # game/characters/main/mc.rpy:58
    old "1.75 m{#height}"
    new "1,75 mt{#height}"

    # game/characters/main/mc.rpy:61
    old "58 kg{#weight}"
    new "58 kg{#weight}"

    # game/characters/main/mc.rpy:64
    old "71 kg{#weight}"
    new "71 kg{#weight}"

    # game/characters/main/mc.rpy:69
    old "Canada{#country}"
    new "Canada{#country}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
