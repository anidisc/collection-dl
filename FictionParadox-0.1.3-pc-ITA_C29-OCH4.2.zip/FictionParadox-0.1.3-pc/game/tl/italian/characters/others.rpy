﻿
translate italian strings:

    # game/characters/others.rpy:2
    old "???{#character}"
    new "???{#character}"

    # game/characters/others.rpy:4
    old "System{#character}"
    new "Sistema{#character}"

    # game/characters/others.rpy:11
    old "Narrator{#character}"
    new "Narratore{#character}"

    # game/characters/others.rpy:18
    old "Voice of the Abyss{#character}"
    new "La voce dell'Abisso{#character}"

    # game/characters/others.rpy:20
    old "Humanoid{#character}"
    new "Umanoide{#character}"

    # game/characters/others.rpy:24
    old "Civic Assistant{#character}"
    new "Assistente civico{#character}"

    # game/characters/others.rpy:28
    old "Michael{#character}"
    new "Michael{#character}"

    # game/characters/others.rpy:29
    old "Bong{#character}"
    new "Bong{#character}"

    # game/characters/others.rpy:31
    old "Telegrim{#character}"
    new "Telegrim{#character}"

    # game/characters/others.rpy:36
    old "Customer{#male}{#character}"
    new "Cliente{#male}{#character}"

    # game/characters/others.rpy:40
    old "Customer{#female}{#character}"
    new "Cliente{#female}{#character}"

    # game/characters/others.rpy:45
    old "Voice from video{#character}"
    new "Voce dal video{#character}"

    # game/characters/others.rpy:46
    old "Phone{#character}"
    new "Telefono{#character}"

    # game/characters/others.rpy:47
    old "Phone's assistant{#character}"
    new "Assistente telefonico{#character}"

    # game/characters/others.rpy:50
    old "Fan{#female}{#character}"
    new "Fan{#female}{#character}"

    # game/characters/others.rpy:53
    old "Fan{#male}{#character}"
    new "Fan{#male}{#character}"

    # game/characters/others.rpy:57
    old "DJ{#character}"
    new "DJ{#character}"

    # game/characters/others.rpy:58
    old "Crowd{#audience}{#character}"
    new "Folla{#audience}{#character}"

    # game/characters/others.rpy:60
    old "Hairdresser{#female}{#character}"
    new "Parrucchiere{#female}{#character}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
