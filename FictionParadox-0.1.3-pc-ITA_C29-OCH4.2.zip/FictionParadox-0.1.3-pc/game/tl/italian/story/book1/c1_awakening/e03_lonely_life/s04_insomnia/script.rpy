﻿
# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:77
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e2ccd8d4:

    # phone "{act}notification{/act}" with dis_std
    phone "{act}notifica{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:78
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_0e227213:

    # mc_t "Okay, “order confirmed”. Arrives tomorrow."
    mc_t "Ok, “ordine confermato”. Arriva domani."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:79
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_753f8967:

    # mc_t "It's too easy to spend money on things you don't even understand, haha."
    mc_t "È troppo facile spendere soldi per cose che non capisci nemmeno, ahah."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:80
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_59a20807:

    # mc_t "Anyway..."
    mc_t "Comunque..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:81
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2b5ae043:

    # mc_t "Let's take a look at social media."
    mc_t "Diamo uno sguardo ai social media."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:84
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_1a9a60ec:

    # mc "{act}opens an app{/act}"
    mc "{act}apre un'app{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:88
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_322a2b7b:

    # video_voice "The sky itself falls upon us..."
    video_voice "Il cielo stesso cade su di noi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:89
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_0c070379:

    # video_voice "It's now or never! The fate of the world is in your{#plural} hands!"
    video_voice "È ora o mai più! Il destino del mondo è nelle tue{#plural} mani!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:92
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_ea3fe4c6:

    # video_voice "NEW ZONE: Storm Islands"
    video_voice "NUOVA ZONA: Isole Tempesta"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:95
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_30f9d4ea:

    # video_voice "NEW DUNGEON: The Death Tunnels"
    video_voice "NUOVO DUNGEON: I Tunnel della Morte"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:98
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9b3c0f1e:

    # video_voice "NEW RAID: Skycrown Citadel"
    video_voice "NUOVO RAID: Cittadella della Corona Celeste"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:100
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_bc87b97c:

    # video_voice "Turtelion Online, Patch 17.3: Fractures of Eternity. Subscribe now!"
    video_voice "Turtelion Online, patch 17.3: Fratture dell'eternità. Iscriviti ora!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:105
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:108
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_21e7a900:

    # phone "{act}eccentric piano music{/act}"
    phone "{act}musica per pianoforte eccentrica{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:109
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_649925d8:

    # mc_t "Not bad."
    mc_t "Non male."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:113
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_1:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:116
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77248e04:

    # phone "{act}electric toothbrush running{/act}"
    phone "{act}spazzolino elettrico in funzione{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:117
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4fb854a0:

    # mc_t "2 million views!? It's just a girl brushing her teeth!"
    mc_t "2 milioni di visualizzazioni!? È solo una ragazza che si lava i denti!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:118
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9a40cf84:

    # mc_t "She's cute, though..."
    mc_t "È carina, però..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:119
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_10e580f6:

    # mc_t "I guess that's the reason."
    mc_t "Immagino che sia questo il motivo."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:123
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_2:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:128
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_de9dd97c:

    # video_voice "{act}sensual voice{/act} Do you want to have sex like a pro{#female}?"
    video_voice "{act}voce sensuale{/act} Vuoi fare sesso come un professionista{#female}?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:130
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_f116e81b:

    # video_voice "{act}sensual voice{/act} Do you want to have sex like a pro{#male}?"
    video_voice "{act}voce sensuale{/act} Vuoi fare sesso come un professionista{#male}?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:131
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d1c6f9d2:

    # video_voice "THEN WAIT! Don't close this video!"
    video_voice "ALLORA ASPETTA! Non chiudere questo video!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:132
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d9f302e0:

    # video_voice "Click on the link in the description below, and sign up for our advanced Kamasutra course!"
    video_voice "Clicca sul link nella descrizione qui sotto e iscriviti al nostro corso avanzato di Kamasutra!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:136
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_3:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:139
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c58d8b96:

    # phone "{act}demonstration sounds{/act}"
    phone "{act}suoni dimostrativi{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:140
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_7f9deaeb:

    # mc_t "Where is this? Brazil?"
    mc_t "Dov'è questo? Brasile?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:141
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_75f486a6:

    # mc_t "I think they're talking about the Amazon..."
    mc_t "Penso che stiano parlando dell'Amazzonia..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:146
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_4:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:149
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_475611f5:

    # video_voice "{act}unintelligible sounds{/act}"
    video_voice "{act}suoni incomprensibili{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:150
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:154
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_5:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:158
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e0704a83:

    # mc_t "Hmm? What's this?"
    mc_t "Ehm? Che cos'è questo?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:159
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_fde81845:

    # mc_t "I think it's a countdown for a... live concert, maybe?"
    mc_t "Penso che sia il conto alla rovescia per un... concerto dal vivo, forse?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:162
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2379ea80:

    # mc_t "Yeah, it is." with dis_std_med
    mc_t "Sì, lo è." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:164
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4369714f:

    # mc_t "The place isn't big, but there's a lot of hype in the chat..."
    mc_t "Il posto non è grande, ma c'è parecchia pubblicità nella chat..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:166
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_16cf30c7:

    # mc_t "Now I'm curious{#female}."
    mc_t "Adesso sono curioso{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:168
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_1ffc2548:

    # mc_t "Now I'm curious{#male}."
    mc_t "Adesso sono curioso{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:173
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2bd0f774:

    # mc_t "Ohhh, I think I know her!" with dis_std_med
    mc_t "Ohhh, penso di conoscerla!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:174
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_5eec99f3:

    # mc_t "She's a famous streamer{#female}, although I don't remember her name right now."
    mc_t "È una famosa streamer{#female}, anche se al momento non ricordo il suo nome."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:176
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_07c88e17:

    # mc_t "Ohhh, I think I know him!" with dis_std_med
    mc_t "Ohhh, penso di conoscerlo!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:177
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_01007001:

    # mc_t "He's a famous streamer{#male}, although I don't remember his name right now."
    mc_t "È uno streamer famoso{#male}, anche se al momento non ricordo il suo nome."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:184
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b8cd524a:

    # dj_party "Aaaaand the moment you've all been waiting for..." with dis_std_biglong
    dj_party "Aaaae il momento che tutti stavate aspettando..." with dis_std_biglong

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:186
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d7ac1e1c:

    # dj_party "Let's give an electrifying welcome to..."
    dj_party "Diamo un elettrizzante benvenuto a..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:187
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_72b218df:

    # dj_party "{sc=1.3}{size=*1.6}[tt.name!u]!!!{/size}{/sc}"
    dj_party "{sc=1.3}{size=*1.6}[tt.name!u]!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:190
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3eb56e71:

    # crowd_audience "{act}cheering{/act}"
    crowd_audience "{act}tifo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:193
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3d92555a:

    # tt "Thank you, thank you~!"
    tt "Grazie, grazie~!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:195
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e2980424:

    # tt "Thank you, thank you!"
    tt "Grazie, grazie!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:196
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_30e55b37:

    # tt "What an enthusiastic audience! That's how I like it!"
    tt "Che pubblico entusiasta! È così che mi piace!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:198
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d253edf1:

    # female_fan2 "{act}yelling{/act} {sc=1.3}You're the best{#female}!{/sc}"
    female_fan2 "{act}urla{/act} {sc=1.3}Sei il migliore{#female}!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:200
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_0961a636:

    # female_fan2 "{act}yelling{/act} {sc=1.3}You're the best{#male}!{/sc}"
    female_fan2 "{act}urla{/act} {sc=1.3}Sei il migliore{#male}!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:205
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4d545aac:

    # tt "Mm-hm~" with dis_std_med
    tt "Mm-hm~" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:207
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b44df0ba:

    # crowd_audience "{act}yelling{/act} {sc=1.3}AAAHHHHHHH!!!{/sc}"
    crowd_audience "{act}urla{/act} {sc=1.3}AAAHHHHHHH!!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:208
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_08f23be1:

    # female_fan1 "{act}yelling{/act} {sc=1.3}SHE DID HER POSE!{/sc}"
    female_fan1 "{act}urla{/act} {sc=1.3}HA FATTO LA SUA POSA!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:209
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e4f781d4:

    # female_fan2 "{act}yelling{/act} {sc=1.3}I'M DYING!{/sc}"
    female_fan2 "{act}urla{/act} {sc=1.3}STO MORENDO!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:210
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c952dd6d:

    # female_fan3 "{act}yelling{/act} {sc=1.3}[tt.name!u], WE LOVE YOU!!!{/sc}"
    female_fan3 "{act}urla{/act} {sc=1.3}[tt.name!u], TI VOGLIAMO BENE!!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:217
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_36cb1a97:

    # tt "Who's up for a good show!?"
    tt "Chi ha voglia di un bello spettacolo!?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:218
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_51b4bbb0:

    # crowd_audience "{act}yelling{/act} {sc=1.3}WE ARE!!!{/sc}"
    crowd_audience "{act}urla{/act} {sc=1.3}NOI SIAMO!!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:219
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_27730403:

    # tt "Let's begin then~!"
    tt "Cominciamo allora~!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:227
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_51441169:

    # mc "{act}stops the video{/act}"
    mc "{act}interrompe il video{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:228
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c3609add:

    # mc_t "I don't feel like listening to music right now."
    mc_t "Non ho voglia di ascoltare musica in questo momento."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:229
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e4d5c805:

    # mc_t "I think I should... Uh..."
    mc_t "Penso che dovrei... Uh..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:242
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_53d5da9e:

    # mc_t "Hmm, let's see..." with dis_std
    mc_t "Hmm, vediamo..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:244
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_5c128b64:

    # mc "{act}reading{/act} {think}[tt.name!t] Oluwaseun... Streamer{#female}, singer{#female}, actress...{/think}"
    mc "{act}lettura{/act} {think}[tt.name!t] Oluwaseun... Streamer{#female}, cantante{#female}, attrice...{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:245
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_fe2685d0:

    # mc_t "Wow, so versatile{#female}."
    mc_t "Wow, così versatile{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:247
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_f4a535d2:

    # mc "{act}reading{/act} {think}[tt.name!t] Oluwaseun... Streamer{#male}, singer{#male}, actor...{/think}"
    mc "{act}lettura{/act} {think}[tt.name!t] Oluwaseun... Streamer{#male}, cantante{#male}, attore...{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:248
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_44fd8daa:

    # mc_t "Wow, so versatile{#male}."
    mc_t "Wow, così versatile{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:251
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_783a6c28:

    # mc "{act}types on her profile image{/act}"
    mc "{act}digita sulla sua immagine del profilo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:257
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_23bd412f:

    # mc_t "W-What is this?" with dis_std
    mc_t "W-Cos'è questo?" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:258
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9cebabf0:

    # mc_t "Did I end up on a fan account? Must be made with AI or something..."
    mc_t "Sono finito su un account fan? Deve essere realizzato con l'intelligenza artificiale o qualcosa del genere..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:259
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_f6b88aa7:

    # mc "{act}keeps reading{/act}"
    mc "{act}continua a leggere{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:263
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_7516ca43:

    # mc_t "No, it's her official account!"
    mc_t "No, è il suo account ufficiale!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:265
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_678e720b:

    # mc_t "This was a promotion for virtual glasses, b-but..."
    mc_t "Questa era una promozione per gli occhiali virtuali, ma..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:267
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_678e720b_1:

    # mc_t "This was a promotion for virtual glasses, b-but..."
    mc_t "Questa era una promozione per gli occhiali virtuali, ma..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:271
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b54c2e4a:

    # mc_t "Who would think of doing it like that!?"
    mc_t "Chi penserebbe di farlo in quel modo!?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:272
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2e3814ea:

    # mc_t "Hot daaaamn!"
    mc_t "Che caldo!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:273
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_71c2bd18:

    # mc_t "More than 3 million likes! The marketing psychopaths at the glasses' company must be delighted."
    mc_t "Più di 3 milioni di Mi piace! Gli psicopatici del marketing dell'azienda di occhiali devono essere contentissimi."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:276
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6cdf2757:

    # mc_t "Sweet baby Jesus..." with dis_std_med
    mc_t "Dolce Gesù Bambino..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:277
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_27b2399a:

    # mc_t "Oh, wait, there's another photo!"
    mc_t "Oh, aspetta, c'è un'altra foto!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:282
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d3f8160d:

    # mc_t "Oh my god..."
    mc_t "Oh mio Dio..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:285
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6caa0ce2:

    # mc_t "I didn't know she had so many freckles. She's adorable!"
    mc_t "Non sapevo avesse così tante lentiggini. È adorabile!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:286
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_5399ecca:

    # mc_t "And that neckline is very dangerous..."
    mc_t "E quella scollatura è molto pericolosa..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:288
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_610a7576:

    # mc_t "I didn't know he had so many freckles. He's adorable!"
    mc_t "Non sapevo avesse così tante lentiggini. È adorabile!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:289
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_a139555c:

    # mc_t "And those pecs are very dangerous..."
    mc_t "E quei pettorali sono molto pericolosi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:293
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_210de7bb:

    # mc_t "What's hidden there must be tastier than the sweetest chocolate. I'm 100%% sure{#female}."
    mc_t "Ciò che è nascosto lì deve essere più gustoso del cioccolato più dolce. Sono sicuro al 100%%{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:295
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_64c2979a:

    # mc_t "What's hidden there must be tastier than the sweetest chocolate. I'm 100%% sure{#male}."
    mc_t "Ciò che è nascosto lì deve essere più gustoso del cioccolato più dolce. Sono sicuro al 100%%{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:300
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_bbc0f071:

    # mc_t "S-Shit, it's 3 a.m.!"
    mc_t "S-Merda, sono le 3 del mattino!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:303
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_ade1abae:

    # mc_t "It's very late, but... I can't stop watching!"
    mc_t "È molto tardi, ma... non riesco a smettere di guardare!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:306
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77c41473_6:

    # mc "{act}swipes screen{/act}"
    mc "{act}fa scorrere lo schermo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:309
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_118e1b45:

    # mc_t "Ohhh god..." with dis_std_med
    mc_t "Ohhh Dio..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:312
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d60aee6a:

    # mc_t "A kitty{#female} costume? How playful{#female}..."
    mc_t "Un costume da gattino{#female}? Che giocoso{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:313
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_84483536:

    # mc_t "This girl loves being the center of attention, that's for sure."
    mc_t "Questa ragazza ama essere al centro dell'attenzione, questo è certo."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:315
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9d0b40ee:

    # mc_t "A kitty{#male} costume? How playful{#male}..."
    mc_t "Un costume da gattino{#male}? Che giocoso{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:316
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6c10b6e0:

    # mc_t "This boy loves being the center of attention, that's for sure."
    mc_t "Questo ragazzo ama essere al centro dell'attenzione, questo è certo."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:319
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b4e78f8b:

    # mc_t "Look at that little innocent smile..." with dis_std_med
    mc_t "Guarda quel sorrisetto innocente..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:321
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_45c7cb6c:

    # mc_t "Did the kitty{#female} sleep well today? Hmmmm~?"
    mc_t "Il gattino{#female} ha dormito bene oggi? Hmmmm~?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:323
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d5e78ebf:

    # mc_t "Did the kitty{#male} sleep well today? Hmmmm~?"
    mc_t "Il gattino{#male} ha dormito bene oggi? Hmmmm~?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:329
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_adfb5f23:

    # mc_t "What a bad girl..."
    mc_t "Che cattiva ragazza..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:330
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4c5967ff:

    # mc_t "The little actress likes to play roles, huh?"
    mc_t "Alla piccola attrice piace recitare, eh?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:332
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6109119b:

    # mc_t "What a bad boy..."
    mc_t "Che cattivo ragazzo..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:333
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_12c7a4b9:

    # mc_t "The little actor likes to play roles, huh?"
    mc_t "Al piccolo attore piace recitare dei ruoli, eh?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:334
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c960f537:

    # mc_t "If your intention was to provoke, you're definitely succeeding!"
    mc_t "Se la tua intenzione era provocare, ci sei sicuramente riuscito!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:340
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d8b8bf62:

    # mc_t "My god, what a queen..."
    mc_t "Mio Dio, che regina..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:342
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_bf4449e9:

    # mc_t "My god, what a king..."
    mc_t "Mio Dio, che re..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:343
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_fb4c3dfe:

    # mc_t "Your eyes are killing me! It's like they're saying: “Do you like what you see~?”"
    mc_t "I tuoi occhi mi stanno uccidendo! È come se dicessero: 'Ti piace quello che vedi~?'"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:344
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_26f58a96:

    # mc_t "And fuck yes, I like what I'm seeing!"
    mc_t "E cazzo sì, mi piace quello che vedo!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:349
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_7d903c47:

    # mc_t "HOOOOLY SHIT!"
    mc_t "MERDA!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:351
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b034185e:

    # mc_t "How can you be so sensual{#female}!?"
    mc_t "Come puoi essere così sensuale{#female}!?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:352
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_633ca4cf:

    # mc_t "Damn{#female} you, [tt.name!t]! Must be difficult to satisfy someone who flies that high..."
    mc_t "Maledizione a {#female}, [tt.name!t]! Deve essere difficile soddisfare qualcuno che vola così in alto..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:354
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_eb1f7ec8:

    # mc_t "How can you be so sensual{#male}!?"
    mc_t "Come puoi essere così sensuale{#male}!?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:355
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9be06594:

    # mc_t "Damn{#male} you, [tt.name!t]! Must be difficult to satisfy someone who flies that high..."
    mc_t "Maledizione a {#male}, [tt.name!t]! Deve essere difficile soddisfare qualcuno che vola così in alto..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:356
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_1b2569e2:

    # mc_t "Hmm?"
    mc_t "Ehm?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:357
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b12125e9:

    # mc_t "What do you say? Me?"
    mc_t "Che ne dici? Me?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:358
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4e0e383d:

    # mc_t "Oh, don't worry! I know {i}exactly{/i} what to do."
    mc_t "Oh, non preoccuparti! So {i}esattamente{/i} cosa fare."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:365
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b371e43c:

    # mc "{act}turning screen off{/act} {think}Sleep.{/think}"
    mc "{act}spegnimento dello schermo{/act} {think}Sonno.{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:367
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e3525547:

    # mc_t "It's very late... I better go to sleep."
    mc_t "È molto tardi... sarà meglio che vada a dormire."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:374
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_a0e6d310:

    # mc "{act}turning screen off{/act}" with dis_std
    mc "{act}spegnimento dello schermo{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:377
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_14a9bfcd:

    # mc_t "Yeah, I should sleep." with dis_std
    mc_t "Sì, dovrei dormire." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:381
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c594cc5b:

    # mc "{act}turning screen off{/act} {think}Enough phone for today.{/think}" with dis_std
    mc "{act}spegnimento dello schermo{/act} {think}Basta telefono per oggi.{/think}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:385
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_92985156:

    # mc_t "I need to be well-rested{#female} for tomorrow." with dis_std_med
    mc_t "Ho bisogno di riposarmi bene{#female} per domani." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:387
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4f0a8dd6:

    # mc_t "I need to be well-rested{#male} for tomorrow." with dis_std_med
    mc_t "Ho bisogno di riposarmi bene{#male} per domani." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:389
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_20aea102:

    # mc_t "Relax, [mc.name!t]..."
    mc_t "Rilassati, [mc.name!t]..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:390
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_7ec26be2:

    # mc_t "Think about nice things..."
    mc_t "Pensa alle cose belle..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:393
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4513b803:

    # mc "{act}blushing{/act}" with dis_std
    mc "{act}arrossire{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:394
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4452fc44:

    # mc_t "[dd.name!t]..."
    mc_t "[dd.name!t]..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:396
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_8d500946:

    # mc_t "[ll.name!t]..."
    mc_t "[ll.name!t]..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:398
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_ea5c4943:

    # mc_t "[tt.name!t]..."
    mc_t "[tt.name!t]..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:415
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:417
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_58c88ea4:

    # mc_t "I can't sleep, I'm too horny{#female}..."
    mc_t "Non riesco a dormire, sono troppo arrapato{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:419
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_cc4c45ca:

    # mc_t "I can't sleep, I'm too horny{#male}..."
    mc_t "Non riesco a dormire, sono troppo arrapato{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:422
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2e75b284:

    # mc_t "I can't sleep, I'm too horny{#female}..." with dis_std
    mc_t "Non riesco a dormire, sono troppo arrapato{#female}..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:424
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_891b6436:

    # mc_t "I can't sleep, I'm too horny{#male}..." with dis_std
    mc_t "Non riesco a dormire, sono troppo arrapato{#male}..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:438
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_415c4a3a:

    # mc "{act}taking off your pajamas{/act}" with dis_std
    mc "{act}toglierti il pigiama{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:442
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e29a6398:

    # mc_t "[dd.name!t]..." with dis_std_med
    mc_t "[dd.name!t]..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:444
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_2a970783:

    # mc_t "You looked gorgeous{#female} today..."
    mc_t "Eri bellissima{#female} oggi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:446
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_fd617247:

    # mc_t "You looked gorgeous{#male} today..."
    mc_t "Eri bellissima{#male} oggi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:449
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_041ba1e9:

    # mc_t "[ll.name!t]..." with dis_std_med
    mc_t "[ll.name!t]..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:451
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_fed43fb6:

    # mc_t "You looked so cool{#female} today..."
    mc_t "Eri così bello{#female} oggi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:453
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_a86273b8:

    # mc_t "You looked so cool{#male} today..."
    mc_t "Eri così bello{#male} oggi..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:456
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_57f7faed:

    # mc_t "[tt.name!t]..." with dis_std_med
    mc_t "[tt.name!t]..." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:458
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c41bda1b:

    # mc_t "You're such a cutie{#female}..."
    mc_t "Sei così carino{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:460
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_e7cc5255:

    # mc_t "You're such a cutie{#male}..."
    mc_t "Sei così carino{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:484
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_4bac4db1:

    # mc "{act}playing with your lips{/act}" with dis_std_med
    mc "{act}giocare con le labbra{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:486
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_eee9d723:

    # mc "{act}stroking your cock{/act}" with dis_std_med
    mc "{act}accarezzandoti il cazzo{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:488
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_ffa62260:

    # mc "Ahhh..."
    mc "Ahhh..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:490
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_bbca7cd6:

    # mc_t "Fuck, you make me so wet..."
    mc_t "Cavolo, mi fai bagnare così tanto..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:491
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_8f448a76:

    # mc_t "I couldn't stop looking at you. It's your fault for being so hot{#female}, alright?"
    mc_t "Non potevo smettere di guardarti. È colpa tua se sei così sexy{#female}, va bene?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:493
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6813ca84:

    # mc_t "Fuck, you make me so hard..."
    mc_t "Cavolo, mi rendi così duro..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:494
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d8e71e92:

    # mc_t "I couldn't stop looking at you. It's your fault for being so hot{#male}, alright?"
    mc_t "Non potevo smettere di guardarti. È colpa tua se sei così sexy{#male}, va bene?"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:495
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_053fc05b:

    # mc_t "God, you're amazing..."
    mc_t "Dio, sei fantastico..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:496
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_58405043:

    # mc "Ahhhhhh..."
    mc "Ahhhhhh..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:497
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_b1c83b1a:

    # mc_t "Yes..."
    mc_t "Sì..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:500
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_1290f735:

    # mc_t "Ohhh, yes!" with dis_std_med
    mc_t "Ohhh, sì!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:511
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3c8a8ef4:

    # mc_t "That curious look on your face...!" with dis_std_med
    mc_t "Quello sguardo curioso sul tuo viso...!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:514
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_6877e954:

    # mc_t "That angry little face while you blush...!" with dis_std_med
    mc_t "Quella faccina arrabbiata mentre arrossisci...!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:518
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3e1c4f82:

    # mc_t "I love that you're so playful{#female}...!" with dis_std_med
    mc_t "Adoro il fatto che sei così giocoso{#female}...!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:520
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_8141b8fc:

    # mc_t "I love that you're so playful{#male}...!" with dis_std_med
    mc_t "Adoro il fatto che sei così giocoso{#male}...!" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:548
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_7b5d3446:

    # mc "{act}playing with your clitoris{/act}" with dis_std_med
    mc "{act}giocare con il clitoride{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:549
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_762b5679:

    # mc_t "It drives me CRAZY{#female}!"
    mc_t "Mi fa impazzire{#female}!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:551
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_13274cb9:

    # mc "{act}jerking off hard{/act}" with dis_std_med
    mc "{act}sega violenta{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:552
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_d2e89c02:

    # mc_t "It drives me CRAZY{#male}!"
    mc_t "Mi fa impazzire{#male}!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:554
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3d9a909a:

    # mc_t "Yes... Keep looking at me like that..."
    mc_t "Sì... Continua a guardarmi così..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:555
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_3ce1f5ac:

    # mc "{sc=1.3}Ahhh...{/sc}{w} {sc=1.3}Ahhhhh...!{/sc}{w} {sc=1.3}AHHHH...!!{/sc}"
    mc "{sc=1.3}Ahhh...{/sc}{w} {sc=1.3}Ahhhhh...!{/sc}{w} {sc=1.3}AHHHH...!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:558
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_5abb8987:

    # mc_t "Oh my fucking god, [dd.name!t]!"
    mc_t "Oh mio Dio, [dd.name!t]!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:560
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_77f24570:

    # mc_t "Oh my fucking god, [ll.name!t]!"
    mc_t "Oh mio Dio, [ll.name!t]!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:562
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_1d790cc9:

    # mc_t "Oh my fucking god, [tt.name!t]!"
    mc_t "Oh mio Dio, [tt.name!t]!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:563
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_06e4fe5f:

    # mc_t "I'M CUMMING..."
    mc_t "STO VENENDO..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:573
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_8acae21b:

    # mc "Mmmmm~!"
    mc "Mmmmm~!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:575
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_938a3904:

    # mc "Hnnng!"
    mc "Hnnng!"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:589
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_a14802fd:

    # mc "{sc=1.3}{size=*1.2}AHHH!{/size}{/sc}"
    mc "{sc=1.3}{size=*1.2}AHHH!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:591
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_294651a4:

    # mc "{sc=1.3}{size=*1.2}GAHH!{/size}{/sc}"
    mc "{sc=1.3}{size=*1.2}GAHH!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:605
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_faa3f486:

    # mc "{sc=1.3}{size=*1.2}AAAHHHHH~!{/size}{/sc}"
    mc "{sc=1.3}{size=*1.2}AAAHHHHH~!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:607
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_5f8089a4:

    # mc "{sc=1.3}{size=*1.2}AAGGGHH!{/size}{/sc}"
    mc "{sc=1.3}{size=*1.2}AAGGGHH!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:625
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_297b4676:

    # mc "{act}panting{/act}" with dis_std_med
    mc "{act}ansimando{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:626
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_8c25cc6d:

    # mc "God..."
    mc "Dio..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:627
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_299f6a80:

    # mc "I needed this..."
    mc "Avevo bisogno di questo..."

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:630
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_088154be:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:631
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_38d83699:

    # mc "What a mess..."
    mc "Che caos..."

translate italian strings:

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:234
    old "{#BOND-CORRECT}Check her social media{#chapter1x1-choice08}"
    new "{#BOND-CORRECT}Controlla i suoi social media{#chapter1x1-choice08}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:236
    old "{#BOND-CORRECT}Check his social media{#chapter1x1-choice08}"
    new "{#BOND-CORRECT}Controlla i suoi social media{#chapter1x1-choice08}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:238
    old "Try to sleep{#chapter1x1-choice08}"
    new "Prova a dormire{#chapter1x1-choice08}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:404
    old "{#BOND-CORRECT}Jerk off{#chapter1x1-choice09}"
    new "{#BOND-CORRECT}Sega{#chapter1x1-choice09}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:406
    old "{#BOND-CORRECT}Touch myself{#female}{#chapter1x1-choice09}"
    new "{#BOND-CORRECT}Toccami{#female}{#chapter1x1-choice09}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:408
    old "Sleep{#chapter1x1-choice09}"
    new "Sonno{#chapter1x1-choice09}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:429
    old "Think about [dd.name!t]{#chapter1x1-choice10}"
    new "Pensa a [dd.name!t]{#chapter1x1-choice10}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:431
    old "Think about [ll.name!t]{#chapter1x1-choice10}"
    new "Pensa a [ll.name!t]{#chapter1x1-choice10}"

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:433
    old "Think about [tt.name!t]{#chapter1x1-choice10}"
    new "Pensa a [tt.name!t]{#chapter1x1-choice10}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:187
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_c5306dc5:

    # dj_party "{sc=1.3}{size=*1.6}[tt.name!tu]!!!{/size}{/sc}"
    dj_party "{sc=1.3}{size=*1.6}[tt.name!tu]!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:211
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9b541312:

    # female_fan1 "{act}yelling{/act} {sc=1.3}HE DID HIS POSE!{/sc}"
    female_fan1 "{act}urla{/act} {sc=1.3}HA FATTO LA SUA POSA!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:213
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_edd9e9fe:

    # female_fan3 "{act}yelling{/act} {sc=1.3}[tt.name!tu], WE LOVE YOU!!!{/sc}"
    female_fan3 "{act}urlando{/act} {sc=1.3}[tt.name!tu], TI VOGLIAMO BENE!!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:257
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_9528cec2:

    # mc "{act}types on his profile image{/act}"
    mc "{act}digita sulla sua immagine del profilo{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:574
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_a4805b87:

    # mc_t "I'M CUMMING...{#female}"
    mc_t "STO VENENDO...{#female}"

# game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/script.rpy:576
translate italian scene__book1__c1_awakening__e03_lonely_life__s04_insomnia_abaa498c:

    # mc_t "I'M CUMMING...{#male}"
    mc_t "STO VENENDO...{#male}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
