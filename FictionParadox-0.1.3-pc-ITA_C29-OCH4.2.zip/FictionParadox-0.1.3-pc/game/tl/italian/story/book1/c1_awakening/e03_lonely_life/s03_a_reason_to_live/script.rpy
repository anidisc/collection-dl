﻿
# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:23
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_6fa6a772:

    # mc_t "When I was a kid{#female}, my favorite moments were when we visited my grandpa, in Vancouver." with dis_std
    mc_t "Quando ero bambino{#female}, i miei momenti preferiti erano quando andavamo a trovare mio nonno, a Vancouver." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:25
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_81983014:

    # mc_t "When I was a kid{#male}, my favorite moments were when we visited my grandpa, in Vancouver." with dis_std
    mc_t "Quando ero bambino{#male}, i miei momenti preferiti erano quando andavamo a trovare mio nonno, a Vancouver." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:26
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_b1a93f0b:

    # mc_t "He lived on a boat! It was full of books, drawings, and mockups everywhere. According to him, he was “redesigning civilization”."
    mc_t "Viveva su una barca! Era pieno di libri, disegni e modelli ovunque. Secondo lui, stava “ridisegnando la civiltà”."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:27
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_3f2f1f6b:

    # mc_t "My family thought he was crazy, that he had lost his mind with his futuristic fantasies."
    mc_t "La mia famiglia pensava che fosse pazzo, che avesse perso la testa con le sue fantasie futuristiche."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:28
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_45f496aa:

    # mc_t "But I... wanted to be like him."
    mc_t "Ma io... volevo essere come lui."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:29
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_1c2fd0a2:

    # mc_t "He taught me that there was only one science: the art of building a better world for all humanity."
    mc_t "Mi ha insegnato che esiste una sola scienza: l’arte di costruire un mondo migliore per tutta l’umanità."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:30
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_f052e823:

    # mc_t "It was so inspiring!"
    mc_t "È stato così stimolante!"

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:32
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_67cfc516:

    # mc_t "Unfortunately, he didn't apply that philosophy to his own health..."
    mc_t "Sfortunatamente, non applicò quella filosofia alla propria salute..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:33
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_e29d8fd6:

    # mc_t "He died of lung cancer."
    mc_t "È morto di cancro ai polmoni."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:36
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_9fbf6756:

    # mc_t "Years later, my parents told me that he wasn't a real engineer. In fact..." with dis_std_long
    mc_t "Anni dopo, i miei genitori mi dissero che non era un vero ingegnere. In effetti..." with dis_std_long

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:39
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_c6dad4b6:

    # mc_t "My grandpa was a fraud."
    mc_t "Mio nonno era un impostore."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:41
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_e44d0826:

    # mc_t "He spent his whole life pretending to be an inventor. He gave lectures, appeared in interviews... but there was nothing real behind it."
    mc_t "Ha passato tutta la vita fingendo di essere un inventore. Teneva conferenze, appariva in interviste... ma dietro non c'era nulla di reale."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:42
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_6d9e355f:

    # mc_t "It was a hard blow for me..."
    mc_t "Per me è stato un duro colpo..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:43
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_2f0d8c0e:

    # mc_t "Since then, it doesn't matter where I put my hope. It always ends the same way..."
    mc_t "Da allora, non importa dove ripongo la mia speranza. Finisce sempre allo stesso modo..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:44
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_9487c708:

    # mc_t "Crushed by reality."
    mc_t "Schiacciato dalla realtà."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:56
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_b397339d:

    # mc_t "I'm alone{#female}." with dis_std
    mc_t "Sono solo{#female}." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:57
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_a9c93b99:

    # mc_t "Completely alone{#female} in this huge world..."
    mc_t "Completamente solo{#female} in questo mondo immenso..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:59
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_cd6802ea:

    # mc_t "I'm alone{#male}." with dis_std
    mc_t "Sono solo{#male}." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:60
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_be0b67ee:

    # mc_t "Completely alone{#male} in this huge world..."
    mc_t "Completamente solo{#male} in questo mondo immenso..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:61
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_d697596f:

    # mc_t "My days just go by, without finding anything or anyone that makes me happy."
    mc_t "Le mie giornate passano senza trovare niente e nessuno che mi renda felice."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:63
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_905b5203:

    # mc_t "I feel so... empty{#female}."
    mc_t "Mi sento così... vuoto{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:65
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_8b952df1:

    # mc_t "I feel so... empty{#male}."
    mc_t "Mi sento così... vuoto{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:68
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_400bb6da:

    # mc_t "Is this the future humanity wants?" with dis_std_med
    mc_t "È questo il futuro che l’umanità vuole?" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:69
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_78411dd4:

    # mc_t "To keep wasting our intelligence and creativity on stupid things..."
    mc_t "Continuare a sprecare la nostra intelligenza e creatività in cose stupide..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:70
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_53d01cf6:

    # mc_t "Or even worse, killing each other in wars."
    mc_t "O peggio ancora, uccidendosi a vicenda nelle guerre."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:71
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_dce5977c:

    # mc_t "Fuck..."
    mc_t "Fanculo..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:72
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_a59e8b22:

    # mc_t "I hate this world."
    mc_t "Odio questo mondo."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:75
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_16ff2e6f:

    # mc_t "But I can't do anything to change it." with dis_std_med
    mc_t "Ma non posso fare nulla per cambiarlo." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:78
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_2a1a83f4:

    # mc_t "I'm just... a simple human{#female}."
    mc_t "Sono solo... un semplice essere umano{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:79
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_b375cf57:

    # mc_t "A human{#female} that couldn't find a reason to live."
    mc_t "Un essere umano{#female} che non riusciva a trovare una ragione per vivere."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:81
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_06d2f611:

    # mc_t "I'm just... a simple human{#male}."
    mc_t "Sono solo... un semplice essere umano{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:82
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_b1b76001:

    # mc_t "A human{#male} that couldn't find a reason to live."
    mc_t "Un essere umano{#male} che non riusciva a trovare una ragione per vivere."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:85
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_743c62d6:

    # mc_t "Yeah, that's right." with dis_std_med
    mc_t "Sì, è vero." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:86
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_0a50f4e7:

    # mc_t "When you put aside all my fantasies, there's nothing left."
    mc_t "Quando metti da parte tutte le mie fantasie, non rimane più niente."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:87
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_6c2791c7:

    # mc_t "Because I'm an empty person..."
    mc_t "Perché sono una persona vuota..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:100
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_22de468c:

    # dd "That's not true." with dis_std
    dd "Non è vero." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:101
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_dcc25ceb:

    # dd "To me, you're like the opposite of an empty person!"
    dd "Per me sei l'opposto di una persona vuota!"

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:109
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_07f40d26:

    # dd "You are more capable{#female} than you think, [mc.name!t]." with dis_std
    dd "Sei più capace{#female} di quanto pensi, [mc.name!t]." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:110
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_bc2a0593:

    # dd "Just be honest{#female} with what your heart truly wants, and start your own adventure!"
    dd "Sii onesto{#female} con ciò che il tuo cuore vuole veramente e inizia la tua avventura!"

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:112
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_0fe59268:

    # dd "You are more capable{#male} than you think, [mc.name!t]." with dis_std
    dd "Sei più capace{#male} di quanto pensi, [mc.name!t]." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:113
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_0eab9408:

    # dd "Just be honest{#male} with what your heart truly wants, and start your own adventure!"
    dd "Sii onesto{#male} con ciò che il tuo cuore vuole veramente e inizia la tua avventura!"

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:117
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_088154be:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:120
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_feeb92b0:

    # mc "{act}smiles{/act}" with dis_std
    mc "{act}sorride{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:123
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_078c0aae:

    # mc_t "My own adventure, huh?" with dis_std_long
    mc_t "La mia avventura, eh?" with dis_std_long

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:125
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_839b1dd2:

    # mc_t "I'd be lying if I said the idea never crossed my mind."
    mc_t "Mentirei se dicessi che l'idea non mi è mai passata per la mente."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:126
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_2d8817f0:

    # mc_t "Doesn't sound very realistic, but..."
    mc_t "Non sembra molto realistico, ma..."

# game/story/book1/c1_awakening/e03_lonely_life/s03_a_reason_to_live/script.rpy:127
translate italian scene__book1__c1_awakening__e03_lonely_life__s03_a_reason_to_live_f92511a0:

    # mc_t "I guess I can try."
    mc_t "Immagino di poter provare."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
