﻿
translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/scene.rpy:6
    old "Caught{#female} in the Act{#story-scene}"
    new "Colto in flagrante{#female}{#story-scene}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/scene.rpy:9
    old "Caught{#male} in the Act{#story-scene}"
    new "Colto in flagrante{#male}{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
