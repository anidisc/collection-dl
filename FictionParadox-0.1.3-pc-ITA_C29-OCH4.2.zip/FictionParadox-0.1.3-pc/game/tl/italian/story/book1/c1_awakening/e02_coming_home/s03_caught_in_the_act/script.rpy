﻿
# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:14
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f917f5fa:

    # mc_t "Damn..."
    mc_t "Accidenti..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:16
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7ede7fc7:

    # mc_t "Damn..." with dis_std_med
    mc_t "Accidenti..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:18
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a248e7b0:

    # mc_t "[ll.name!t]'s in great shape!"
    mc_t "[ll.name!t] è in gran forma!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:19
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_53f122be:

    # mc_t "Meanwhile, I haven't exercised at all since we finished high school."
    mc_t "Nel frattempo, non ho più fatto attività fisica da quando abbiamo finito il liceo."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:22
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5949b399:

    # mc_t "I miss our P.E. classes... [ll.name!t] always caught me staring at her and [dd.name!t]'s asses, haha."
    mc_t "Mi manca il nostro P.E. lezioni... [ll.name!t] mi sorprendeva sempre a fissare il culo di lei e di [dd.name!t], ahah."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:23
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2aa63706:

    # mc_t "Although today she's unusually distracted{#female}. Maybe I can..."
    mc_t "Anche se oggi è insolitamente distratta{#female}. Forse posso..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:25
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f0204efa:

    # mc_t "I miss our P.E. classes... [ll.name!t] always caught me staring at him and [dd.name!t]'s asses, haha."
    mc_t "Mi manca il nostro P.E. lezioni... [ll.name!t] mi sorprendeva sempre a fissare lui e il sedere di [dd.name!t], ahah."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:26
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2aa63706_1:

    # mc_t "Although today she's unusually distracted{#female}. Maybe I can..."
    mc_t "Anche se oggi è insolitamente distratta{#female}. Forse posso..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:40
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_8f337a6f:

    # mc_t "Nah, better not to risk."
    mc_t "No, meglio non rischiare."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:42
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c9d4fda7:

    # mc_t "Nah, better not to risk." with dis_std
    mc_t "No, meglio non rischiare." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:45
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b22350b8:

    # mc_t "Last thing I want is her punching me in the face."
    mc_t "L'ultima cosa che voglio è che mi dia un pugno in faccia."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:47
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_84c645b2:

    # mc_t "Last thing I want is him punching me in the face."
    mc_t "Last thing I want is him punching me in the face."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:50
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f4f28653:

    # mc_t "Let's keep watching the city..." with dis_std_med
    mc_t "Continuiamo a guardare la città..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:51
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_cd714092:

    # mc_t "Not as exciting, but at least I keep my teeth in place."
    mc_t "Non così eccitante, ma almeno tengo i denti a posto."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:57
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c538df33:

    # mc_t "Fuck it."
    mc_t "Fanculo."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:59
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5d0aee91:

    # mc_t "Fuck it." with dis_std
    mc_t "Fanculo." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:60
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_0c1adb5e:

    # mc_t "You only live once, right?"
    mc_t "Si vive una volta sola, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:63
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1cf1b759:

    # mc_t "Wow..." with dis_std_med
    mc_t "Vabbè..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:66
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_539d8476:

    # mc_t "She's strong{#female} as fuck! How many pull-ups does she do per day?"
    mc_t "È forte{#female} dannatamente! Quanti pull-up fa al giorno?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:68
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d4a92506:

    # mc_t "He's strong{#male} as fuck! How many pull-ups does he do per day?"
    mc_t "È fortissimo{#male} dannatamente! Quanti pull-up fa al giorno?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:69
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_148d3661:

    # mc_t "I wonder how it'd feel to touch her back..."
    mc_t "Mi chiedo come ci si sentirebbe a toccarla di nuovo..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:70
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_81e16afd:

    # mc_t "{sc=1}{color=[gui.think_dialogue_color]}Hnnggg{/color}{/sc}"
    mc_t "{sc=1}{color=[gui.think_dialogue_color]}Hnnggg{/color}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:73
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_195caad5:

    # mc_t "S-Stop it, [mc.name!t], stop!" with dis_std_med
    mc_t "S-Smettila, [mc.name!t], fermati!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:74
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_4129c05f:

    # mc_t "Control yourself!"
    mc_t "Controlla te stesso!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:75
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:76
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5408e322:

    # mc_t "Okay, just one more peek..."
    mc_t "Ok, solo un'altra sbirciatina..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:79
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b44f89e8:

    # mc_t "Daaaamn..." with dis_std_med
    mc_t "Daaaam..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:81
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_929fdceb:

    # mc_t "Her legs are also toned, for sure."
    mc_t "Sicuramente anche le sue gambe sono toniche."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:83
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_3bf412dc:

    # mc_t "His legs are also toned, for sure."
    mc_t "Sicuramente anche le sue gambe sono toniche."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:84
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_34bc9fc6:

    # mc_t "But more importantly..."
    mc_t "Ma cosa ancora più importante..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:89
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_39f11604:

    # mc_t "How the hell does she have that ass!?"
    mc_t "Come diavolo ha quel culo!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:91
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c753f9ba:

    # mc_t "How the hell does he have that ass!?"
    mc_t "Come diavolo ha quel culo!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:92
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_17c417a1:

    # mc_t "Hot daaamn!"
    mc_t "Che caldo!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:93
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_4cfb3cdd:

    # mc_t "You {i}really{/i} like to do squats, huh?"
    mc_t "A te {i}davvero{/i} piace fare gli squat, eh?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:94
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b5e4d9c1:

    # mc_t "{sc=1}{color=[gui.think_dialogue_color]}Grrrr{/color}{/sc}"
    mc_t "{sc=1}{color=[gui.think_dialogue_color]}Grrrr{/color}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:96
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d26bf86d:

    # mc_t "No matter where you look, her body is pure dynamite."
    mc_t "Non importa dove guardi, il suo corpo è pura dinamite."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:98
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_48d0fb2b:

    # mc_t "No matter where you look, his body is pure dynamite."
    mc_t "Non importa dove guardi, il suo corpo è pura dinamite."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:99
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_49cbb46c:

    # ll "Hm?"
    ll "Ehm?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:105
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7637fde6:

    # mc "{act}looks to the city{/act}"
    mc "{act}guarda alla città{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:106
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c5d907e1:

    # ll "[mc.name!t]."
    ll "[mc.name!t]."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:107
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_01b41ede:

    # mc_t "Shit."
    mc_t "Merda."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:108
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_8dc90012:

    # ll "[mc.name!tu]!"
    ll "[mc.name!tu]!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:112
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a2fcca17:

    # mc "{sc=1}Y-Yes...?{/sc}"
    mc "{sc=1}S-Sì...?{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:114
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5ee87513:

    # ll "Don't play dumb{#female}!"
    ll "Non fare lo stupido{#female}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:116
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5457107d:

    # ll "Don't play dumb{#male}!"
    ll "Non fare lo stupido{#male}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:119
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_25908b98:

    # ll "What the fuck were you doing!?" with dis_std_med
    ll "Che cazzo stavi facendo!?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:122
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b6c43c4a:

    # mc "M-Me?"
    mc "M-Io?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:123
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_53f3214d:

    # mc "Just looking at the city!"
    mc "Basta guardare la città!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:127
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a69b45b7:

    # ll "Do you think I'm stupid{#female}?"
    ll "Pensi che io sia stupido{#female}?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:129
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7b36331a:

    # ll "Do you think I'm stupid{#male}?"
    ll "Pensi che io sia stupido{#male}?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:130
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_554379f5:

    # ll "Your eyes were about to pop out of their sockets!"
    ll "I tuoi occhi stavano per uscire dalle orbite!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:133
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9d7d505f:

    # mc_t "My god..." with dis_std_med
    mc_t "Mio Dio..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:135
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5cfb2ab7:

    # mc_t "Her figure is insane!"
    mc_t "La sua figura è pazzesca!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:137
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e95a1868:

    # mc_t "His figure is insane!"
    mc_t "La sua figura è pazzesca!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:142
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c34214f6:

    # mc_t "And her belly button is driving me CRAZY{#female}." with dis_std_med
    mc_t "E il suo ombelico mi sta facendo impazzire{#female}." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:144
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_06aeb7ca:

    # mc_t "And her belly button is driving me CRAZY{#male}." with dis_std_med
    mc_t "E il suo ombelico mi sta facendo impazzire{#male}." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:147
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e55f9c20:

    # mc_t "And his belly button is driving me CRAZY{#female}." with dis_std_med
    mc_t "E il suo ombelico mi sta facendo impazzire{#female}." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:149
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_170291b2:

    # mc_t "And his belly button is driving me CRAZY{#male}." with dis_std_med
    mc_t "E il suo ombelico mi sta facendo impazzire{#male}." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:150
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_51c5a7d5:

    # mc_t "It's too cute!"
    mc_t "È troppo carino!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:154
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1a319de9:

    # ll "Are you listening to me!?"
    ll "Mi stai ascoltando!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:157
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_6605c8e4:

    # mc "O-Of course!"
    mc "O-Certamente!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:160
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_fb8b4bcc:

    # ll "You were fantasizing about my body, weren't you?"
    ll "Stavi fantasticando sul mio corpo, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:163
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b2a3b30c:

    # mc "No, no! Not at all!"
    mc "No, no! Affatto!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:166
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b2122fa3:

    # mc "{act}thinking{/act}"
    mc "{act}pensare{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:179
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_79218668:

    # mc "There was a fly on your butt!"
    mc "C'era una mosca sul tuo sedere!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:181
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_dcf44fd0:

    # mc "There was a fly on your butt!" with dis_std
    mc "C'era una mosca sul tuo sedere!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:184
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9cdee31c:

    # ll "...a fly?"
    ll "...una mosca?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:187
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_568b16be:

    # mc "Yeah! A {i}big{/i} one."
    mc "Sì! Uno {i}grande{/i}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:188
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1ad52796:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:189
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:192
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d2eb0bed:

    # ll "Are you kidding me?"
    ll "Ma stai scherzando?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:195
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f07425c4:

    # mc "N-No, I'm seri—"
    mc "N-No, sono serio—"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:199
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_51da3dc1:

    # mc "Your outfit's way too cool!"
    mc "Il tuo outfit è davvero troppo bello!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:201
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d322a44c:

    # mc "Your outfit's way too cool!" with dis_std
    mc "Il tuo outfit è davvero troppo bello!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:204
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c4c77c24:

    # ll "...my outfit?"
    ll "...il mio vestito?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:207
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_0e6bf652:

    # mc "Yeah! I told you before, remember?"
    mc "Sì! Te l'ho già detto, ricordi?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:208
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_891c4f1d:

    # mc "Now I was looking at...{w} the quality of...{w} the fabric!"
    mc "Ora stavo guardando...{w} la qualità del...{w} il tessuto!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:209
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1ad52796_1:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:210
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_2:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:213
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d2eb0bed_1:

    # ll "Are you kidding me?"
    ll "Ma stai scherzando?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:216
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f07425c4_1:

    # mc "N-No, I'm seri—"
    mc "N-No, sono serio—"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:220
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_bad396a8:

    # mc "You've gotten really strong!"
    mc "Sei diventato davvero forte!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:222
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a372b139:

    # mc "You've gotten really strong!" with dis_std
    mc "Sei diventato davvero forte!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:223
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9c7bd28c:

    # mc "I couldn't help but admire your...{w} results."
    mc "Non ho potuto fare a meno di ammirare i tuoi...{w} risultati."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:226
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_06a5c17a:

    # ll "So you admit you were staring."
    ll "Quindi ammetti che stavi fissando."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:229
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_aebbb9e3:

    # mc_t "Fuck."
    mc_t "Fanculo."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:230
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_63714729:

    # mc "Well, technically speaking... yes, I was staring at you."
    mc "Beh, tecnicamente parlando... sì, ti stavo fissando."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:231
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e6e10972:

    # mc "But I wasn't having dirty thoughts, I swear!"
    mc "Ma non avevo pensieri sporchi, lo giuro!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:234
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_90b88727:

    # ll "Hmm..." with dis_std_med
    ll "Hmm..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:238
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2d9ad671:

    # ll "Pervert{#female}."
    ll "Pervertito{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:240
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c6e63699:

    # ll "Pervert{#male}."
    ll "Pervertito{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:244
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_750df673:

    # mc "I'm not a pervert{#female}!"
    mc "Non sono un pervertito{#female}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:246
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d1a6a131:

    # mc "I'm not a pervert{#male}!"
    mc "Non sono un pervertito{#male}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:249
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d7fbba1f:

    # ll "Yes you are."
    ll "Sì, sei tu."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:251
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e4d181f2:

    # ll "Per{w}-vert{#female}."
    ll "Per{w}-vert{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:253
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5bc3f53e:

    # ll "Per{w}-vert{#male}."
    ll "Per{w}-vert{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:257
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9ebba72b:

    # mc_t "Fuck, why am I getting horny{#female}...?"
    mc_t "Cavolo, perché mi sto arrapando{#female}...?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:258
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f6fb8336:

    # mc_t "Am I a pervert{#female}!?"
    mc_t "Sono un pervertito{#female}!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:260
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b6ecefda:

    # mc_t "Fuck, why am I getting horny{#male}...?"
    mc_t "Cavolo, perché mi sto arrapando{#male}...?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:261
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_35f8f3ad:

    # mc_t "Am I a pervert{#male}!?"
    mc_t "Sono un pervertito{#male}!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:265
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_4d2ebccb:

    # ll "Did you enjoy it, pig{#female}?"
    ll "Ti è piaciuto, maiale{#female}?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:267
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5de20c45:

    # ll "Did you enjoy it, pig{#male}?"
    ll "Ti è piaciuto, maiale{#male}?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:270
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5956e0bb:

    # mc_t "I enjoyed every damn second..."
    mc_t "Mi sono goduto ogni dannato secondo..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:271
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7469d590:

    # mc "[ll.name!t], you're prejudging me. I assure you I couldn't fantasize even if I wanted to!"
    mc "[ll.name!t], mi stai giudicando in modo pregiudizievole. Ti assicuro che non potrei fantasticare nemmeno se lo volessi!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:274
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_6783d0a0:

    # ll "I don't believe you."
    ll "Non ti credo."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:278
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_4e56e59f:

    # mc_t "Lying won't work with her..."
    mc_t "Mentire non funzionerà con lei..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:280
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2ea20328:

    # mc_t "Lying won't work with him..."
    mc_t "Mentire non funzionerà con lui..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:281
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1ac61332:

    # mc_t "Better to say something based on a real emotion!"
    mc_t "Meglio dire qualcosa basato su un'emozione reale!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:296
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_47eff917:

    # mc "I was bored{#female}, okay?"
    mc "Mi annoiavo{#female}, ok?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:298
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9f61707d:

    # mc "I was bored{#male}, okay?"
    mc "Mi annoiavo{#male}, ok?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:301
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_0ea2d9cf:

    # mc "I was bored{#female}, okay?" with dis_std
    mc "Mi annoiavo{#female}, ok?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:303
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f7bac971:

    # mc "I was bored{#male}, okay?" with dis_std
    mc "Mi annoiavo{#male}, ok?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:304
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1487969a:

    # mc "I had nothing better to do, so..."
    mc "Non avevo niente di meglio da fare, quindi..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:307
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_339b8618:

    # ll "...you stared at my butt."
    ll "...mi hai fissato il sedere."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:310
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_3:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:311
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f800bed0:

    # mc "Yes."
    mc "SÌ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:316
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_8e0d0bf4:

    # mc "I'm sorry [ll.name!t], but you're too hot{#female}."
    mc "Mi dispiace [ll.name!t], ma sei troppo sexy{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:318
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_fefea0e0:

    # mc "I'm sorry [ll.name!t], but you're too hot{#male}."
    mc "Mi dispiace [ll.name!t], ma sei troppo sexy{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:321
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_80cfa3b9:

    # mc "I'm sorry [ll.name!t], but you're too hot{#female}." with dis_std
    mc "Mi dispiace [ll.name!t], ma sei troppo sexy{#female}." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:323
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9ad514ff:

    # mc "I'm sorry [ll.name!t], but you're too hot{#male}." with dis_std
    mc "Mi dispiace [ll.name!t], ma sei troppo sexy{#male}." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:326
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_3ec2a769:

    # ll "I knew it..."
    ll "lo sapevo..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:330
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_fe5c9df3:

    # mc "I was trying to inspire myself..."
    mc "Stavo cercando di ispirarmi..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:332
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2d6abc21:

    # mc "I was trying to inspire myself..." with dis_std
    mc "Stavo cercando di ispirarmi..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:333
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_499e35cb:

    # mc "{act}sighs{/act} I thought some exercise might do me good."
    mc "{act}sospira{/act} Pensavo che un po' di esercizio potesse farmi bene."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:334
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1ad52796_2:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:335
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_4:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:338
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_96fa44de:

    # ll "{act}cute voice{/act} Do you mean it?" with dis_std_med
    ll "{act}voce carina{/act} Dici sul serio?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:341
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_998f19ce:

    # mc_t "Wait... did that actually work!?"
    mc_t "Aspetta... ha funzionato davvero!?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:342
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_5b3a6119:

    # mc "Y-Yeah, totally!"
    mc "S-Sì, assolutamente!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:343
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_29475ee7:

    # mc "Seeing how strong you've gotten, it's kind of motivating."
    mc "Vedere quanto sei diventato forte è un po' motivante."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:347
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_0550c76b:

    # ll "I'm very proud{#female} of my progress!" with dis_std_med
    ll "Sono molto orgoglioso{#female} dei miei progressi!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:349
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_3073b91d:

    # ll "I'm very proud{#male} of my progress!" with dis_std_med
    ll "Sono molto orgoglioso{#male} dei miei progressi!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:350
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d20e3540:

    # ll "You know, training is a way of life to me. This is just a side effect!"
    ll "Sai, per me l'allenamento è uno stile di vita. Questo è solo un effetto collaterale!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:353
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_8a276323:

    # mc "A person's true appeal lies in how they live!"
    mc "Il vero fascino di una persona sta nel modo in cui vive!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:356
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_4129d5c8:

    # ll "Yeah, I think the same."
    ll "Sì, penso lo stesso."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:359
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_75100e0b:

    # ll "{act}cute voice{/act} Do you forgive me...?" with dis_std_med
    ll "{act}voce carina{/act} Mi perdoni...?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:362
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_05500ff6:

    # mc "Huh?"
    mc "Eh?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:365
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_475fec40:

    # ll "{act}cute voice{/act} For prejudging you..."
    ll "{act}voce carina{/act} Per averti pregiudicato..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:368
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_66b86362:

    # mc_t "Oh god..."
    mc_t "Oh Dio..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:369
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7222bd07:

    # mc "D-Don't worry, haha. There's nothing to forgive!"
    mc "D-Non preoccuparti, ahah. Non c'è niente da perdonare!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:373
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c5dc1d85:

    # ll "{act}cute voice{/act} I'm a good girl, right?"
    ll "{act}voce carina{/act} Sono una brava ragazza, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:375
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f54b7dbc:

    # ll "{act}cute voice{/act} I'm a good boy, right?"
    ll "{act}voce carina{/act} Sono un bravo ragazzo, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:378
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_5:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:379
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_7d1a1c68:

    # mc "Yes, you are..."
    mc "Sì, sei..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:382
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_697d740a:

    # ll "{act}cute voice{/act} Did you enjoy...{w} watching me?"
    ll "{act}voce carina{/act} Ti è piaciuto...{w} guardarmi?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:385
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_9e85d9ae:

    # mc "Oh my god [ll.name!t], I enjoyed every damn second..."
    mc "Oh mio Dio [ll.name!t], mi sono goduto ogni dannato secondo..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:388
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a92a88ef:

    # ll "{act}smiles{/act}" with dis_std
    ll "{act}sorrisi{/act}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:389
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c4e0ec33:

    # mc "W-What is it?"
    mc "W-che cos'è?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:392
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_8e837e7f:

    # ll "{act}cute voice{/act} I caught you..." with dis_std_med
    ll "{act}voce carina{/act} Ti ho beccato..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:397
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c5f558a2:

    # ll "You're a fucking PERVERT{#female}!"
    ll "Sei un fottuto PERVERTITO{#female}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:399
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b02dbc65:

    # ll "You're a fucking PERVERT{#male}!"
    ll "Sei un fottuto PERVERTITO{#male}!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:402
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_ab03913e:

    # mc "No, no! This is a misunderstanding!"
    mc "No, no! Questo è un malinteso!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:405
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_ffdbb817:

    # ll "Misunderstanding, my ass."
    ll "Malinteso, mio ​​caro."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:406
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_0a6064d6:

    # ll "Instead of thinking about dirty stuff all day, you should take better care of yourself!"
    ll "Invece di pensare tutto il giorno alle cose sporche, dovresti prenderti più cura di te stesso!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:407
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e466fa8b:

    # ll "You're skin and bones!"
    ll "Sei pelle e ossa!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:411
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_de63cb2a:

    # mc_t "Her eyes are so pretty..." with dis_std_med
    mc_t "I suoi occhi sono così belli..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:413
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_2c9494cc:

    # mc_t "His eyes are so pretty..." with dis_std_med
    mc_t "I suoi occhi sono così belli..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:415
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_70ea2f69:

    # mc_t "They're hypnotic..."
    mc_t "Sono ipnotici..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:418
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_a6ececcb:

    # mc_t "And that nose with the piercing? Oh god..." with dis_std_med
    mc_t "E quel naso con il piercing? Oh Dio..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:419
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f2824d6c:

    # mc_t "I think I have a new fetish."
    mc_t "Penso di avere un nuovo feticcio."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:422
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_1ae101f1:

    # mc "{act}looking down{/act} {think}What a nice view...{/think}" with dis_std_med
    mc "{act}guardando in basso{/act} {think}Che bella vista...{/think}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:425
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d27ca6ce:

    # ll "You should eat more!"
    ll "Dovresti mangiare di più!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:428
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_f43183ec:

    # mc "Yeah, you're right. Eating is...{w} important."
    mc "Sì, hai ragione. Mangiare è...{w} importante."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:431
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_e58af6e4:

    # ll "Where the fuck are you looking at?" with dis_std_med
    ll "Dove cazzo stai guardando?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:432
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_b6c43c4a_1:

    # mc "M-Me?"
    mc "M-Io?"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:433
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_c927f942:

    # ll "Yes, you."
    ll "Sì, tu."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:434
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_80a5c16f:

    # mc "Umm..."
    mc "Ehm..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:438
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_01495dd7:

    # bogdan "TELEGRIM, COME HERE!"
    bogdan "TELEGRIM, VIENI QUI!"

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:439
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_49cbb46c_1:

    # ll "Hm?"
    ll "Ehm?"

translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:31
    old "{#BOND-CORRECT}Contemplate her body{#chapter1x1-choice02}"
    new "{#BOND-CORRECT}Contempla il suo corpo{#chapter1x1-choice02}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:33
    old "{#BOND-CORRECT}Contemplate his body{#chapter1x1-choice02}"
    new "{#BOND-CORRECT}Contempla il suo corpo{#chapter1x1-choice02}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:35
    old "Better not to risk{#chapter1x1-choice02}"
    new "Meglio non rischiare{#chapter1x1-choice02}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:170
    old "There was a fly on your butt.{#chapter1x1-choice03}"
    new "C'era una mosca sul tuo sedere.{#chapter1x1-choice03}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:172
    old "Your outfit's too cool.{#chapter1x1-choice03}"
    new "Il tuo outfit è troppo bello.{#chapter1x1-choice03}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:174
    old "{#BOND-CORRECT}You've gotten really strong.{#chapter1x1-choice03}"
    new "{#BOND-CORRECT}Sei diventato davvero forte.{#chapter1x1-choice03}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:286
    old "{#BOND-CORRECT}Inspiration{#chapter1x1-choice04}"
    new "{#BOND-CORRECT}Ispirazione{#chapter1x1-choice04}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:288
    old "Boredom{#chapter1x1-choice04}"
    new "Noia{#chapter1x1-choice04}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:290
    old "Excitement{#chapter1x1-choice04}"
    new "Eccitazione{#chapter1x1-choice04}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:19
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_bcf430d9:

    # mc "{act}looks towards [ll.name!t]{/act}" with dis_std_med
    mc "{act}guarda verso [ll.name!t]{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:32
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_d9a28afc:

    # mc_t "Although today he's unusually distracted{#male}. Maybe I can..."
    mc_t "Anche se oggi è insolitamente distratto{#male}. Forse posso..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:78
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_bcd45ead:

    # mc_t "I wonder how it'd feel to touch his back..."
    mc_t "Mi chiedo come sarebbe toccargli la schiena..."

# game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:389
translate italian scene__book1__c1_awakening__e02_coming_home__s03_caught_in_the_act_77a89e99_6:

    # mc ". . ."
    mc ". . ."

translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:183
    old "{#BOND-CORRECT}You've gotten really strong{#female}.{#chapter1x1-choice03}"
    new "{#BOND-CORRECT}Sei diventato davvero forte{#female}.{#chapter1x1-choice03}"

    # game/story/book1/c1_awakening/e02_coming_home/s03_caught_in_the_act/script.rpy:185
    old "{#BOND-CORRECT}You've gotten really strong{#male}.{#chapter1x1-choice03}"
    new "{#BOND-CORRECT}Sei diventato davvero forte{#male}.{#chapter1x1-choice03}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
