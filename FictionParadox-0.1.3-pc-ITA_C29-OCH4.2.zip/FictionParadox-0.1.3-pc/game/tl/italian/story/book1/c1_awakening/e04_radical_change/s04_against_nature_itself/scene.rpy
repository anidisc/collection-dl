﻿
translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/scene.rpy:6
    old "Against Nature Itself{#story-scene}"
    new "Contro la natura stessa{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
