﻿
# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:75
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_3569d166:

    # mc "This is a complete disaster..." with dis_std
    mc "Questo è un disastro totale..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:78
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_8fe4a4fb:

    # phone_ai "Why do you say that?"
    phone_ai "Perchè dici questo?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:83
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_b71eb4a0:

    # mc "Why!?"
    mc "Perché!?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:84
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_26381a59:

    # mc "You ask why, seriously!?"
    mc "Ti chiedi perché, sul serio!?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:85
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_87f43923:

    # mc "Every time we try to do something outside the norm, you make things up!"
    mc "Ogni volta che proviamo a fare qualcosa fuori dalla norma, ti inventi qualcosa!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:88
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_e3ca3d1d:

    # phone_ai "I apologize..."
    phone_ai "mi scuso..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:89
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c104ca45:

    # phone_ai "As a language model, I only rely on existing data."
    phone_ai "Come modello linguistico, mi baso solo sui dati esistenti."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:92
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_ac0a405e:

    # mc_t "We're not making any progress..."
    mc_t "Non stiamo facendo alcun progresso..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:93
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_bfd1333b:

    # mc_t "If I had more money, I could buy a license and use one of those super-powerful AIs."
    mc_t "Se avessi più soldi, potrei comprare una licenza e usare una di quelle IA super potenti."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:94
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_55ac6ab6:

    # mc_t "But this is all I got..."
    mc_t "Ma questo è tutto quello che ho..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:95
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_0187a98c:

    # mc_t "And no, I'm not going to learn how to code. It's beyond my capabilities."
    mc_t "E no, non imparerò a programmare. Va oltre le mie capacità."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:98
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_db010abf:

    # phone_ai "Do you want to try again?"
    phone_ai "Vuoi riprovare?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:101
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_3ee47f39:

    # mc "How many attempts have we made so far?"
    mc "Quanti tentativi abbiamo fatto finora?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:104
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_1500168a:

    # phone_ai "134."
    phone_ai "134."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:107
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_1dd9a20b:

    # mc "{act}sighs{/act}"
    mc "{act}sospira{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:108
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_1ef7e68c:

    # mc "Just turn off, please."
    mc "Spegni e basta, per favore."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:111
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_4801c5cf:

    # phone_ai "Understood."
    phone_ai "Inteso."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:112
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_381a46a7:

    # phone_ai "Good luck with your science-link, [mc.name!t]!"
    phone_ai "Buona fortuna con il tuo collegamento scientifico, [mc.name!t]!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:118
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_8198bce0:

    # phone "{act}turns off{/act}" with dis_std
    phone "{act}si spegne{/act}" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:121
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_dedce312:

    # mc "What a waste of time..."
    mc "Che perdita di tempo..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:124
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:125
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_56a2e3b6:

    # mc_t "I think I'll go for a walk. I need to clear my thoughts..."
    mc_t "Penso che andrò a fare una passeggiata. Ho bisogno di schiarirmi le idee..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:137
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_fad658e9:

    # mc_t "I've been fooling around for a whole week..." with dis_std
    mc_t "È un'intera settimana che sto scherzando..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:138
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_2c70e91a:

    # mc_t "Damn it, it's so hard!"
    mc_t "Dannazione, è così difficile!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:139
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_5e5939a3:

    # mc_t "Yes, you can imagine wonderful things, but making them real is a different thing. Just taking one step forward takes a lot of effort..."
    mc_t "Sì, puoi immaginare cose meravigliose, ma renderle reali è una cosa diversa. Anche solo fare un passo avanti richiede molto impegno..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:140
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_e3c23e06:

    # mc_t "Not to mention that I lack knowledge, I lack skills, and above all... I lack resources."
    mc_t "Senza contare che mi mancano le conoscenze, mi mancano le competenze e soprattutto... mi mancano le risorse."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:143
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_d029bcbd:

    # mc "{act}stops walking{/act}" with dis_std_med
    mc "{act}smette di camminare{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:145
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_b6792288:

    # mc_t "Fuck, I feel so stupid{#female}..."
    mc_t "Cavolo, mi sento così stupido{#female}..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:147
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_deb2c425:

    # mc_t "Fuck, I feel so stupid{#male}..."
    mc_t "Cavolo, mi sento così stupido{#male}..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:148
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_f5406df3:

    # mc_t "Who am I kidding? It's very likely that my science-link is a silly idea, impossible to build."
    mc_t "Chi sto prendendo in giro? È molto probabile che il mio collegamento scientifico sia un'idea sciocca, impossibile da realizzare."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:149
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_4d0c3f6f:

    # mc "{act}sighs{/act} {think}Like my grandpa's fake inventions...{/think}"
    mc "{act}sospira{/act} {think}Come le false invenzioni di mio nonno...{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:150
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:153
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_4c9d19af:

    # mc "{act}looks to the right{/act}" with dis_std_med
    mc "{act}guarda a destra{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:155
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_9340d5e8:

    # mc_t "Despite the noise from the highway, it's pretty calm."
    mc_t "Nonostante il rumore dell'autostrada, è abbastanza tranquillo."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:156
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_15f493f7:

    # mc_t "I think I'll stay here..."
    mc_t "Penso che rimarrò qui..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:166
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_a5b7c526:

    # mc "{act}lies down, looking at the sky{/act}" with dis_std_med
    mc "{act}si sdraia, guardando il cielo{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:167
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_ded4365a:

    # mc_t "It's past midnight."
    mc_t "È mezzanotte passata."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:168
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_1a392fa9:

    # mc_t "Which means... that it's my birthday."
    mc_t "Il che significa... che è il mio compleanno."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:169
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_f86dd44e:

    # mc_t "I'm 24 now."
    mc_t "Ho 24 anni adesso."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:172
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_91ec4945:

    # mc "{act}keeps looking at the sky{/act}" with dis_std_med
    mc "{act}continua a guardare il cielo{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:174
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_2297aeb1:

    # mc_t "In large cities, it's difficult to see the stars."
    mc_t "Nelle grandi città è difficile vedere le stelle."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:175
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_8aa1771a:

    # mc_t "Between the light pollution, the weather, and the atmosphere... you can't see a damn thing."
    mc_t "Tra l'inquinamento luminoso, il tempo e l'atmosfera... non si vede proprio niente."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:176
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_bc159426:

    # mc_t "And yet, I know that... on the other side..."
    mc_t "Eppure so che... dall'altra parte..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:184
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_fb446a45:

    # mc_t "There's an immense sea of stars." with dis_std_long
    mc_t "C'è un immenso mare di stelle." with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:185
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_4d5d4569:

    # mc_t "My eyes may not be able to see them, but... I know they are there."
    mc_t "Forse i miei occhi non riescono a vederli, ma... so che sono lì."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:188
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_819c1cb0:

    # mc_t "It's incredible, right? Human imagination is so powerful..." with dis_std_long
    mc_t "È incredibile, vero? L'immaginazione umana è così potente..." with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:190
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_9249fb89:

    # mc_t "We're fucking awesome! Although sometimes we take what we imagine too seriously, haha."
    mc_t "Siamo fottutamente fantastici! Anche se a volte prendiamo troppo sul serio ciò che immaginiamo, ahah."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:191
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_2abf7fbf:

    # mc_t "You only have to look at me..."
    mc_t "Devi solo guardarmi..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:194
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_82f78c88:

    # mc_t "Nature is beautiful. And at the same time, ruthless. It doesn't care about your feelings." with dis_std_long
    mc_t "La natura è bella. E allo stesso tempo spietato. Non gli importa dei tuoi sentimenti." with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:196
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_d0b9c413:

    # mc_t "But the worst part is that... nothing lasts forever. Even stars die one day."
    mc_t "Ma la cosa peggiore è che... niente dura per sempre. Anche le stelle un giorno muoiono."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:197
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_b7480c2b:

    # mc_t "Death... is our final destination."
    mc_t "La morte... è la nostra destinazione finale."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:198
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_adde66e7:

    # mc_t "That's why I'd like to find a purpose in life."
    mc_t "Ecco perché vorrei trovare uno scopo nella vita."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:200
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_316566ba:

    # mc_t "In my fantasies I'm very ambitious{#female}, sure. But real life is a different story..."
    mc_t "Nelle mie fantasie sono molto ambizioso{#female}, certo. Ma la vita reale è una storia diversa..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:202
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c63428eb:

    # mc_t "In my fantasies I'm very ambitious{#male}, sure. But real life is a different story..."
    mc_t "Nelle mie fantasie sono molto ambizioso{#male}, certo. Ma la vita reale è una storia diversa..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:203
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_78d49422:

    # mc_t "What could someone like me do? I'm just..."
    mc_t "Cosa potrebbe fare uno come me? sono solo..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:204
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_e3549eac:

    # mc_t "A human being."
    mc_t "Un essere umano."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:218
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c141c5a4:

    # mc_t "A human being?" with dis_std
    mc_t "Un essere umano?" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:221
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_21435cb7:

    # mc_t "That's right..."
    mc_t "Esatto..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:223
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_bc450e16:

    # mc_t "How could I have been so blind{#female}!"
    mc_t "Come ho potuto essere così cieco{#female}!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:225
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_0246cf2f:

    # mc_t "How could I have been so blind{#male}!"
    mc_t "Come ho potuto essere così cieco{#male}!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:228
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_089fc242:

    # mc_t "I'm a human being!" with dis_std_med
    mc_t "Sono un essere umano!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:229
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_ea30a962:

    # mc_t "Maybe I've lost my mind from playing so many adventure video games, but..."
    mc_t "Forse ho perso la testa giocando a così tanti videogiochi d'avventura, ma..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:230
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_02489f20:

    # mc_t "People can change, right?"
    mc_t "Le persone possono cambiare, giusto?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:232
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_39a799fd:

    # mc_t "If I don't have a strong light that guides me... I can become that light myself{#female}!"
    mc_t "Se non ho una luce forte che mi guidi... posso diventare io stesso quella luce{#female}!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:234
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_94b54927:

    # mc_t "If I don't have a strong light that guides me... I can become that light myself{#male}!"
    mc_t "Se non ho una luce forte che mi guidi... posso diventare io stesso quella luce{#male}!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:237
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_b4615be7:

    # mc_t "Science starts with pure imagination." with dis_std_med
    mc_t "La scienza inizia con la pura immaginazione." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:239
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_b8c71a34:

    # mc_t "What's the point of setting limits? Just as we transform the world, we can also transform ourselves!"
    mc_t "Che senso ha porre dei limiti? Così come trasformiamo il mondo, possiamo anche trasformare noi stessi!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:240
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_898329c2:

    # mc_t "My starting point sucks, yes..."
    mc_t "Il mio punto di partenza fa schifo, sì..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:241
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_67eeff46:

    # mc_t "But in my era, I have access to all the knowledge of humanity!"
    mc_t "Ma nella mia epoca ho accesso a tutta la conoscenza dell’umanità!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:242
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_3c0a7f8c:

    # mc_t "I can use the power of science, stand on the shoulders of giants, and become the person I always wanted to be!"
    mc_t "Posso usare il potere della scienza, salire sulle spalle dei giganti e diventare la persona che ho sempre desiderato essere!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:252
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_3a5fe6f1:

    # mc_t "But that will have consequences..." with dis_instant
    mc_t "Ma ciò avrà delle conseguenze..." with dis_instant

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:254
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_36ddc389:

    # mc_t "Am I going to question our entire civilization, like my grandpa? Because if that's the case..."
    mc_t "Metterò in discussione la nostra intera civiltà, come mio nonno? Perché se è così..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:257
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_9a41703d:

    # mc_t "I'll have to face the whole world." with dis_std_med
    mc_t "Dovrò affrontare il mondo intero." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:259
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_9f597af2:

    # mc_t "And when you push for a radical change, power always fights back. Without mercy."
    mc_t "E quando si spinge per un cambiamento radicale, il potere reagisce sempre. Senza pietà."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:261
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_ce7f622d:

    # mc_t "To be honest{#female}, I'm scared{#female} to death."
    mc_t "A dire il vero{#female}, sono spaventato{#female} a morte."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:262
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_7cf0e913:

    # mc_t "Scared{#female} of failing, of being alone{#female}, of wasting my life chasing impossible dreams..."
    mc_t "Paura{#female} di fallire, di restare sola{#female}, di sprecare la vita inseguendo sogni impossibili..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:264
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_24dd4f8d:

    # mc_t "To be honest{#male}, I'm scared{#male} to death."
    mc_t "A dire il vero{#male}, sono spaventato{#male} a morte."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:265
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_1e83844f:

    # mc_t "Scared{#male} of failing, of being alone{#male}, of wasting my life chasing impossible dreams..."
    mc_t "Paura{#male} di fallire, di restare sola{#male}, di sprecare la vita inseguendo sogni impossibili..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:266
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_104e6888:

    # mc_t "But, what's the alternative?"
    mc_t "Ma qual è l'alternativa?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:267
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_8e64c32c:

    # mc_t "To keep living quietly, pretending everything is fine?"
    mc_t "Continuare a vivere in silenzio, fingendo che vada tutto bene?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:268
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_0a176efe:

    # mc_t "To let the world stay the same, just because I'm too afraid to move? Is that the right option for me?"
    mc_t "Lasciare che il mondo rimanga lo stesso, solo perché ho troppa paura di muovermi? È l'opzione giusta per me?"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:278
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c0797494:

    # mc_t "Of course not!"
    mc_t "Ovviamente no!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:280
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_e8c43461:

    # mc_t "I plan to make all my fantasies come true!"
    mc_t "Ho intenzione di realizzare tutte le mie fantasie!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:283
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c15a1511:

    # mc_t "I'll create cool inventions! I'll eat great food! I'll get in shape! I'll fuck like a champ{#female}! And most importantly..."
    mc_t "Creerò fantastiche invenzioni! Mangerò dell'ottimo cibo! Mi rimetterò in forma! Scoparò come un campione{#female}! E soprattutto..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:285
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_06ae9117:

    # mc_t "I'll create cool inventions! I'll eat great food! I'll get in shape! I'll fuck like a champ{#male}! And most importantly..."
    mc_t "Creerò fantastiche invenzioni! Mangerò dell'ottimo cibo! Mi rimetterò in forma! Scoparò come un campione{#male}! E soprattutto..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:287
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_07a016fc:

    # mc_t "I'll create cool inventions! I'll eat great food! I'll get in shape! And most importantly..."
    mc_t "Creerò fantastiche invenzioni! Mangerò dell'ottimo cibo! Mi rimetterò in forma! E soprattutto..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:290
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_cb15452c:

    # mc_t "I'LL CHANGE THE WORLD!"
    mc_t "CAMBIERÒ IL MONDO!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:293
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_ffa1be96:

    # mc_t "More than 9 billion people live on this planet..." with dis_std_long
    mc_t "Su questo pianeta vivono più di 9 miliardi di persone..." with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:294
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_4db19830:

    # mc_t "But as long as there are wars, poverty, and so much stupidity, we can't be called civilized!"
    mc_t "Ma finché ci saranno guerre, povertà e tanta stupidità, non potremo dirci civili!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:295
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c07cf52d:

    # mc_t "Our world is broken..."
    mc_t "Il nostro mondo è distrutto..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:296
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_f53cbe03:

    # mc_t "And as humans, it's our duty to fix it!"
    mc_t "E come esseri umani, è nostro dovere risolverlo!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:299
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_6a45e51d:

    # ll "It's human nature." with fade_flashback_fast
    ll "È la natura umana." with fade_flashback_fast

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:302
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_8bb71c2c:

    # ll "Stop thinking like a kid{#female}, and accept it already."
    ll "Smetti di pensare come un bambino{#female} e accettalo già."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:304
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_3611f7e2:

    # ll "Stop thinking like a kid{#male}, and accept it already."
    ll "Smetti di pensare come un bambino{#male} e accettalo già."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:308
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_f9112103:

    # mc_t "You're wrong{#female}, [ll.name!t]..." with fade_flashback_fast
    mc_t "Ti sbagli{#female}, [ll.name!t]..." with fade_flashback_fast

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:310
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_5916a053:

    # mc_t "You're wrong{#male}, [ll.name!t]..." with fade_flashback_fast
    mc_t "Ti sbagli{#male}, [ll.name!t]..." with fade_flashback_fast

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:311
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_284f5a17:

    # mc_t "And I'm going to prove it to you!"
    mc_t "E te lo dimostrerò!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:314
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_e7a5fa08:

    # mc_t "I don't care what or who I have to face..." with dis_std_med
    mc_t "Non mi interessa cosa o chi devo affrontare..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:315
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_f7f5787b:

    # mc_t "Society? History? Our destiny? Even if it's nature itself!"
    mc_t "Società? Storia? Il nostro destino? Anche se è la natura stessa!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:319
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_2cc4021a:

    # mc_t "BRING IT ON!"
    mc_t "PRENDILO!"

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:320
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_19474b81:

    # mc_t "If my dreams are unnatural, then..."
    mc_t "Se i miei sogni sono innaturali, allora..."

# game/story/book1/c1_awakening/e04_radical_change/s04_against_nature_itself/script.rpy:321
translate italian scene__book1__c1_awakening__e04_radical_change__s04_against_nature_itself_c36335c1:

    # mc_t "I'll defeat nature."
    mc_t "Sconfiggerò la natura."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
