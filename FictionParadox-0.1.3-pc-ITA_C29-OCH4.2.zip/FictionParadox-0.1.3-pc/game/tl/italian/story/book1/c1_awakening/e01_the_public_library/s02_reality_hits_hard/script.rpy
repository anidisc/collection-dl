﻿
# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:21
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ec581d3d:

    # dd "...so I ended up learning a bit of Basque too. Now I can order a coffee in three languages!" with dis_std
    dd "...così ho finito per imparare anche un po' di basco. Ora posso ordinare un caffè in tre lingue!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:24
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7376aaae:

    # mc "That's cool!"
    mc "Questo è figo!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:25
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_66a1f8e1:

    # mc "I didn't know Spain had such linguistic diversity."
    mc "Non sapevo che la Spagna avesse una tale diversità linguistica."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:29
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_02e433da:

    # mc_t "God, she looks so mature{#female}..." with dis_std_med
    mc_t "Dio, sembra così matura{#female}..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:31
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3a517162:

    # mc_t "God, he looks so mature{#male}..." with dis_std_med
    mc_t "Dio, sembra così maturo{#male}..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:34
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_81f851cd:

    # mc_t "I'm starting to get nervous{#female}, and this jazz playing in the background doesn't help."
    mc_t "Comincio a innervosirmi{#female} e questo jazz in sottofondo non aiuta."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:36
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_04fa7056:

    # mc_t "I'm starting to get nervous{#male}, and this jazz playing in the background doesn't help."
    mc_t "Comincio a innervosirmi{#male} e questo jazz in sottofondo non aiuta."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:38
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_4d5a79ff:

    # mc "T-Then, now that you've finished the master..."
    mc "T-Allora, ora che hai finito il master..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:39
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_d540dfe2:

    # mc "What's next?"
    mc "Qual è il prossimo passo?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:42
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_04a1ae6d:

    # dd "I'm going to do a PhD in Sustainable Architecture. Here, at the University of Verona."
    dd "Farò un dottorato di ricerca in Architettura Sostenibile. Qui, all'Università di Verona."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:45
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_d4b1ef40:

    # mc_t "A PhD? Wow..."
    mc_t "Un dottorato? Vabbè..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:46
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_06ffa7b0:

    # mc_t "I wouldn't expect anything less from [dd.name!t]."
    mc_t "Non mi aspetterei niente di meno da [dd.name!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:48
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_d914e588:

    # mc "I'm sure{#female} you'll do great!"
    mc "Sono sicuro{#female} che te la caverai alla grande!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:50
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_dcbfbfd7:

    # mc "I'm sure{#male} you'll do great!"
    mc "Sono sicuro{#male} che te la caverai alla grande!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:53
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5ec5257a:

    # dd "Thanks!"
    dd "Grazie!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:54
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_31e84312:

    # dd "What about you? Still living with your family?"
    dd "E tu? Vivi ancora con la tua famiglia?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:57
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1467c9a8:

    # mc "My parents moved back to Canada, but I decided to stay."
    mc "I miei genitori sono tornati in Canada, ma io ho deciso di restare."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:58
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_61b3e663:

    # mc "I managed to get a simple job... Nothing special, just 10 hours a week."
    mc "Sono riuscita a trovare un lavoro semplice... Niente di speciale, solo 10 ore settimanali."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:61
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_07692932:

    # dd "So you live in a shared apartment?"
    dd "Quindi vivi in ​​un appartamento condiviso?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:64
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5daa539b:

    # mc "Nope. Between my salary and basic income, I can afford a small apartment."
    mc "No. Tra lo stipendio e il reddito di base posso permettermi un piccolo appartamento."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:65
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5be1c16f:

    # mc "Actually, it's in the same neighborhood as [ll.name!t]!"
    mc "In realtà è nello stesso quartiere di [ll.name!t]!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:68
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_71f6f124:

    # dd "Oh, what a coincidence!"
    dd "Oh, che coincidenza!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:70
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_2bb7c91a:

    # dd "If you see her, would you mind telling [ll.name!t] to turn on her phone?"
    dd "Se la vedessi, ti dispiacerebbe dire a [ll.name!t] di accendere il suo telefono?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:71
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_b09f665a:

    # dd "I arrived a week earlier than planned, but her phone's always off. I couldn't let her know."
    dd "Sono arrivata una settimana prima del previsto, ma il suo telefono è sempre spento. Non potevo farglielo sapere."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:73
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_91c2a0d5:

    # dd "If you see him, would you mind telling [ll.name!t] to turn on his phone?"
    dd "Se lo vedessi, ti dispiacerebbe dire a [ll.name!t] di accendere il suo telefono?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:74
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0b7ebef4:

    # dd "I arrived a week earlier than planned, but his phone's always off. I couldn't let him know."
    dd "Sono arrivato una settimana prima del previsto, ma il suo telefono è sempre spento. Non potevo farglielo sapere."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:77
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0bb54b06:

    # mc "{act}laughs{/act} Classic [ll.name!t], yeah."
    mc "{act}ride{/act} Classico [ll.name!t], sì."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:79
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_35841bd2:

    # mc "Don't worry, I'll tell her as soon as I see her!"
    mc "Non preoccuparti, glielo dirò appena la vedo!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:81
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_308f5b00:

    # mc "Don't worry, I'll tell him as soon as I see him!"
    mc "Non preoccuparti, glielo dirò appena lo vedo!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:84
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f0e22bc8:

    # dd "Thanks, [mc.name!t]."
    dd "Grazie, [mc.name!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:87
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_154c1bdc:

    # mc_t "I can't believe I'm talking to [dd.name!t]..."
    mc_t "Non posso credere che sto parlando con [dd.name!t]..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:89
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_bb93c0ec:

    # mc_t "Does she remember the last time we spoke? I hope not..."
    mc_t "Si ricorda l'ultima volta che abbiamo parlato? spero di no..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:91
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_71177772:

    # mc_t "Does he remember the last time we spoke? I hope not..."
    mc_t "Si ricorda l'ultima volta che abbiamo parlato? spero di no..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:102
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5468cf46:

    # mc_t "Okay, here's the plan..." with dis_std
    mc_t "Ok, ecco il piano..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:104
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_cdd9278c:

    # mc_t "Step 1: approach her and greet her."
    mc_t "Passaggio 1: avvicinati a lei e salutala."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:106
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c8fa494c:

    # mc_t "Step 1: approach him and greet him."
    mc_t "Passaggio 1: avvicinati a lui e salutalo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:107
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_8f076f0d:

    # mc_t "Step 2: bring up a casual topic of conversation, to set the mood."
    mc_t "Passaggio 2: affronta un argomento di conversazione casuale, per creare l'atmosfera."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:108
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1cb76c53:

    # mc_t "Step 3: ask... uh..."
    mc_t "Passaggio 3: chiedi... ehm..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:112
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:114
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f9789a30:

    # mc_t "That ass is insane..."
    mc_t "Quel culo è pazzesco..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:116
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_54cc23fe:

    # mc_t "That back is insane..."
    mc_t "Quella schiena è pazzesca..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:117
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5e2c6600:

    # mc_t "G-God damn it [mc.name!t], FOCUS! This is your last chance!"
    mc_t "Dio mio, dannazione [mc.name!t], CONCENTRATI! Questa è la tua ultima possibilità!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:120
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_a2745659:

    # mc_t "Ummm... Where was I?" with dis_std_med
    mc_t "Uhm... dov'ero?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:121
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ca7d0d84:

    # mc_t "Step..."
    mc_t "Passo..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:124
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ed3b32ca:

    # dd "Huh?" with dis_std
    dd "Eh?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:125
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_641cdcff:

    # mc_t "SHIT, I'VE GONE BLANK."
    mc_t "MERDA, SONO RIMASTO IN BIANCO."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:128
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_061292b8:

    # dd "[mc.name!t]?"
    dd "[mc.name!t]?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:131
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_df957a2a:

    # mc_t "WHAT DO I DO NOW!?"
    mc_t "COSA FACCIO ORA!?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:134
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_d690973d:

    # mc "H-Hey [dd.name!t]!" with dis_std_med
    mc "H-Ehi [dd.name!t]!" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:135
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_65ad2266:

    # mc "I was passing by and... I s-saw you, and then... uh..."
    mc "Stavo passando di lì e... ti ho visto, e poi... uh..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:136
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_45a22267:

    # mc "I remembered something!"
    mc "Mi sono ricordato qualcosa!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:139
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_299f1db1:

    # dd "What is it about?"
    dd "Di cosa si tratta?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:142
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_80a5c16f:

    # mc "Umm..."
    mc "Ehm..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:147
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_310b34ae:

    # mc_t "Oh my god, I'm going crazy{#female} with all these moles..." with dis_std_med
    mc_t "Oh mio Dio, sto impazzendo{#female} con tutti questi nei..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:149
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0be660b1:

    # mc_t "Oh my god, I'm going crazy{#male} with all these moles..." with dis_std_med
    mc_t "Oh mio Dio, sto impazzendo{#male} con tutti questi nei..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:152
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_40028d26:

    # mc_t "Oh my god, I'm going crazy{#female} with his hands..." with dis_std_med
    mc_t "Oh mio Dio, sto impazzendo{#female} con le sue mani..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:154
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_52d4387d:

    # mc_t "Oh my god, I'm going crazy{#male} with his hands..." with dis_std_med
    mc_t "Oh mio Dio, sto impazzendo{#male} con le sue mani..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:156
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5a319387:

    # mc_t "I DON'T EVEN KNOW WHERE TO LOOK."
    mc_t "NON SO NEMMENO DOVE CERCARE."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:159
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_bc84da0f:

    # mc "Today we have... umm..." with dis_std_med
    mc "Oggi abbiamo... ehm..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:162
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_976db001:

    # dd "The History final exam?"
    dd "L'esame finale di Storia?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:165
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6c1f573d:

    # mc "Yes! The exam!"
    mc "SÌ! L'esame!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:166
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_98a6e84e:

    # mc_t "Okay, I got this! Step 2 incoming... setting the mood!"
    mc_t "Ok, ho capito! Fase 2 in arrivo... creare l'atmosfera!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:169
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f5a8cb15:

    # mc_t "Just pretend to be smart{#female}, like her."
    mc_t "Fai finta di essere intelligente{#female}, come lei."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:171
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_4b9b33a7:

    # mc_t "Just pretend to be smart{#female}, like him."
    mc_t "Fai finta di essere intelligente{#female}, come lui."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:174
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_2439b4dc:

    # mc_t "Just pretend to be smart{#male}, like her."
    mc_t "Fai finta di essere intelligente{#male}, come lei."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:176
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_9641c3c4:

    # mc_t "Just pretend to be smart{#male}, like him."
    mc_t "Fai finta di essere intelligente{#male}, come lui."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:179
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_059a2339:

    # mc "I was studying History, and the Vikings totally blew my mind!" with dis_std_med
    mc "Stavo studiando Storia e i Vichinghi mi hanno letteralmente sbalordito!" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:180
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_52affc6d:

    # mc "I mean, how did they even navigate without a compass? You can't see the sun when it's cloudy!"
    mc "Voglio dire, come facevano a navigare senza bussola? Non puoi vedere il sole quando è nuvoloso!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:181
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_325cbeb2:

    # mc "So I looked it up online, and found out they used calcite stones! It seems they glow in a way that reveals the sun's position."
    mc "Così ho cercato online e ho scoperto che usavano pietre di calcite! Sembra che brillino in un modo che rivela la posizione del sole."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:182
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e0d4b75a:

    # mc "How ingenious! Looks like magic, don't you think?"
    mc "Com'è ingegnoso! Sembra una magia, non credi?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:185
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_28ab58fd:

    # dd "Yeah, it's interesting."
    dd "Sì, è interessante."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:186
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c55d73c0:

    # dd "But the Middle Ages exam was last year."
    dd "Ma l'esame di Medioevo era l'anno scorso."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:189
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:190
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_aebbb9e3:

    # mc_t "Fuck."
    mc_t "Fanculo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:193
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_bed97cc6:

    # mc "Y-Yes, of course! I was just reviewing everything, haha."
    mc "S-Sì, certo! Stavo giusto rivedendo tutto, ahah."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:194
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0b71664b:

    # mc "What I wanted to say is..."
    mc "Quello che volevo dire è..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:197
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f3138cd3:

    # mc "...is..." with dis_std_med
    mc "...è..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:200
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0ac30d5f:

    # mc ". . ." with dis_std_med
    mc ". . ." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:202
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_9631bc8a:

    # mc_t "God, this is too much..."
    mc_t "Dio, questo è troppo..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:204
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_57e040a5:

    # mc_t "The lips, the earring, the neck, that little mole near her eye... I can even smell her strawberry perfume from here..."
    mc_t "Le labbra, l'orecchino, il collo, quel piccolo neo vicino all'occhio... riesco persino a sentire il suo profumo di fragola da qui..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:206
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3c9e47ed:

    # mc_t "The lips, the earring, the neck, that little mole near his eye... I can even smell his strawberry perfume from here..."
    mc_t "Le labbra, l'orecchino, il collo, quel piccolo neo vicino all'occhio... riesco persino a sentire il suo profumo di fragola da qui..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:207
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_796e4728:

    # mc_t "This is impossible. I can't think straight."
    mc_t "Questo è impossibile. Non riesco a pensare lucidamente."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:208
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99_2:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:210
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_00614140:

    # mc_t "Fuck it! I'll ask her right away."
    mc_t "Fanculo! Glielo chiederò subito."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:212
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_540b1d04:

    # mc_t "Fuck it! I'll ask him right away."
    mc_t "Fanculo! Glielo chiederò subito."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:213
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_09c4c74b:

    # mc_t "NOW OR NEVER!"
    mc_t "ORA O MAI PIÙ!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:216
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_53e55018:

    # mc "I mentioned the Viking sunstone because they've opened a medieval technology section..." with dis_std_med
    mc "Ho menzionato la pietra solare vichinga perché hanno aperto una sezione dedicata alla tecnologia medievale..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:218
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_719f5ead:

    # mc "I mean, in Verona's Science Museum."
    mc "Voglio dire, al Museo delle Scienze di Verona."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:219
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_d3dbc709:

    # dd "Mm-hm."
    dd "Mm-hm."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:220
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_09b80711:

    # mc "I would like to go, but I don't know anyone interested on that."
    mc "Vorrei andarci, ma non conosco nessuno interessato."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:221
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_4b57d65c:

    # mc "So... I was wondering if..."
    mc "Quindi... mi chiedevo se..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:224
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_da791a13:

    # mc "If you would like to go n-next weekend with..." with dis_std_med
    mc "Se vuoi andare il prossimo fine settimana con..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:225
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_20f97864:

    # mc "...m-me?"
    mc "...m-io?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:228
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_02e41c08:

    # dd "Oh..."
    dd "Oh..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:229
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_33070896:

    # dd "Sorry, but I can't."
    dd "Mi dispiace, ma non posso."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:231
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e527c7d6:

    # dd "That weekend I'm going on a trip with my boyfriend."
    dd "Quel fine settimana farò un viaggio con il mio ragazzo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:233
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_8880c573:

    # dd "That weekend I'm going on a trip with my girlfriend."
    dd "Quel fine settimana farò un viaggio con la mia ragazza."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:243
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_4bcbbedb:

    # dd "If you don't mind, I'm leaving now. Or I'll be late for Physics class!" with dis_std
    dd "Se non ti dispiace, me ne vado adesso. Oppure farò tardi alla lezione di fisica!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:244
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99_3:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:249
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_956621ee:

    # dd "Goodbye, [mc.name!t]!" with dis_std_med
    dd "Addio, [mc.name!t]!" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:250
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_faefac40:

    # dd "See you later at the exam!"
    dd "Ci vediamo più tardi all'esame!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:258
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_fd796af1:

    # mc_t "Damn, that was embarrassing..." with dis_std_med
    mc_t "Cavolo, è stato imbarazzante..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:260
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f2bf985c:

    # mc_t "Does she still have a boyfriend? I mean, it's been 5 years."
    mc_t "Ha ancora un fidanzato? Voglio dire, sono passati 5 anni."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:262
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3e0a75b7:

    # mc_t "Does he still have a girlfriend? I mean, it's been 5 years."
    mc_t "Ha ancora una ragazza? Voglio dire, sono passati 5 anni."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:263
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99_4:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:267
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3501682d:

    # mc_t "WAIT!"
    mc_t "ASPETTARE!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:268
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1257fb87:

    # mc_t "What if this is a sign from the universe!?"
    mc_t "E se questo fosse un segno dell'universo!?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:270
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_030fb796:

    # mc_t "I've got nothing to lose, so... I'll show her my true feelings, and see what happens."
    mc_t "Non ho niente da perdere, quindi... le mostrerò i miei veri sentimenti e vedrò cosa succede."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:271
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e336af82:

    # mc "D-Diana?"
    mc "D-Diana?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:273
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_19aede97:

    # mc_t "I've got nothing to lose, so... I'll show him my true feelings, and see what happens."
    mc_t "Non ho niente da perdere, quindi... gli mostrerò i miei veri sentimenti e vedrò cosa succede."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:274
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3ac07e4d:

    # mc "D-Daniel?"
    mc "D-Daniele?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:277
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ba8cad00:

    # dd "Yes?"
    dd "SÌ?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:280
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_84bc3cf8:

    # mc "I don't know if we'll see each other again. So before we say goodbye, I'd like to confess that..."
    mc "Non so se ci rivedremo. Quindi, prima di salutarci, vorrei confessare che..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:281
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_878bdf6c:

    # mc "W-When we were in high school... I used to look at you."
    mc "W-Quando eravamo al liceo... ti guardavo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:284
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0ef76928:

    # dd "I know, everyone noticed."
    dd "Lo so, se ne sono accorti tutti."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:287
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77a89e99_5:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:288
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_22318f93:

    # mc_t "Of course she knew."
    mc_t "Naturalmente lo sapeva."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:289
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_8082ba42:

    # mc "Y-Yeah, haha."
    mc "S-Sì, ahah."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:290
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_52a0f653:

    # mc "But don't get me wrong! I watched you because..."
    mc "Ma non fraintendermi! Ti ho osservato perché..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:309
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c2e02e6c:

    # mc "Because you're hot{#female} as fuck."
    mc "Perché sei sexy{#female} dannatamente."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:311
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_4f085452:

    # mc "Because you're hot{#male} as fuck."
    mc "Perché sei sexy{#male} dannatamente."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:314
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_928b1821:

    # mc "Because you're hot{#female} as fuck." with dis_std
    mc "Perché sei sexy{#female} dannatamente." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:316
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f08b280b:

    # mc "Because you're hot{#male} as fuck." with dis_std
    mc "Perché sei sexy{#male} dannatamente." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:319
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_72704cc7:

    # dd "Pff, that was it?" with dis_std
    dd "Pff, era tutto?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:320
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_13361c28:

    # dd "You didn't have to say it like that..."
    dd "Non dovevi dirlo così..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:324
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f3bc9a6f:

    # mc "But it's true! You're very attractive{#female}, [dd.name!t]." with dis_std
    mc "Ma è vero! Sei molto attraente{#female}, [dd.name!t]." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:326
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6344fb56:

    # mc "But it's true! You're very attractive{#male}, [dd.name!t]." with dis_std
    mc "Ma è vero! Sei molto attraente{#male}, [dd.name!t]." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:328
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5440a14d:

    # mc "I don't know if we'll meet again, so... I wanted to tell you how I felt."
    mc "Non so se ci rivedremo, quindi... volevo dirti come mi sentivo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:333
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_36ee9e2a:

    # dd "For your information, I'm more than just big tits and a pretty face, okay?" with dis_std
    dd "Per tua informazione, non sono solo grandi tette e un bel viso, ok?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:335
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_163580ed:

    # dd "For your information, I'm more than just muscles and a pretty face, okay?" with dis_std
    dd "Per tua informazione, non sono solo muscoli e un bel viso, ok?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:343
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_fb0196c6:

    # mc_t "Oops... I shouldn't have said that." with dis_std
    mc_t "Ops... non avrei dovuto dirlo." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:344
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6aab99f6:

    # mc "Sorry [dd.name!t], I didn't want to offend you."
    mc "Scusa [dd.name!t], non volevo offenderti."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:345
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f99dca8c:

    # dd ". . ."
    dd ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:346
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_42f41f50:

    # mc "[dd.name!t]?"
    mc "[dd.name!t]?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:347
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f99dca8c_1:

    # dd ". . ."
    dd ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:349
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_63bc8e10:

    # mc_t "Fuck, I've never seen her so upset... Did I touch a sensitive subject?"
    mc_t "Cavolo, non l'ho mai vista così sconvolta... Ho toccato un argomento delicato?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:351
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_b29310ac:

    # mc_t "Fuck, I've never seen him so upset... Did I touch a sensitive subject?"
    mc_t "Cavolo, non l'ho mai visto così sconvolto... Ho toccato un argomento delicato?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:355
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_41fbb916:

    # mc "Because I admired you."
    mc "Perché ti ammiravo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:357
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_cdfa91f3:

    # mc "Because I admired you." with dis_std
    mc "Perché ti ammiravo." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:358
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0217e250:

    # mc "Although we've only spoken a few times, you've always been an inspiration to me..."
    mc "Anche se ci siamo parlati solo poche volte, sei sempre stato un'ispirazione per me..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:359
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ff6ad5e9:

    # mc "Thanks for being who you are."
    mc "Grazie per essere quello che sei."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:362
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_62c36246:

    # dd "Aww~" with dis_std
    dd "Aww~" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:367
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e8612143:

    # dd "That's so sweet, [mc.name!t]!"
    dd "È così dolce, [mc.name!t]!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:368
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7406d893:

    # dd "I really appreciate that you consider me a source of inspiration! It's one of the nicest things you could say."
    dd "Apprezzo davvero che tu mi consideri una fonte di ispirazione! È una delle cose più belle che si possano dire."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:371
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f802c4d0:

    # mc_t "I DID IT! Mission accomplished!"
    mc_t "L'HO FATTO! Missione compiuta!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:373
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c22a6939:

    # mc_t "Now is my chance to get her phone... I can do this!"
    mc_t "Ora ho la possibilità di prendere il suo telefono... posso farcela!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:375
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_74bd34e7:

    # mc_t "Now is my chance to get his phone... I can do this!"
    mc_t "Ora ho la possibilità di prendere il suo telefono... posso farcela!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:380
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c53eaf0c:

    # mc "Because I was bored{#female} in class."
    mc "Perché mi annoiavo{#female} in classe."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:382
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_689ef5ce:

    # mc "Because I was bored{#male} in class."
    mc "Perché mi annoiavo{#male} in classe."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:385
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_dbed31ed:

    # mc "Because I was bored{#female} in class." with dis_std
    mc "Perché mi annoiavo{#female} in classe." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:387
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_235c3613:

    # mc "Because I was bored{#male} in class." with dis_std
    mc "Perché mi annoiavo{#male} in classe." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:389
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f99dca8c_2:

    # dd ". . ."
    dd ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:392
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_29d62ea5:

    # dd "I see."
    dd "Vedo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:396
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_48b59154:

    # mc_t "I'm so stupid{#female}. Why did I say that?"
    mc_t "Sono così stupido{#female}. Perché l'ho detto?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:398
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0de25ae0:

    # mc_t "I'm so stupid{#male}. Why did I say that?"
    mc_t "Sono così stupido{#male}. Perché l'ho detto?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:400
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7f3fb0b8:

    # unknown "{act}yelling{/act} [dd.name!u]!!!"
    unknown "{act}urla{/act} [dd.name!u]!!!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:403
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_b3eb05bb:

    # dd "Oh! It's [oo.name!t]!" with dis_std
    dd "OH! È [oo.name!t]!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:404
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_dae91bc4:

    # mc_t "[oo.name!t]...?"
    mc_t "[oo.name!t]...?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:410
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_504f4899:

    # oo "{act}yelling{/act} What the fuck are you doing!?"
    oo "{act}urla{/act} Che cazzo stai facendo!?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:412
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f4f84cfb:

    # oo "{act}yelling{/act} You weren't answering my calls! I've been looking for you like crazy{#male}, this place is HUGE!"
    oo "{act}urla{/act} Non rispondevi alle mie chiamate! Ti ho cercato come un matto{#male}, questo posto è ENORME!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:414
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_aa884ca8:

    # oo "{act}yelling{/act} You weren't answering my calls! I've been looking for you like crazy{#female}, this place is HUGE!"
    oo "{act}urla{/act} Non rispondevi alle mie chiamate! Ti ho cercato come un matto{#female}, questo posto è ENORME!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:418
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_eac56bd4:

    # dd ". . ." with dis_std_med
    dd ". . ." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:420
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_abd8ec34:

    # dd "Sorry [mc.name!t]!" with dis_std_med
    dd "Mi dispiace [mc.name!t]!" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:422
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_14ac1082:

    # dd "My boyfriend is here, I got to go!"
    dd "Il mio ragazzo è qui, devo andare!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:424
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_03dfca79:

    # dd "My girlfriend is here, I got to go!"
    dd "La mia ragazza è qui, devo andare!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:427
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_49437cad:

    # mc_t "Back to the real world..." with dis_std_med
    mc_t "Ritorno al mondo reale..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:430
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_384d85dd:

    # mc_t "At least I got to see her one more time."
    mc_t "Almeno ho potuto vederla ancora una volta."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:432
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e1857837:

    # mc_t "At least I got to see him one more time."
    mc_t "Almeno ho avuto modo di vederlo ancora una volta."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:435
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_babb3e7c:

    # oo "{act}speaking slowly{/act} Are you aware of how much you just embarrassed me?" with dis_std_med
    oo "{act}parla lentamente{/act} Sei consapevole di quanto mi hai messo in imbarazzo?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:437
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_60801840:

    # oo "I was supposed to introduce you to my new friends{#male}!"
    oo "Avrei dovuto presentarti ai miei nuovi amici{#male}!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:438
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_32d49f55:

    # oo "{act}imitating one of them{#male}{/act} “Suuure, she's in the library... downloading her next update!”"
    oo "{act}imitando uno di loro{#male}{/act} 'Suuure, è nella biblioteca... sta scaricando il suo prossimo aggiornamento!'"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:439
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_cd470f3c:

    # oo "I've been showing them{#male} pictures of you for months! They thought you were an AI, for fuck's sake!!!"
    oo "Sono mesi che mostro loro{#male} le tue foto! Pensavano che fossi un'intelligenza artificiale, per l'amor del cielo!!!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:441
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6cb602bd:

    # oo "I was supposed to introduce you to my new friends{#female}!"
    oo "Avrei dovuto presentarti ai miei nuovi amici{#female}!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:442
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_a07e1b40:

    # oo "{act}imitating one of them{#female}{/act} “Suuure, he's in the library... downloading his next update!”"
    oo "{act}imitando uno di loro{#female}{/act} 'Suuure, è nella biblioteca... sta scaricando il suo prossimo aggiornamento!'"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:443
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f5aeeea5:

    # oo "I've been showing them{#female} pictures of you for months! They thought you were an AI, for fuck's sake!!!"
    oo "Sono mesi che mostro loro{#female} le tue foto! Pensavano che fossi un'intelligenza artificiale, per l'amor del cielo!!!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:447
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_68a59756:

    # mc_t "This is the guy [dd.name!t] was dating in high school?" with dis_std_med
    mc_t "Questo è il ragazzo con cui [dd.name!t] usciva al liceo?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:449
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_f74fe4c9:

    # mc_t "This is the girl [dd.name!t] was dating in high school?" with dis_std_med
    mc_t "Questa è la ragazza con cui [dd.name!t] usciva al liceo?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:452
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_613ada13:

    # mc_t "What an asshole{#male}..."
    mc_t "Che stronzo{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:454
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e32536a9:

    # mc_t "What a bitch..."
    mc_t "Che stronza..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:458
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e5253b39:

    # oo "Look, you're my girlfriend, okay?" with dis_std_med
    oo "Senti, tu sei la mia ragazza, ok?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:460
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6d70f53a:

    # oo "Look, you're my boyfriend, okay?" with dis_std_med
    oo "Senti, tu sei il mio ragazzo, ok?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:461
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c514d8c8:

    # oo "Next time, if we agree to meet somewhere and you get there first, you stay put until I show up."
    oo "La prossima volta, se decidiamo di incontrarci da qualche parte e tu arrivi per primo, rimani lì finché non arrivo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:462
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_27c08fea:

    # oo "Is that clear?"
    oo "È chiaro?"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:465
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_5275b380:

    # dd "Sorry honey, I totally lost track of time." with dis_std
    dd "Scusa tesoro, ho perso completamente la cognizione del tempo." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:467
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c25d4845:

    # dd "I just got there too early, and... wanted to see the library again, so..."
    dd "È solo che sono arrivato troppo presto e... volevo rivedere la biblioteca, quindi..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:468
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_b5b4eeee:

    # dd "I came here and muted my phone."
    dd "Sono venuto qui e ho disattivato l'audio del telefono."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:471
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_41f4ca81:

    # oo "What the fuck are you talking about!?" with dis_std_med
    oo "Di che cazzo stai parlando!?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:472
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_fb4643d9:

    # oo "It's Saturday! And you don't have to study anymore!"
    oo "È sabato! E non devi più studiare!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:473
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1fff53bb:

    # dd "Come on, don't be mad~"
    dd "Dai, non arrabbiarti~"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:474
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_a4fb6724:

    # dd "When we get home, I'll cook you something tasty for dinner!"
    dd "Quando torniamo a casa, ti cucinerò qualcosa di gustoso per cena!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:475
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_ed53674e:

    # oo ". . ."
    oo ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:476
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_019c7b3f:

    # oo "Okay."
    oo "Va bene."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:477
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7cd91826:

    # mc_t "That was easy."
    mc_t "È stato facile."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:481
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_80e5c2b7:

    # oo "Who was that girl you were talking to?" with dis_std_med
    oo "Chi era quella ragazza con cui stavi parlando?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:482
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_70fa2dfc:

    # dd "Just an old classmate{#female} from high school."
    dd "Solo un vecchio compagno di classe{#female} del liceo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:484
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_77fc5f9b:

    # dd "I found her asleep in the study room, but I got worried for nothing..."
    dd "L'ho trovata addormentata nello studio, ma mi sono preoccupata per niente..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:486
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c1237a62:

    # dd "{act}lowering her voice{/act} I got a little worried because I found her asleep in the study room. The poor girl is depressed..."
    dd "{act}abbassando la voce{/act} Mi sono preoccupato un po' perché l'ho trovata addormentata nello studio. La povera ragazza è depressa..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:488
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_6ca6eb18:

    # dd "{act}lowering his voice{/act} I got a little worried because I found her asleep in the study room. The poor girl is depressed..."
    dd "{act}abbassando la voce{/act} Mi sono preoccupato un po' perché l'ho trovata addormentata nello studio. La povera ragazza è depressa..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:490
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_25a354a5:

    # oo "Who was that dude you were talking to?" with dis_std_med
    oo "Chi era quel tizio con cui stavi parlando?" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:491
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3d3b6de6:

    # dd "Just an old classmate{#male} from high school."
    dd "Solo un vecchio compagno di classe{#male} del liceo."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:493
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_3965f0dd:

    # dd "I found him asleep in the study room, but I got worried for nothing..."
    dd "L'ho trovato addormentato nello studio, ma mi sono preoccupata per niente..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:495
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_23fcbce2:

    # dd "{act}lowering her voice{/act} I got a little worried because I found him asleep in the study room. The poor boy is depressed..."
    dd "{act}abbassando la voce{/act} Mi sono preoccupata un po' perché l'ho trovato addormentato nello studio. Il povero ragazzo è depresso..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:497
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c150cc2a:

    # dd "{act}lowering his voice{/act} I got a little worried because I found him asleep in the study room. The poor boy is depressed..."
    dd "{act}abbassando la voce{/act} Mi sono un po' preoccupato perché l'ho trovato addormentato nello studio. Il povero ragazzo è depresso..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:500
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_e0b17f6b:

    # oo "Haha, what a loser{#female}."
    oo "Ahah, che perdente{#female}."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:502
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7e5ee36f:

    # oo "Haha, what a loser{#male}."
    oo "Ahah, che perdente{#male}."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:505
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_092c30d0:

    # dd "{act}laughs{/act}"
    dd "{act}ride{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:507
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_7c1fa3ac:

    # dd "{act}laughs{/act} Hey~, don't be mean{#male}!"
    dd "{act}ride{/act} Ehi~, non essere cattivo{#male}!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:509
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_589a02d1:

    # dd "{act}laughs{/act} Hey~, don't be mean{#female}!"
    dd "{act}ride{/act} Ehi~, non essere cattivo{#female}!"

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:512
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_0ac30d5f_1:

    # mc ". . ." with dis_std_med
    mc ". . ." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:513
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_8fb26067:

    # mc_t "This is too painful."
    mc_t "Questo è troppo doloroso."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:516
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1269eee1:

    # mc "{act}turning around{/act} {think}I don't want to keep looking at them.{/think}" with dis_std_med
    mc "{act}mi volto{/act} {think}Non voglio continuare a guardarli.{/think}" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:518
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_2eb1e522:

    # mc_t "But [oo.name!t] is right. I'm a loser{#female}..."
    mc_t "Ma [oo.name!t] ha ragione. Sono un perdente{#female}..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:520
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_c038ede2:

    # mc_t "But [oo.name!t] is right. I'm a loser{#male}..."
    mc_t "Ma [oo.name!t] ha ragione. Sono un perdente{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:521
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1dd9a20b:

    # mc "{act}sighs{/act}"
    mc "{act}sospira{/act}"

translate italian strings:

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:295
    old "{#BOND-INCORRECT}You're hot{#female} as fuck.{#chapter1x1-choice01}"
    new "{#BOND-INCORRECT}Sei sexy{#female} dannatamente.{#chapter1x1-choice01}"

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:297
    old "{#BOND-INCORRECT}You're hot{#male} as fuck.{#chapter1x1-choice01}"
    new "{#BOND-INCORRECT}Sei sexy{#male} da morire.{#chapter1x1-choice01}"

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:299
    old "{#BOND-CORRECT}I admired you.{#chapter1x1-choice01}"
    new "{#BOND-CORRECT}Ti ammiravo.{#chapter1x1-choice01}"

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:301
    old "I was bored{#female} in class.{#chapter1x1-choice01}"
    new "Mi annoiavo{#female} in classe.{#chapter1x1-choice01}"

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:303
    old "I was bored{#male} in class.{#chapter1x1-choice01}"
    new "Mi annoiavo{#male} in classe.{#chapter1x1-choice01}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:292
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_345749b7:

    # mc_t "Of course he knew."
    mc_t "Naturalmente lo sapeva."

# game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/script.rpy:404
translate italian scene__book1__c1_awakening__e01_the_public_library__s02_reality_hits_hard_1b6929f6:

    # unknown "{act}yelling{/act} [dd.name!tu]!!!"
    unknown "{act}urla{/act} [dd.name!tu]!!!"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
