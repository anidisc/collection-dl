﻿
# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:141
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_97c6f3b6:

    # mc_t "Here I am, world!"
    mc_t "Eccomi, mondo!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:143
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_393af7b0:

    # mc_t "Ready{#female} to start my adventure!"
    mc_t "Pronto{#female} per iniziare la mia avventura!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:145
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_c5b3ea6b:

    # mc_t "Ready{#male} to start my adventure!"
    mc_t "Pronto{#male} per iniziare la mia avventura!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:148
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_0db32e07:

    # mc_t "It's been more than 8 months since I decided to change my life..." with dis_std_med
    mc_t "Sono passati più di 8 mesi da quando ho deciso di cambiare vita..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:149
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_9d61b95f:

    # mc_t "And now, look at me! I'm pure fire!"
    mc_t "E ora, guardami! Sono puro fuoco!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:151
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_14cbfe08:

    # mc_t "[mc.name!t] [mc.surname!t] has been reborn, and her mission is clear: to defeat nature, and forge a new future for humanity!"
    mc_t "[mc.name!t] [mc.surname!t] è rinata e la sua missione è chiara: sconfiggere la natura e forgiare un nuovo futuro per l'umanità!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:153
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_f08faeef:

    # mc_t "[mc.name!t] [mc.surname!t] has been reborn, and his mission is clear: to defeat nature, and forge a new future for humanity!"
    mc_t "[mc.name!t] [mc.surname!t] è rinato e la sua missione è chiara: sconfiggere la natura e forgiare un nuovo futuro per l'umanità!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:154
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_dfa6836b:

    # mc_t "Sounds pretty cool, right?"
    mc_t "Sembra piuttosto interessante, vero?"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:157
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_9228b22d:

    # mc_t "My science-link is already finished." with dis_std_med
    mc_t "Il mio collegamento scientifico è già terminato." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:159
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_7eadd82c:

    # mc_t "So from now on, no matter where I go. The power of science will always be with me!"
    mc_t "Quindi da ora in poi, non importa dove andrò. Il potere della scienza sarà sempre con me!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:163
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_932efc26:

    # mc_t "I feel really proud{#female}." with dis_std_med
    mc_t "Mi sento davvero orgoglioso{#female}." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:165
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_4c4b45e1:

    # mc_t "I feel really proud{#male}." with dis_std_med
    mc_t "Mi sento davvero orgoglioso{#male}." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:166
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_f3a35e92:

    # mc_t "After all, this is my first invention! I didn't expect to finish it so fast!"
    mc_t "Dopotutto, questa è la mia prima invenzione! Non mi aspettavo di finirlo così in fretta!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:169
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_4cd1a14f:

    # mc_t "My new life starts today..." with dis_std_med
    mc_t "La mia nuova vita inizia oggi..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:171
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_0d7e2b41:

    # mc "{act}smirks{/act}"
    mc "{act}sorride{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:172
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_c26e5911:

    # mc_t "And it will be the greatest adventure of all time!"
    mc_t "E sarà la più grande avventura di tutti i tempi!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:174
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_a2535916:

    # mc_t "I'M SO EXCITED{#female}!!!"
    mc_t "SONO COSÌ ECCITATO{#female}!!!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:176
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_1f7ef78f:

    # mc_t "I'M SO EXCITED{#male}!!!"
    mc_t "SONO COSÌ ECCITATO{#male}!!!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:179
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_a064bae0:

    # mc_t "Are you watching, world?" with dis_std_med
    mc_t "Stai guardando, mondo?" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:181
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_7171a698:

    # mc_t "Anyone would say that my dream is impossible..."
    mc_t "Chiunque direbbe che il mio sogno è impossibile..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:182
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_2058a294:

    # mc_t "But I know I can do it!"
    mc_t "Ma so che posso farcela!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:185
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_31adf06c:

    # mc_t "Because..." with dis_std_med
    mc_t "Perché..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:187
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_217a7d0c:

    # mc_t "I'm a human being."
    mc_t "Sono un essere umano."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:188
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_249fdd9f:

    # mc_t "If something doesn't exist, I can imagine it and create it with my own hands."
    mc_t "Se qualcosa non esiste, posso immaginarlo e crearlo con le mie mani."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:189
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_547e9171:

    # mc_t "From scratch. Step by step. Like science does!"
    mc_t "Da zero. Passo dopo passo. Come fa la scienza!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:200
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_29bcc315:

    # mc_t "Alright!" with dis_std
    mc_t "Bene!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:201
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_f3fb6b47:

    # mc_t "Today is the entrance exam for the University of Verona. And I never thought I'd say this, but..."
    mc_t "Oggi è l'esame di ammissione all'Università di Verona. E non avrei mai pensato di dirlo, ma..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:202
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_d427cd69:

    # mc_t "I'm taking that exam!"
    mc_t "Sto facendo quell'esame!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:203
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_24792931:

    # mc_t "If I pass, they'll give me a scholarship and a student permit, which means I'll be able to access Verona's Center."
    mc_t "Se passo, mi danno una borsa di studio e un permesso per studenti, quindi potrò accedere al Centro di Verona."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:204
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_bd89daa9:

    # mc_t "Yes, it won't be easy. But I think it's worth a shot."
    mc_t "Sì, non sarà facile. Ma penso che valga la pena provare."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:205
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step_32d3eaa8:

    # mc_t "Let's go!"
    mc_t "Andiamo!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:265
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__gadgets_0a8feb69:

    # mc_t "This is the charger for my science-link." with dis_std
    mc_t "Questo è il caricabatterie per il mio collegamento scientifico." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:266
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__gadgets_11f42f9e:

    # mc_t "It's wireless!"
    mc_t "È senza fili!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:274
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__painting_cafd0be1:

    # mc_t "“A sailboat doesn't sail, it's pushed by the wind”." with dis_std
    mc_t "“Una barca a vela non naviga, è spinta dal vento”." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:275
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__painting_bf3a0364:

    # mc_t "My grandpa used to say that."
    mc_t "Mio nonno lo diceva."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:276
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__painting_74e161c6:

    # mc_t "His point was that reality is a chain of causes and effects, not a collection of inexplicable miracles."
    mc_t "Il suo punto era che la realtà è una catena di cause ed effetti, non una raccolta di miracoli inspiegabili."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:283
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__globe_024567f3:

    # mc_t "When astronauts see Earth from outer space, some of them experience “the overview effect”." with dis_std
    mc_t "Quando gli astronauti vedono la Terra dallo spazio, alcuni di loro sperimentano “l’effetto panoramica”." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:284
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__globe_15cd6afc:

    # mc_t "Basically, they see a beautiful world, without borders, and they come home shocked by how fake our values are."
    mc_t "Fondamentalmente vedono un mondo bellissimo, senza confini, e tornano a casa scioccati da quanto siano falsi i nostri valori."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:285
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__globe_ad7ae33e:

    # mc_t "We are one planet, one species."
    mc_t "Siamo un pianeta, una specie."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:286
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__globe_54a545f7:

    # mc_t "Do we all have to become astronauts to understand that?"
    mc_t "Dobbiamo diventare tutti astronauti per capirlo?"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:293
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__telescope_9e01919d:

    # mc_t "Even though it's a bad place to see the stars, you can still see some planets or the Moon itself." with dis_std
    mc_t "Anche se è un brutto posto per vedere le stelle, puoi comunque vedere alcuni pianeti o la Luna stessa." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:294
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__telescope_b4e610c5:

    # mc_t "Telescopes are soooo cool..."
    mc_t "I telescopi sono davvero fantastici..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:346
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__window_3826af10:

    # mc_t "What a beautiful day!" with dis_std
    mc_t "Che bella giornata!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:347
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__window_8f9e302d:

    # mc_t "Since I installed this roller blind, I also sleep better."
    mc_t "Da quando ho installato questa tenda a rullo dormo anche meglio."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:348
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__window_f8a8c9b6:

    # mc_t "But the best part is..."
    mc_t "Ma la parte migliore è..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:353
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__window_945ebca2:

    # mc_t "Look at this BEAUTY!"
    mc_t "Guarda questa BELLEZZA!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:354
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__window_372343d2:

    # mc_t "This is what I call a good air conditioner! No more hellish summers!"
    mc_t "Questo è quello che chiamo un buon condizionatore d'aria! Niente più estati infernali!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:397
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__books_43ebbd4e:

    # mc_t "Reading has become an important part of my life." with dis_std
    mc_t "La lettura è diventata una parte importante della mia vita." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:398
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__books_cee2dc5a:

    # mc_t "It's like... talking through time with other people. Learning from their experiences, you know."
    mc_t "It's like... talking through time with other people. Imparando dalle loro esperienze, lo sai."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:405
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__desktop_0aa1d8a8:

    # mc_t "I wanted a more ambitious renovation, but this was all I could afford." with dis_std
    mc_t "Volevo una ristrutturazione più ambiziosa, ma questo era tutto ciò che potevo permettermi." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:406
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__desktop_bd22f868:

    # mc_t "At least I have a new desk, and a decent chair."
    mc_t "Almeno ho una nuova scrivania e una sedia decente."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:407
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__desktop_13c3235a:

    # mc_t "Not bad!"
    mc_t "Non male!"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:451
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__bed_5c842960:

    # mc "{act}looks at the bed{/act}" with dis_std
    mc "{act}guarda il letto{/act}" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:452
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__bed_0d7e2b41:

    # mc "{act}smirks{/act}"
    mc "{act}sorride{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:467
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_e2ccd8d4:

    # phone "{act}notification{/act}" with dis_std
    phone "{act}notifica{/act}" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:468
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_1b2569e2:

    # mc_t "Hmm?"
    mc_t "Ehm?"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:469
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_2dc6f249:

    # mc "{act}reading on your phone{/act} {think}“The University of Verona regrets to inform you that the entrance exam has been postponed indefinitely.”{/think}"
    mc "{act}lettura sul cellulare{/act} {think}“L'Università degli Studi di Verona è spiacente di informarvi che l'esame di ammissione è stato rinviato a data da destinarsi.”{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:470
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_9d20fa6e:

    # mc_t "Oh..."
    mc_t "Oh..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:471
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_63fb8d38:

    # mc "{act}reading on your phone{/act} {think}“For security reasons, the examination center will remain closed until further notice. Thanks for your attention.”{/think}"
    mc "{act}lettura sul telefono{/act} {think}'Per motivi di sicurezza, il centro esami rimarrà chiuso fino a nuovo avviso. Grazie per l'attenzione.'{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:472
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:473
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_5d74f435:

    # mc_t "My luck is terrible, haha."
    mc_t "La mia fortuna è terribile, ahah."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:474
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_46ed7186:

    # mc_t "But no problem! I can do other things while—"
    mc_t "Ma nessun problema! Posso fare altre cose mentre..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:477
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_4b2d29ec:

    # phone "{act}notification{/act}"
    phone "{act}notifica{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:478
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:479
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_b639f8b7:

    # mc_t "What now?"
    mc_t "E adesso?"

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:482
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_779de6ba:

    # mc "{act}starts reading{/act}" with dis_std_long
    mc "{act}inizia a leggere{/act}" with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:483
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_ca5740ed:

    # mc_t "No... It can't be..."
    mc_t "No... non può essere..."

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:488
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_9773a43a:

    # mc "{act}keeps reading{/act}" with dis_std_long
    mc "{act}continua a leggere{/act}" with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/script.rpy:489
translate italian scene__book1__c1_awakening__e04_radical_change__s06_the_first_step__kitchen_from_outside_eb94f958:

    # mc_t "But that's... impossible..."
    mc_t "Ma questo è... impossibile..."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
