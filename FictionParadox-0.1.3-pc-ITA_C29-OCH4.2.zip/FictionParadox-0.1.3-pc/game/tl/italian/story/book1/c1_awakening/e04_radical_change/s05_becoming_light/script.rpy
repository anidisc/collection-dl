﻿
# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:44
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_f33920f1:

    # mc "I want to dye my hair." with dis_std
    mc "Voglio tingermi i capelli." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:45
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_51e1ede1:

    # hairdresser "Perfect!"
    hairdresser "Perfetto!"

# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:46
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_1e5a1cba:

    # hairdresser "Tell me, what color do you want?"
    hairdresser "Dimmi, che colore vuoi?"

# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:49
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_0ac30d5f:

    # mc ". . ." with dis_std_med
    mc ". . ." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:64
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_23a0a3dc:

    # mc "Red."
    mc "Rosso."

# game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/script.rpy:65
translate italian scene__book1__c1_awakening__e04_radical_change__s05_becoming_light_40b2da1d:

    # mc "I want it red."
    mc "Lo voglio rosso."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
