﻿
# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:18
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_96375d68:

    # mc_t "Phew! We haven't opened yet, thank goodness." with dis_std
    mc_t "Uff! Non abbiamo ancora aperto, grazie al cielo." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:19
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_9bb8d584:

    # mc "Hello Isabella!"
    mc "Ciao Isabella!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:22
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_8993c60e:

    # isabella "You're late, wey."
    isabella "Sei in ritardo, ehi."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:27
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_0df7e969:

    # mc_t "This is Isabella, my coworker{#female}." with dis_std
    mc_t "Questa è Isabella, la mia collega{#female}." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:29
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_570e353a:

    # mc_t "She handles customers and runs our social media. Always glued to her phone..."
    mc_t "Si occupa dei clienti e gestisce i nostri social media. Sempre incollato al cellulare..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:34
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c0ebeb28:

    # isabella "The boss is very angry with you, as usual." with dis_std
    isabella "Il capo è molto arrabbiato con te, come al solito." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:37
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_987090bb:

    # mc "But we haven't open ye—"
    mc "Ma non ti abbiamo aperto—"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:38
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_4827e6a8:

    # grabbman "{size=*1.7}[mc.name!tu] [mc.surname!tu]!!!{/size}"
    grabbman "{size=*1.7}[mc.name!tu] [mc.surname!tu]!!!{/size}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:45
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_661f5ee3:

    # mc "Y-Yes, Mr. Grabbman!"
    mc "S-sì, signor Grabbman!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:48
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_66a3c43e:

    # grabbman "How dare you be late on such an important day!?"
    grabbman "Come osi arrivare in ritardo in un giorno così importante!?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:53
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_08db196e:

    # mc_t "This is my boss, Frankie Grabbman." with dis_std
    mc_t "This is my boss, Frankie Grabbman." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:55
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_5d53d465:

    # mc_t "He owns a bunch of—"
    mc_t "Possiede un sacco di..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:61
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c9d5ddc9:

    # grabbman "Wipe that clueless look{#female} off your face!"
    grabbman "Togliti quello sguardo da incapace{#female} dalla faccia!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:63
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_34449526:

    # grabbman "Wipe that clueless look{#male} off your face!"
    grabbman "Togliti quello sguardo da incapace{#male} dalla faccia!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:64
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_a5fb053f:

    # grabbman "Today is Crazy Pizza Day! There will be lots of orders, and YOU must deliver them all on time!"
    grabbman "Oggi è il Crazy Pizza Day! Ci saranno moltissimi ordini e TU dovrai consegnarli tutti in tempo!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:67
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_d3a7414c:

    # mc_t "Oh, crap... I totally forgot."
    mc_t "Oh, merda... me ne ero completamente dimenticato."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:70
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_e3d10916:

    # grabbman "Get your ass moving already!"
    grabbman "Muovi già il culo!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:73
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_9efa0005:

    # mc "Yes, sir."
    mc "Sì, signore."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:79
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_3ecba73c:

    # mc_t "I'll never understand why a job like mine exists with so many robots around..."
    mc_t "Non capirò mai perché esiste un lavoro come il mio con così tanti robot in giro..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:80
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_009539e1:

    # mc_t "Strange as it sounds, tons of jobs are still manual."
    mc_t "Per quanto strano possa sembrare, tantissimi lavori sono ancora manuali."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:81
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_60896885:

    # mc_t "Government pays businesses if they hire humans. Supposedly, to give unemployed people “a purpose”."
    mc_t "Il governo paga le imprese se assumono persone. Presumibilmente, per dare ai disoccupati “uno scopo”."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:86
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_e1ba46f2:

    # mc_t "But if you ask me, it just keeps people running in circles..."
    mc_t "Ma secondo me, fa sì che le persone continuino a girare in tondo..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:87
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_26b4b01d:

    # mc_t "My boss doesn't care about that, of course. He owns a bunch of companies, and one of his slog—"
    mc_t "Al mio capo questo non interessa, ovviamente. Possiede un sacco di aziende e uno dei suoi slogan..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:88
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_792f2f6e:

    # mc_t "Oh, wait, the delivery!"
    mc_t "Oh, aspetta, la consegna!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:103
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f978e24b:

    # mc "Here's your order, {i}monsieur!{/i}"
    mc "Ecco il tuo ordine, {i}signore!{/i}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:104
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_71a36688:

    # mc "We're glad you chose our services! Nothing beats that human touch, right?"
    mc "Siamo felici che tu abbia scelto i nostri servizi! Niente batte quel tocco umano, giusto?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:105
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_8f5d31fc:

    # mc "{i}Bon appétit!{/i}"
    mc "{i}Buon appetito!{/i}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:111
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_72edbb85:

    # mc_t "I hate putting on that smile sooo much..."
    mc_t "Odio così tanto indossare quel sorriso..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:112
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_fb5083fd:

    # mc_t "As I was saying, one of the slogans of my boss is “made by humans”."
    mc_t "Come dicevo, uno degli slogan del mio capo è “made by human”."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:113
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7c869104:

    # mc_t "Not out of kindness, but because that way he can get subsidies from the government, and keep most of it for himself."
    mc_t "Non per gentilezza, ma perché in questo modo può ottenere sussidi dal governo e tenerne la maggior parte per sé."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:114
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_3bdb0907:

    # mc_t "What a bastard..."
    mc_t "Che bastardo..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:129
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c9e64efe:

    # mc "Piping hot pizza, fresh from the oven!"
    mc "Pizza bollente, appena sfornata!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:130
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_0857b168:

    # mc "Thank you so much for choosing us! We added extra cheese, just as you requested."
    mc "Grazie mille per averci scelto! Abbiamo aggiunto altro formaggio, proprio come hai richiesto."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:131
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_66b77778:

    # mc "Enjoy~!"
    mc "Divertitevi~!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:137
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c6d4b36b:

    # mc_t "But hey, I can't complain."
    mc_t "Ma ehi, non posso lamentarmi."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:138
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_8c07ffa2:

    # mc_t "Without these odd jobs, people like me would be stuck living on basic income forever. And no one wants to be poor, you know."
    mc_t "Senza questi lavori saltuari, le persone come me sarebbero costrette a vivere per sempre con il reddito di base. E nessuno vuole essere povero, lo sai."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:143
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_04f563f2:

    # mc_t "In the end, all of us need more money, for whatever reason."
    mc_t "Alla fine, tutti noi abbiamo bisogno di più soldi, qualunque sia il motivo."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:144
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7901b309:

    # mc_t "It doesn't matter whether our work is useful or not. As long as we get paid... it's enough."
    mc_t "Non importa se il nostro lavoro sia utile o meno. Finché veniamo pagati... è abbastanza."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:145
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_ff7b2180:

    # mc_t "Ha! What a circus."
    mc_t "Ah! Che circo."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:163
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_088154be:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:164
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7ad7707a:

    # mc_t "Why won't they open the door?"
    mc_t "Perché non aprono la porta?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:171
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f3d6a602:

    # mc_t "Come oooon, I don't have all day..." with dis_std
    mc_t "Dai, non ho tutto il giorno..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:179
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7cb15c46:

    # unknown "{act}moaning{/act}" with dis_std_long
    unknown "{act}gemito{/act}" with dis_std_long

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:180
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:181
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_976183aa:

    # mc_t "There's no way..."
    mc_t "Non c'è modo..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:182
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_1837b2a7:

    # mc_t "Are they... doing it?"
    mc_t "Lo stanno facendo?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:184
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_74deb9a9:

    # mc_t "Right now? With me standing{#female} here? This has to be a joke or something..."
    mc_t "Proprio adesso? Con me qui{#female}? Dev'essere uno scherzo o qualcosa del genere..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:186
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f12b6f7a:

    # mc_t "Right now? With me standing{#male} here? This has to be a joke or something..."
    mc_t "Adesso? Con me qui{#male}? Dev'essere uno scherzo o qualcosa del genere..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:201
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f7c8343d:

    # mc_t "But I need to check... uh... customer's{#female} availability."
    mc_t "Ma devo verificare... ehm... la disponibilità del cliente{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:203
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f2c893fe:

    # mc_t "But I need to check... uh... customer's{#male} availability."
    mc_t "Ma devo verificare... ehm... la disponibilità del cliente{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:206
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_782ed9d9:

    # mc_t "I need to check... uh... customer's{#female} availability." with dis_std
    mc_t "Devo verificare... ehm... la disponibilità del cliente{#female}." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:208
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_cc377f79:

    # mc_t "I need to check... uh... customer's{#male} availability." with dis_std
    mc_t "Devo verificare... ehm... la disponibilità del cliente{#male}." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:209
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f8186dec:

    # mc_t "Y-Yeah, that's right!"
    mc_t "S-sì, è vero!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:210
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_60068ea1:

    # mc_t "The reasons are strictly professional."
    mc_t "Le ragioni sono strettamente professionali."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:211
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_23132b68:

    # mc_t "I mean, what if they need help or something? Perhaps I'm misinterpreting the sounds..."
    mc_t "Voglio dire, e se avessero bisogno di aiuto o qualcosa del genere? Forse sto interpretando male i suoni..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:220
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_b97a4e74:

    # dyn_customer1 "{act}moaning{/act} Mmm...{w} Hmmm...{w} Hmmmmm..." with dis_std_long
    dyn_customer1 "{act}gemito{/act} Mmm...{w} Hmmm...{w} Hmmmmm..." with dis_std_long

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:222
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_9be85de3:

    # mc_t "T-They are actually doing it!"
    mc_t "T-Lo stanno facendo davvero!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:225
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_10c1b578:

    # dyn_customer2 "I knew you'd like it, babe{#female}..."
    dyn_customer2 "Sapevo che ti sarebbe piaciuto, tesoro{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:226
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_1c7ea396:

    # dyn_customer2 "You love it when I pound your pussy with this strap-on, don't you?"
    dyn_customer2 "Ti piace quando ti colpisco la figa con questo strap-on, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:228
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_10c1b578_1:

    # dyn_customer2 "I knew you'd like it, babe{#female}..."
    dyn_customer2 "Sapevo che ti sarebbe piaciuto, tesoro{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:229
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_edd37d20:

    # dyn_customer2 "You love it when I pound your pussy like this, don't you?"
    dyn_customer2 "Ti piace quando ti colpisco la figa in questo modo, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:231
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c6405767:

    # dyn_customer2 "I knew you'd like it, babe{#male}..."
    dyn_customer2 "Sapevo che ti sarebbe piaciuto, tesoro{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:232
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_ea4941a3:

    # dyn_customer2 "You love it when I'm on top riding your cock, don't you?"
    dyn_customer2 "Ti piace quando sono sopra, cavalcando il tuo cazzo, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:234
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_c6405767_1:

    # dyn_customer2 "I knew you'd like it, babe{#male}..."
    dyn_customer2 "Sapevo che ti sarebbe piaciuto, tesoro{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:235
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_758782de:

    # dyn_customer2 "You love it when I pound your ass like this, don't you?"
    dyn_customer2 "Ti piace quando ti colpisco il culo in questo modo, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:237
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_5fc8131c:

    # dyn_customer1 "{act}moaning{/act} Hm-hm..."
    dyn_customer1 "{act}gemito{/act} Hm-hm..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:239
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_ce2ac0a0:

    # dyn_customer2 "{act}chuckles{/act} Hehe... Right now, the delivery girl is listening to your lewd moans."
    dyn_customer2 "{act}ridacchia{/act} Hehe... In questo momento, la ragazza delle consegne sta ascoltando i tuoi gemiti osceni."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:241
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_62dc159a:

    # dyn_customer2 "{act}chuckles{/act} Hehe... Right now, the delivery guy is listening to your lewd moans."
    dyn_customer2 "{act}ridacchia{/act} Hehe... In questo momento, il ragazzo delle consegne sta ascoltando i tuoi lamenti osceni."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:244
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_d075d97c:

    # dyn_customer2 "It turns you on{#female}, doesn't it?"
    dyn_customer2 "Ti eccita{#female}, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:246
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_bc6109e6:

    # dyn_customer2 "It turns you on{#male}, doesn't it?"
    dyn_customer2 "Ti eccita{#male}, vero?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:248
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_24b35b45:

    # dyn_customer1 "{act}keeps moaning{/act}"
    dyn_customer1 "{act}continua a gemere{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:249
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_792b8506:

    # mc_t "Oh my god, they don't care at all I'm here!"
    mc_t "Oh mio Dio, a loro non importa affatto che sono qui!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:252
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7afccce2:

    # dyn_customer2 "You're so fucking wet..."
    dyn_customer2 "Sei così dannatamente bagnato..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:254
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_29e44c4e:

    # dyn_customer2 "You're so fucking hard..."
    dyn_customer2 "Sei così dannatamente duro..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:257
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_b7111686:

    # dyn_customer2 "Bet she's wondering what's going on... But {i}only I{/i} can see your cute face..."
    dyn_customer2 "Scommetto che si sta chiedendo cosa sta succedendo... Ma {i}solo io{/i} posso vedere il tuo bel faccino..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:259
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_1a44a81f:

    # dyn_customer2 "Bet he's wondering what's going on... But {i}only I{/i} can see your cute face..."
    dyn_customer2 "Scommetto che si sta chiedendo cosa sta succedendo... Ma {i}solo io{/i} posso vedere il tuo bel faccino..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:261
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_31896536:

    # dyn_customer1 "{act}moaning{/act} Hmmmm~"
    dyn_customer1 "{act}gemito{/act} Hmmmm~"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:262
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_058fd218:

    # dyn_customer2 "Do you want more? Want me to go harder?"
    dyn_customer2 "Ne vuoi di più? Vuoi che vada più forte?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:263
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_00a16a44:

    # dyn_customer1 "{act}moaning{/act} Mm-hm..."
    dyn_customer1 "{act}gemito{/act} Mm-hm..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:272
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_46bcce55:

    # dyn_customer2 "Like this, babe{#female}!?"
    dyn_customer2 "Così, tesoro{#female}!?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:274
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_a2f3edd6:

    # dyn_customer2 "Like this, babe{#male}!?"
    dyn_customer2 "Così, tesoro{#male}!?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:275
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_e7cfbe64:

    # dyn_customer1 "{act}moaning{/act} {sc=1.1}Ah~!{w} AHH~!{w} AAHHH~!{/sc}"
    dyn_customer1 "{act}gemito{/act} {sc=1.1}Ah~!{w} AHH~!{w} AAHHH~!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:276
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_035e8ffc:

    # mc_t "How intense..."
    mc_t "Che intensità..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:277
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_a3e14849:

    # dyn_customer2 "Oh my fucking god, YES!"
    dyn_customer2 "Oh mio maledetto Dio, SÌ!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:278
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_8f17f629:

    # dyn_customer2 "LET IT OUT!"
    dyn_customer2 "LASCIATELO FUORI!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:279
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7ea0be5c:

    # dyn_customer2 "I WANT EVERYONE TO HEAR YOUR LEWD MOANS!"
    dyn_customer2 "VOGLIO CHE TUTTI SENTINO I TUOI GEMENTI LASCIATI!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:280
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_360b4783:

    # dyn_customer1 "{act}moaning{/act} {sc=1.1}AHHHHH!!{/sc}"
    dyn_customer1 "{act}gemito{/act} {sc=1.1}AHHHHH!!{/sc}"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:284
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_5b18e9b9:

    # mc_t "I wouldn't be able to fuck at that pace."
    mc_t "Non riuscirei a scopare a quel ritmo."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:286
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7944414e:

    # mc_t "I mean, they're so into it{#female}..."
    mc_t "Voglio dire, sono così presi{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:288
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_fce393a5:

    # mc_t "I mean, they're so into it{#male}..."
    mc_t "Voglio dire, sono così presi{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:290
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7663aaec:

    # mc_t "I mean, they're so into it{#both-genders}..."
    mc_t "Voglio dire, sono così presi{#both-genders}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:291
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_1496b19b:

    # mc_t "The few times I've had sex were so unfortunate, that I'd rather not remember them."
    mc_t "Le poche volte che ho fatto sesso sono state così sfortunate che preferirei non ricordarle."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:292
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:293
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_278c2951:

    # mc_t "Oh shit, the pizzas."
    mc_t "Oh merda, le pizze."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:305
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_ad816742:

    # mc_t "Damn degenerates{#female}..."
    mc_t "Maledetti degenerati{#female}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:307
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_7bb46677:

    # mc_t "Damn degenerates{#male}..."
    mc_t "Maledetti degenerati{#male}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:309
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_6662837c:

    # mc_t "Damn degenerates{#both-genres}..."
    mc_t "Maledetti degenerati{#both-genres}..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:310
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_f3775c33:

    # mc_t "You ordered a pizza just because of some twisted kink!?"
    mc_t "Hai ordinato una pizza solo per qualche capriccio!?"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:311
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_84655fe9:

    # mc_t "My god! People are crazy these days..."
    mc_t "Mio Dio! La gente è pazza di questi tempi..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:316
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_9de05eb8:

    # mc_t "Okay, here's the last one..."
    mc_t "Ok, ecco l'ultimo..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:317
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_8591e85e:

    # mc_t "Let's hope it doesn't take me too long, or my boss is going to kill me."
    mc_t "Speriamo che non ci metta troppo tempo, altrimenti il mio capo mi ucciderà."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:332
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_6e33b667:

    # mc "Here's your pizza, gentleman!"
    mc "Ecco la tua pizza, signore!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:333
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_88cb3c75:

    # mc "Thank you so mu—"
    mc "Grazie mille—"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:336
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_5058dbaf:

    # customer3 "The offer stated delivery in less than 30 minutes."
    customer3 "L'offerta prevedeva la consegna in meno di 30 minuti."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:339
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_73c43c9f:

    # mc "I know, but—"
    mc "Lo so, ma..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:342
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_4deb095b:

    # customer3 "I want my money back."
    customer3 "Rivoglio i miei soldi."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:345
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_e15a7e21:

    # mc "There was a bit of traffic, sir!"
    mc "C'era un po' di traffico, signore!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:346
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_2f76cde6:

    # mc "But doooon't worry! Your pizza is in perfect condition!"
    mc "Ma non preoccuparti! La tua pizza è in perfette condizioni!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:349
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_a56d71c9:

    # customer3 "I'm not going to eat it cold..."
    customer3 "Non lo mangerò freddo..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:352
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_85966ef5:

    # mc "You can heat it up in the microwave, and it will be like new!"
    mc "Puoi scaldarlo nel microonde e sarà come nuovo!"

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:355
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_1a97b109:

    # customer3 "Sorry, but I'll pass."
    customer3 "Scusa, ma passo."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:356
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_e6fc3ae9:

    # customer3 "If you don't know how to do your damn job, find something else to do! I'll request a refund..."
    customer3 "Se non sai fare il tuo dannato lavoro, trova qualcos'altro da fare! Chiederò il rimborso..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:362
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_fab11bc1:

    # customer3 "{act}closes the door{/act}" with dis_std
    customer3 "{act}chiude la porta{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:364
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_77a89e99_2:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:367
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_67a32107:

    # mc "{act}sighs{/act}" with dis_std_med
    mc "{act}sospira{/act}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:369
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_6ff593ff:

    # mc_t "I'm sick{#female} of everything..."
    mc_t "Sono stufo{#female} di tutto..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:371
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_151adc4d:

    # mc_t "I'm sick{#male} of everything..."
    mc_t "Sono stufo{#male} di tutto..."

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:374
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_eec71787:

    # mc ". . ." with dis_std_long
    mc ". . ." with dis_std_long

translate italian strings:

    # game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:91
    old "DELIVER{#pizza}"
    new "CONSEGNA{#pizza}"

    # game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:191
    old "{#BOND-CORRECT}Listen closely{#chapter1x1-choice06}"
    new "{#BOND-CORRECT}Ascolta attentamente{#chapter1x1-choice06}"

    # game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:193
    old "Leave the pizza and keep working{#chapter1x1-choice06}"
    new "Lascia la pizza e continua a lavorare{#chapter1x1-choice06}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e03_lonely_life/s02_pizza_delivery/script.rpy:263
translate italian scene__book1__c1_awakening__e03_lonely_life__s02_pizza_delivery_00a16a44_1:

    # dyn_customer1 "{act}moaning{/act} Mm-hm..."
    dyn_customer1 "{act}gemito{/act} Mm-hm..."

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
