﻿
translate italian strings:

    # game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/scene.rpy:6
    old "Fragments of a Nightmare{#story-scene}"
    new "Frammenti di un incubo{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
