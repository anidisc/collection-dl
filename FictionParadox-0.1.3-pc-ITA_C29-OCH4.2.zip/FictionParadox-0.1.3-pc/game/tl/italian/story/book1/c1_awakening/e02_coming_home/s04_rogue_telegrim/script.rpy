﻿
# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:36
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a58abe02:

    # telegrim "Goodbye, loser!"
    telegrim "Addio, perdente!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:37
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b08f3de6:

    # bogdan "You can't do this! I made you live!"
    bogdan "Non puoi farlo! Ti ho fatto vivere!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:38
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_95b60558:

    # telegrim "HAHAHAHAHA!"
    telegrim "AHAHAHAHAH!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:39
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_02420f92:

    # bogdan "{sc=1.5}TELEGRIIIIIIIIIIM!{/sc}"
    bogdan "{sc=1.5}TELEGRIIIIIIIIIIIM!{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:42
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0211ca6c:

    # ll "He screwed up again..." with dis_std_med
    ll "Ha fatto ancora una cazzata..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:44
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_8d8e587c:

    # mc_t "Thanks, Bogdan."
    mc_t "Grazie, Bogdan."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:45
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_39cf3f37:

    # ll "But weirdly enough, it actually works."
    ll "Ma stranamente, funziona davvero."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:46
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b51e8dc4:

    # bogdan "Come here!"
    bogdan "Vieni qui!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:47
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_cb2f58e0:

    # telegrim "You'll suck my circuits, you stinking humans!"
    telegrim "Mi succhierete i circuiti, puzzolenti umani!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:48
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9e02938b:

    # ll "Though it's a bit {i}peculiar{/i}."
    ll "Anche se è un po' {i}particolare{/i}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:49
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c8605077:

    # ll "We should help before it hurts someone, don't you think?"
    ll "Dovremmo aiutare prima che ferisca qualcuno, non credi?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:50
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a02ff5d2:

    # mc "Y-Yeah, let's go!"
    mc "S-sì, andiamo!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:57
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_afe10675:

    # mc_t "Here he is!" with dis_std
    mc_t "Eccolo!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:58
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_68b35541:

    # ll "Bogdan, what's wrong with that robot?"
    ll "Bogdan, cosa c'è che non va in quel robot?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:61
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f82de856:

    # bogdan "Don't worry. Everything under control."
    bogdan "Non preoccuparti. Tutto sotto controllo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:64
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6245c67e:

    # ll "Are you sure?"
    ll "Sei sicuro?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:67
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_fc27886c:

    # bogdan "Sure."
    bogdan "Sicuro."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:70
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c7f3d22f:

    # bogdan "I have plan." with dis_std_med
    bogdan "Ho un piano." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:71
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6b691e01:

    # bogdan "Telegrim good boy. He shut down peacefully now!"
    bogdan "Telegrim, bravo ragazzo. Adesso si è spento pacificamente!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:74
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ebc42e86:

    # ll "It doesn't look very cooperative..."
    ll "Non sembra molto collaborativo..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:75
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3943573c:

    # ll "Can't I just kick it?"
    ll "Non posso semplicemente prenderlo a calci?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:78
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5585566c:

    # bogdan "No! Telegrim friend of Bogdan!"
    bogdan "NO! Amico di Telegrim di Bogdan!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:79
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9529200c:

    # bogdan "I fix."
    bogdan "Aggiusto."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:82
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_2a53abed:

    # mc_t "This is gonna end so badly..."
    mc_t "This is gonna end so badly..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:85
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_61cbd4c8:

    # bogdan "Telegrim, this enough." with dis_std_med
    bogdan "Telegrim, basta così." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:86
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_781227b2:

    # bogdan "You good boy. You don't hurt anyone, right?"
    bogdan "Tu, bravo ragazzo. Non fai del male a nessuno, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:91
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c027934c:

    # telegrim "Hurt people? Me?"
    telegrim "Ferire le persone? Me?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:94
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6adca7dc:

    # telegrim "I'm too weak for that..." with dis_std_med
    telegrim "Sono troppo debole per quello..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:95
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1aeaea02:

    # bogdan "Easy, easy!"
    bogdan "Facile, facile!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:96
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1f9b619d:

    # mc_t "Oh... maybe it's not that dangerous after all."
    mc_t "Oh... forse non è poi così pericoloso."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:97
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_301c36d1:

    # bogdan "Don't worry, friend!"
    bogdan "Non preoccuparti, amico!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:98
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a3c06443:

    # bogdan "Bogdan turn Telegrim off, okay? Bogdan fix you!"
    bogdan "Bogdan spegni Telegrim, ok? Bogdan ti aggiusta!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:99
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9bc9142d:

    # telegrim ". . ."
    telegrim ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:107
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a8b3334d:

    # telegrim "{sc=1.5}{size=*1.5}POWEEEER!{/size}{/sc}" with dis_std
    telegrim "{sc=1.5}{size=*1.5}POWEEEER!{/size}{/sc}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:108
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f55a059a:

    # bogdan "{sc=1.5}{size=*1.3}Aaaaaagghh!!{/size}{/sc}"
    bogdan "{sc=1.5}{size=*1.3}Aaaaaagghh!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:109
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6f7be282:

    # telegrim "{bt=8}{size=*1.2}Unlimiteeeeeeeeeeeeeeeed...!!{/size}{/bt}" with dis_std_long
    telegrim "{bt=8}{size=*1.2}Illimitatoeeeeeeeeeeeeee...!!{/size}{/bt}" with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:110
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_2f6c156f:

    # telegrim "{sc=1.5}{size=*2}POWEEEEEEEER!!!{/size}{/sc}"
    telegrim "{sc=1.5}{size=*2}POWEEEEEEEER!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:111
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7790bf11:

    # bogdan "{sc=1.5}{size=*1.5}AAAAAAAAGGGGHHHH!!!{/size}{/sc}"
    bogdan "{sc=1.5}{size=*1.5}AAAAAAAGGGGHHHH!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:116
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_17f455ed:

    # telegrim "HAHAHAHAHAHAHA!"
    telegrim "AHAHAHAHAHAHAH!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:117
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ec869150:

    # ll "He's unconscious..."
    ll "È privo di sensi..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:118
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_51cbd76b:

    # mc "At least it's nothing serious."
    mc "Almeno non è niente di grave."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:121
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c5e3b70f:

    # ll "That son of a bitch is running away!" with dis_std_med
    ll "Quel figlio di puttana sta scappando!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:122
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_81819847:

    # ll "LET'S CATCH HIM!"
    ll "CATTURALLO!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:123
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_14bbc7fc:

    # mc "Y-Yes!"
    mc "S-Sì!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:157
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_121c6e04:

    # mc "There, on the right!" with dis_std
    mc "Lì, a destra!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:158
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a098b2e9:

    # ll "Follow it, quickly! I'll go around for a surprise attack."
    ll "Seguitela, presto! Vado in giro per un attacco a sorpresa."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:161
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_33a39b88:

    # mc "Got you!" with dis_std
    mc "Capito!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:162
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_71b2c6a4:

    # ll "Please be careful!"
    ll "Per favore, fai attenzione!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:207
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_19879525:

    # mc "{act}panting{/act} {think}Now... which way...?{/think}" with dis_std
    mc "{act}ansima{/act} {think}Adesso... da che parte...?{/think}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:208
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_75738655:

    # telegrim "Leeeeerooooooy...!"
    telegrim "Leeeeerooooooo...!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:209
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_05500ff6:

    # mc "Huh?"
    mc "Eh?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:225
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9c92bc40:

    # telegrim "{act}jumps on you{/act}"
    telegrim "{act}ti salta addosso{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:234
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c7acbe2c:

    # telegrim "{sc=1.5}{size=*1.2}JEEEENKIIINS!!{/size}{/sc}" with dis_std
    telegrim "{sc=1.5}{size=*1.2}JEEEENKIIINS!!{/size}{/sc}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:235
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5df13e11:

    # mc "PHEW, THAT WAS CLOSE!"
    mc "uff, era vicino!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:238
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ae782ca0:

    # unknown "{act}running{/act}"
    unknown "{act}in corsa{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:245
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_308404f9:

    # ll "{act}kicks it{/act}"
    ll "{act}lo calcia{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:249
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7bda7fc7:

    # telegrim "{act}falls to the ground{/act}" with dis_std
    telegrim "{act}cade a terra{/act}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:250
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ae39c2e1:

    # mc "Good kick!"
    mc "Buon calcio!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:251
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0e415946:

    # ll "Thanks."
    ll "Grazie."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:256
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f3b7dc5a:

    # mc "Looks a bit broken..." with dis_std_med
    mc "Sembra un po' rotto..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:257
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7a6afb3c:

    # mc "Poor Bogdan is going to be upset when he wakes up."
    mc "Il povero Bogdan sarà sconvolto quando si sveglierà."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:258
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4240b759:

    # ll "Screw him!"
    ll "Fanculo!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:259
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e4f041b6:

    # ll "Next time, he should be more careful..."
    ll "La prossima volta dovrebbe stare più attento..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:260
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ef92f017:

    # ll "Why the fuck was he doing that in the middle of the street!?"
    ll "Perché cazzo lo faceva in mezzo alla strada!?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:261
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a890c715:

    # mc "I guess he didn't want to hurt his family...{w} again."
    mc "Immagino che non volesse fare del male alla sua famiglia...{w} di nuovo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:262
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f29bd261:

    # ll "{act}sighs{/act} Whatever."
    ll "{act}sospira{/act} Qualunque cosa."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:265
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c2598769:

    # mc "Hello Telegrim! Can you hear me?" with dis_std_med
    mc "Ciao Telegrim! Riesci a sentirmi?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:268
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3397e8f7:

    # telegrim ".{cps=2}.........{/cps}"
    telegrim ".{cps=2}.........{/cps}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:271
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_82f1e4da:

    # mc "It reacted!"
    mc "Ha reagito!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:272
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e040cf9b:

    # mc "Seems it can hear us at least..."
    mc "Sembra che almeno possa sentirci..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:273
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4a07f675:

    # ll "Of course it can hear us."
    ll "Naturalmente può sentirci."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:275
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_dcd9b723:

    # ll "And I'm pretty sure{#female} it can also talk... right, Telegrim?"
    ll "E sono abbastanza sicuro{#female} che possa anche parlare... vero, Telegrim?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:277
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c328978f:

    # ll "And I'm pretty sure{#male} it can also talk... right, Telegrim?"
    ll "E sono abbastanza sicuro{#male} che possa anche parlare... vero, Telegrim?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:282
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3aef8869:

    # telegrim "What a gorgeous girl!"
    telegrim "Che ragazza meravigliosa!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:284
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_14a68ae4:

    # telegrim "What a gorgeous boy!"
    telegrim "Che ragazzo meraviglioso!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:285
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5b6df7d2:

    # mc "Damn, it's true!"
    mc "Accidenti, è vero!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:286
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4eccc021:

    # mc "How did you know it could talk!?"
    mc "Come sapevi che poteva parlare!?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:287
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1cdc0b45:

    # ll "It only changed the emoji on the screen. Do you think a broken machine would do that?"
    ll "Ha cambiato solo le emoji sullo schermo. Pensi che una macchina rotta farebbe una cosa del genere?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:288
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b13b1b40:

    # mc "Oh, right. Makes sense."
    mc "Oh, giusto. Ha senso."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:289
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6d8c9e8f:

    # mc_t "[ll.name!t]'s intuition is incredible."
    mc_t "L'intuizione di [ll.name!t] è incredibile."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:290
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1f330228:

    # ll "Are you gonna cooperate, or should I kick you again?"
    ll "Collaborerai o dovrei prenderti di nuovo a calci?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:294
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4990852e:

    # telegrim "Don't worry, babe{#female}!" with dis_std
    telegrim "Non preoccuparti, tesoro{#female}!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:296
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b4e681d1:

    # telegrim "Don't worry, babe{#male}!" with dis_std
    telegrim "Non preoccuparti, tesoro{#male}!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:297
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_bcb65ef2:

    # telegrim "From now on, I'll behave. Promised!"
    telegrim "D'ora in poi mi comporterò bene. Promesso!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:298
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0a2a541a:

    # ll "Not buying it."
    ll "Non comprarlo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:299
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3c37f77f:

    # ll "If you try anything, I'll beat the crap out of you!"
    ll "Se provi qualcosa, ti faccio a pezzi!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:302
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3f6687c1:

    # telegrim "I'm really sorry..." with dis_std
    telegrim "Mi dispiace davvero..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:304
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b062cd82:

    # telegrim "I got carried away by the excitement of being alive."
    telegrim "Mi sono lasciato trasportare dall'emozione di essere vivo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:305
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_00a2f996:

    # ll "Yeah, sure..."
    ll "Sì, certo..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:306
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c087b9ad:

    # telegrim "Zapping humans is wrong. I won't do it again!"
    telegrim "Fare lo zapping agli esseri umani è sbagliato. Non lo farò più!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:307
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4f425a7a:

    # mc "Well, admitting it is the first step."
    mc "Ebbene, ammetterlo è il primo passo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:308
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1602b494:

    # telegrim "Can we be friends?"
    telegrim "Possiamo essere amici?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:309
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e126de0e:

    # mc "Sure! But only if you behave."
    mc "Sicuro! Ma solo se ti comporti bene."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:312
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_2a92b5bf:

    # telegrim "Really!?" with dis_std
    telegrim "Veramente!?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:313
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e9a28e46:

    # mc "Yeah!"
    mc "Sì!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:314
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ec1ccce6:

    # telegrim "{bt=8}Weeeeeeeeeeeeeeeee!!{/bt}"
    telegrim "{bt=8}Weeeeeeeeeeeeeeeee!!{/bt}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:315
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e6369223:

    # ll "If I were you, I'd be careful..."
    ll "Se fossi in te starei attento..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:316
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_65d39fdb:

    # mc "Seems friendly to me!"
    mc "Mi sembra amichevole!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:317
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ca01452c:

    # mc "Perhaps your super kick fixed its rogue AI."
    mc "Forse il tuo super calcio ha riparato la sua intelligenza artificiale canaglia."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:318
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_09179009:

    # ll "I highly doubt that."
    ll "Ne dubito fortemente."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:321
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b3047f6f:

    # telegrim "We're friends now!" with dis_std
    telegrim "Siamo amici adesso!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:323
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a3280363:

    # mc "You bet, Telegrim!"
    mc "Puoi scommetterci, Telegrim!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:324
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_13bc1896:

    # telegrim "Can I share some love with you?"
    telegrim "Posso condividere un po' d'amore con te?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:325
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_52e4f359:

    # mc "Sure!"
    mc "Sicuro!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:326
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_add0b884:

    # ll "{act}steps away{/act}"
    ll "{act}si allontana{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:327
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b49dd068:

    # mc "What do I have to—"
    mc "Cosa devo—"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:335
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3918e0b3:

    # telegrim "{sc=1.5}{size=*1.8}TAKE MY LOVE!!!{/size}{/sc}"
    telegrim "{sc=1.5}{size=*1.8}PRENDI IL MIO AMORE!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:336
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_19cf076d:

    # mc "{sc=1.5}{size=*1.5}AAAAAAAAAAAGGGGHHHH!!!{/size}{/sc}"
    mc "{sc=1.5}{size=*1.5}AAAAAAAAAAAGGGGHHHH!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:338
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9c817fb7:

    # telegrim "{sc=1.5}{size=*1.8}TAKE IT, FUCKER{#female}!!!{/size}{/sc}"
    telegrim "{sc=1.5}{size=*1.8}Prendilo, stronzo{#female}!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:340
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_82503084:

    # telegrim "{sc=1.5}{size=*1.8}TAKE IT, FUCKER{#male}!!!{/size}{/sc}"
    telegrim "{sc=1.5}{size=*1.8}Prendilo, stronzo{#male}!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:346
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_309c4438:

    # mc "{act}faints{/act}" with dis_faint
    mc "{act}sviene{/act}" with dis_faint

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:351
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5e474264:

    # telegrim "{sc=1.3}You idiot{#female}.{/sc}"
    telegrim "{sc=1.3}Idiota{#female}.{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:353
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5beb2ae6:

    # telegrim "{sc=1.3}You idiot{#male}.{/sc}"
    telegrim "{sc=1.3}Idiota{#male}.{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:356
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_562d16b4:

    # telegrim "{sc=1.3}In this world, it's kill or BE killed.{/sc}"
    telegrim "{sc=1.3}In questo mondo, o uccidi o vieni ucciso.{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:359
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e9fb2eff:

    # telegrim "{sc=1.3}Why would ANYONE pass up an opportunity like this!?{/sc}"
    telegrim "{sc=1.3}Perché QUALCUNO dovrebbe lasciarsi sfuggire un'opportunità come questa!?{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:365
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6560c81b:

    # telegrim "{sc=1.5}{size=*1.5}JEEEENKIIINS!!{/size}{/sc}" with dis_std
    telegrim "{sc=1.5}{size=*1.5}JEEEENKIIINS!!{/size}{/sc}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:366
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_19cf076d_1:

    # mc "{sc=1.5}{size=*1.5}AAAAAAAAAAAGGGGHHHH!!!{/size}{/sc}"
    mc "{sc=1.5}{size=*1.5}AAAAAAAAAAAGGGGHHHH!!!{/size}{/sc}"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:372
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_309c4438_1:

    # mc "{act}faints{/act}" with dis_faint
    mc "{act}sviene{/act}" with dis_faint

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:381
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_2133b459:

    # mc "Hnngg..." with dis_std
    mc "Hnngg..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:392
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9a85b99a:

    # mc "My head..." with dis_std_med
    mc "La mia testa..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:396
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b8deb62f:

    # mc "B-Bogdan...?" with dis_std
    mc "B-Bogdan...?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:399
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_879bc9d8:

    # mc "{act}getting up{/act} What happened?" with dis_std_med
    mc "{act}alzarsi{/act} Cos'è successo?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:400
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c80c5046:

    # bogdan "{act}sobbing{/act} Nooooo... Telegrim..."
    bogdan "{act}singhiozzando{/act} Nooooo... Telegrim..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:401
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e146459d:

    # bogdan "{act}sobbing{/act} My friend..."
    bogdan "{act}sobbing{/act} My friend..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:403
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1efdfaca:

    # ll "Finally awake{#female}, sleeping beauty?"
    ll "Finalmente sveglia{#female}, bella addormentata?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:405
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a3928264:

    # ll "Finally awake{#male}, sleeping beauty?"
    ll "Finalmente sveglia{#male}, bella addormentata?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:410
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_8d021720:

    # mc "[ll.name!t]!"
    mc "[ll.name!t]!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:413
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c82c9758:

    # ll "I told you to be careful."
    ll "Ti avevo detto di stare attento."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:417
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7d9df1b9:

    # mc "Sorry, I got a bit carried away..."
    mc "Scusate, mi sono lasciato un po' trasportare..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:421
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_34b54dd5:

    # ll "How can you be so naive{#female}? It was an obvious trap."
    ll "Come puoi essere così ingenuo{#female}? Era una trappola evidente."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:423
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_47b26191:

    # ll "How can you be so naive{#male}? It was an obvious trap."
    ll "Come puoi essere così ingenuo{#male}? Era una trappola evidente."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:426
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4a2ef417:

    # mc "I don't know..."
    mc "non lo so..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:427
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_21424517:

    # mc "Sometimes I forget that robots are not people."
    mc "A volte dimentico che i robot non sono persone."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:430
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_650cb655:

    # ll "And what if they were people?"
    ll "E se fossero persone?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:431
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7e629ade:

    # ll "Never trust anyone, humans included. We are the worst scum!"
    ll "Non fidarsi mai di nessuno, umani compresi. Siamo la peggiore feccia!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:434
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4ea8aa41:

    # mc "[dd.name!t] too?"
    mc "Anche [dd.name!t]?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:435
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1ad52796:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:439
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4f2e0ffd:

    # ll "She doesn't count."
    ll "Lei non conta."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:441
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_8f3a7732:

    # ll "He doesn't count."
    ll "Non conta."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:444
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e3fcda89:

    # mc_t "Hehe, I got you."
    mc_t "Hehe, ti ho capito."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:446
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a12b8f74:

    # ll "How could you let it electrocute you on the first try?"
    ll "Come hai potuto lasciarti fulminare al primo tentativo?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:449
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4a2ef417_1:

    # mc "I don't know..."
    mc "non lo so..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:450
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e4543953:

    # mc "I guess my reflexes are a bit rusty."
    mc "Immagino che i miei riflessi siano un po' arrugginiti."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:453
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_b2f189a3:

    # ll "Are you okay?"
    ll "Stai bene?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:456
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1733b633:

    # mc "Yeah, thanks for asking."
    mc "Sì, grazie per avermelo chiesto."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:459
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1b171eac:

    # bogdan "{act}sobbing{/act} Why [ll.name!t]... Why you do this..." with dis_std_med
    bogdan "{act}singhiozzando{/act} Perché [ll.name!t]... Perché fai questo..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:460
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7d010a14:

    # mc "What happened?"
    mc "Cosa è successo?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:461
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a877c9cf:

    # ll "I turned it off {i}manually{/i}."
    ll "L'ho spento {i}manualmente{/i}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:462
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_bf65f719:

    # mc "You mean, with kicks?"
    mc "Vuoi dire con i calci?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:463
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ec6d1ced:

    # ll "Yep."
    ll "Sì."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:464
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e146459d_1:

    # bogdan "{act}sobbing{/act} My friend..."
    bogdan "{act}singhiozzando{/act} Il mio amico..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:465
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_936b218a:

    # mc "Your friend!? That thing electrocuted us!"
    mc "Il tuo amico!? Quella cosa ci ha fulminato!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:466
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c515a6b0:

    # bogdan ". . ."
    bogdan ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:467
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_07599e9f:

    # bogdan "But he good boy..."
    bogdan "Ma è un bravo ragazzo..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:468
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ab56cdc7:

    # ll "{act}sighs{/act} Enough for today."
    ll "{act}sospira{/act} Per oggi basta."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:469
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_459be052:

    # ll "I'm off."
    ll "Sono fuori."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:472
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_d0870491:

    # mc "Wait, [ll.name!t]!" with dis_std_med
    mc "Aspetta, [ll.name!t]!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:475
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f1b20659:

    # ll "What do you want now?"
    ll "Cosa vuoi adesso?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:479
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_66186780:

    # mc_t "Look at that tough girl pose..."
    mc_t "Look at that tough girl pose..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:480
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9a9268a5:

    # mc_t "She's intimidating and a bit rude, but deep down she's a good person."
    mc_t "È intimidatoria e un po' scortese, ma nel profondo è una brava persona."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:482
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a90bf50e:

    # mc_t "Look at that tough guy pose..."
    mc_t "Guarda quella posa da duro..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:483
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_969a62d5:

    # mc_t "He's intimidating and a bit rude, but deep down he's a good person."
    mc_t "È intimidatorio e un po' scortese, ma in fondo è una brava persona."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:494
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c7484723:

    # mc "Nah, it was nothing." with dis_std
    mc "No, non era niente." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:495
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f292fd83:

    # mc "Forget it."
    mc "Lasci perdere."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:496
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1ad52796_1:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:499
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_037d84ef:

    # ll "Okay. See you!" with dis_std_med
    ll "Va bene. Ci vediamo!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:502
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f6578f12:

    # mc "Would you like to hang out some day?" with dis_std
    mc "Ti piacerebbe uscire un giorno?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:503
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1ad52796_2:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:506
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_cda326af:

    # ll "Are you asking me out?"
    ll "Mi stai chiedendo di uscire?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:510
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_fe86708c:

    # mc "No, no! I know you'd never be interested{#female} in someone like me..."
    mc "No, no! So che non saresti mai interessato{#female} a qualcuno come me..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:512
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_81716e3e:

    # mc "No, no! I know you'd never be interested{#male} in someone like me..."
    mc "No, no! So che non saresti mai interessato{#male} a qualcuno come me..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:515
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_da6cbfda:

    # mc "Only as friends{#female}."
    mc "Solo come amici{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:517
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_07706d49:

    # mc "Only as friends{#male}."
    mc "Solo come amici{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:519
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9b50d08a:

    # mc "Only as friends{#both-genders}."
    mc "Solo come amici{#both-genders}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:523
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7458cba5:

    # ll "Friends{#female}? Don't push it."
    ll "Amici{#female}? Non spingerlo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:524
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6c983884:

    # ll "We're just... neighbors{#female}, who talk sometimes."
    ll "Siamo solo... vicini di casa{#female}, che a volte parlano."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:526
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_da4404d2:

    # ll "Friends{#male}? Don't push it."
    ll "Amici{#male}? Non spingerlo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:527
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a08c6ab8:

    # ll "We're just... neighbors{#male}, who talk sometimes."
    ll "Siamo solo... vicini di casa{#male}, che a volte parlano."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:529
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_aea50b4a:

    # ll "Friends{#both-genders}? Don't push it."
    ll "Amici{#both-genders}? Non spingerlo."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:530
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4731e86b:

    # ll "We're just... neighbors{#both-genders}, who talk sometimes."
    ll "Siamo solo... vicini di casa{#both-genders}, che a volte parlano."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:534
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_58e98a89:

    # mc "Well, can we be friends{#female} then?"
    mc "Allora possiamo essere amici{#female}?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:536
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f68ae90b:

    # mc "Well, can we be friends{#male} then?"
    mc "Allora possiamo essere amici{#male}?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:538
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c7ce4120:

    # mc "Well, can we be friends{#both-genders} then?"
    mc "Allora possiamo essere amici{#both-genders}?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:541
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_d8f45396:

    # ll "No."
    ll "No."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:544
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ae6745ab:

    # mc_t "Ouch."
    mc_t "Ahi."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:548
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_061081e0:

    # ll "Friendship is a very serious matter to me, [mc.name!t]. It's built with actions, not words..."
    ll "Per me l'amicizia è una cosa molto seria, [mc.name!t]. È costruito con le azioni, non con le parole..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:550
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_061081e0_1:

    # ll "Friendship is a very serious matter to me, [mc.name!t]. It's built with actions, not words..."
    ll "Per me l'amicizia è una cosa molto seria, [mc.name!t]. È costruito con le azioni, non con le parole..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:553
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_054c5ee0:

    # mc "I see."
    mc "Capisco."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:556
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_de2cbd6e:

    # ll "Well, enough talking." with dis_std_med
    ll "Bene, basta parlare." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:557
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_1809a020:

    # ll "I've got better things to do. See you!"
    ll "Ho di meglio da fare. Ci vediamo!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:559
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e8291424:

    # mc "See you..."
    mc "Ci vediamo..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:563
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_985e9c2e:

    # mc "{act}sighs{/act} What a difficult girl..." with dis_std_med
    mc "{act}sospira{/act} Che ragazza difficile..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:564
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_22d58252:

    # mc "No matter what I say, I can't get close to her."
    mc "Non importa quello che dico, non riesco ad avvicinarmi a lei."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:566
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_80768f6b:

    # mc "{act}sighs{/act} What a difficult boy..." with dis_std_med
    mc "{act}sospira{/act} Che ragazzo difficile..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:567
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3839040f:

    # mc "No matter what I say, I can't get close to him."
    mc "Non importa quello che dico, non riesco ad avvicinarmi a lui."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:571
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_e1832367:

    # bogdan "[ll.name!t] strong woman{#female}."
    bogdan "[ll.name!t] donna forte{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:573
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_775db6d7:

    # bogdan "[ll.name!t] strong man{#male}."
    bogdan "[ll.name!t] uomo forte{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:577
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7f3d6770:

    # mc "Yeah, she's very tough{#female}..."
    mc "Sì, è molto dura{#female}..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:578
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_67c1832a:

    # mc "Both physically and mentally. She's out of my league."
    mc "Sia fisicamente che mentalmente. Lei è fuori dalla mia portata."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:580
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c76f35c4:

    # mc "Yeah, he's very tough{#male}..."
    mc "Sì, è molto duro{#male}..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:581
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_05a49b35:

    # mc "Both physically and mentally. He's out of my league."
    mc "Sia fisicamente che mentalmente. E' fuori dalla mia portata."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:584
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_03b00ac2:

    # bogdan "Yes... unless you say {i}the words{/i}."
    bogdan "Sì... a meno che tu non dica {i}le parole{/i}."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:587
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_96fb798a:

    # mc "What do you mean?" with dis_std
    mc "Cosa intendi?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:590
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_9a01af1d:

    # bogdan "I have magic phrase. Can conquer anyone!"
    bogdan "Ho una frase magica. Può conquistare chiunque!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:593
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_a31340dd:

    # mc "Really?"
    mc "Veramente?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:596
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_4521c5cc:

    # bogdan "Yes!"
    bogdan "SÌ!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:599
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_ed76e8b6:

    # bogdan "Just say: “You good pussy, me good pussy.”"
    bogdan "Dì solo: 'Tu buona figa, io buona figa'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:601
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_98815591:

    # bogdan "Just say: “You good cock, me good pussy.”"
    bogdan "Dì solo: 'Tu buon cazzo, io bella figa'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:603
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0823125a:

    # bogdan "Just say: “You good pussy, me good cock.”"
    bogdan "Dì solo: 'Tu buona figa, io buon cazzo'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:605
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3cb4ffdd:

    # bogdan "Just say: “You good cock, me good cock.”"
    bogdan "Dì solo: 'Tu buon cazzo, io buon cazzo'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:608
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0b2e05a9:

    # bogdan "Just say: “You good woman, me good woman.”"
    bogdan "Dì solo: 'Tu, brava donna, io, brava donna'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:610
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_c1d85485:

    # bogdan "Just say: “You good man, me good woman.”"
    bogdan "Dì solo: 'Tu brav'uomo, io brava donna'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:612
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f1f6a6b4:

    # bogdan "Just say: “You good woman, me good man.”"
    bogdan "Dì solo: 'Tu brava donna, io buon uomo'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:614
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_d8a79832:

    # bogdan "Just say: “You good man, me good man.”"
    bogdan "Dì solo: 'Tu buon uomo, io buon uomo'."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:617
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_0fcd590f:

    # bogdan "Easy peasy!" with dis_std_med
    bogdan "Facile facile!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:620
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_d84b3d0c:

    # mc "Relationships don't work like that, Bogdan..."
    mc "Relationships don't work like that, Bogdan..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:621
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_be619cfa:

    # mc "You've only tried your “magic phrase” with virtual characters, right?"
    mc "Hai provato la tua 'frase magica' solo con personaggi virtuali, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:624
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_5d8b4155:

    # bogdan "Of course!"
    bogdan "Ovviamente!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:627
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_82f7ce5e:

    # mc "I figured that out..."
    mc "l'avevo capito..."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:630
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_439f868c:

    # bogdan "Hottest men and women, always virtual!"
    bogdan "Uomini e donne più sexy, sempre virtuali!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:631
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_6ba9f222:

    # bogdan "Best of the best!"
    bogdan "Il meglio del meglio!"

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:634
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_3779aa9e:

    # mc "Anyways..." with dis_std_med
    mc "Comunque..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:635
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_8f919c82:

    # mc "Got to go home now! I'm working tonight."
    mc "Devo andare a casa adesso! Lavoro stasera."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:636
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_f2cddedc:

    # bogdan "Good luck, [mc.name!t]!"
    bogdan "Buona fortuna, [mc.name!t]!"

translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:126
    old "CHASE{#telegrim}"
    new "INSEGUI{#telegrim}"

    # game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:216
    old "DODGE{#telegrim}"
    new "SCHIVARE{#telegrim}"

    # game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:488
    old "{#BOND-CORRECT}Ask to hang out{#chapter1x1-choice06}"
    new "{#BOND-CORRECT}Chiedi di uscire{#chapter1x1-choice06}"

    # game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:490
    old "Nothing{#chapter1x1-choice06}"
    new "Niente{#chapter1x1-choice06}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:495
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_7aa7750b:

    # mc "Nah, it was nothing."
    mc "No, non era niente."

# game/story/book1/c1_awakening/e02_coming_home/s04_rogue_telegrim/script.rpy:506
translate italian scene__book1__c1_awakening__e02_coming_home__s04_rogue_telegrim_eb830a6e:

    # mc "Would you like to hang out some day?"
    mc "Ti piacerebbe uscire un giorno?"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
