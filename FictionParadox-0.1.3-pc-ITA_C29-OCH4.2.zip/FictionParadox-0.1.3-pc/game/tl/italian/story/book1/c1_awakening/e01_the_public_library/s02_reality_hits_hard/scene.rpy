﻿
translate italian strings:

    # game/story/book1/c1_awakening/e01_the_public_library/s02_reality_hits_hard/scene.rpy:6
    old "Reality Hits Hard{#story-scene}"
    new "La realtà colpisce duro{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
