﻿
# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:29
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_f058c0b3:

    # mc_t "My name is [mc.name!t] [mc.surname!t]." with dis_std_med
    mc_t "Il mio nome è [mc.name!t] [mc.surname!t]." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:30
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_67dbab0e:

    # mc_t "I'm 23, born in Canada. But if you ask me... I was raised on the Internet."
    mc_t "Ho 23 anni, sono nato in Canada. Ma secondo me... sono cresciuto su Internet."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:31
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_6fe0bd38:

    # mc_t "You know, scrolling through lives I'll never live... watching shows and movies... playing games... that stuff."
    mc_t "Sai, scorrendo vite che non vivrò mai... guardando programmi e film... giocando... quella roba."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:33
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_3780c611:

    # mc_t "I have no special talents, and almost no money. Just an ordinary girl with a shitty life."
    mc_t "Non ho talenti speciali e quasi non ho soldi. Solo una ragazza normale con una vita di merda."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:35
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_4aaad8aa:

    # mc_t "I have no special talents, and almost no money. Just an ordinary guy with a shitty life."
    mc_t "Non ho talenti speciali e quasi non ho soldi. Solo un ragazzo normale con una vita di merda."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:36
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_12544d8b:

    # mc_t "But my problems are nothing..."
    mc_t "Ma i miei problemi non sono niente..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:37
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_ac8f1f6e:

    # mc_t "...compared to what's happening out there."
    mc_t "...rispetto a ciò che sta accadendo là fuori."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:44
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_ea4d9d25:

    # mc_t "For as long as I can remember, the world has been falling apart." with dis_std_long
    mc_t "Per quanto posso ricordare, il mondo è andato in pezzi." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:46
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_269de7a6:

    # mc_t "Wars. Financial crashes. Environmental disasters. Identity crisis. Division. Poverty. Hate. Nearly every problem we face is self-inflicted."
    mc_t "Guerre. Crolli finanziari. Disastri ambientali. Crisi d'identità. Divisione. Povertà. Odio. Quasi tutti i problemi che affrontiamo sono autoinflitti."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:47
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_83df53cd:

    # mc_t "You know that feeling, right? It's easier to imagine our extinction than a better future..."
    mc_t "Conosci quella sensazione, vero? È più facile immaginare la nostra estinzione che un futuro migliore..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:48
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_ba338861:

    # mc_t "However, back in 2029, everything changed."
    mc_t "Tuttavia, nel 2029, tutto è cambiato."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:49
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_209f7f99:

    # mc_t "A group of renowned scientists and engineers announced an unprecedented project."
    mc_t "Un gruppo di rinomati scienziati e ingegneri ha annunciato un progetto senza precedenti."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:50
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_b9d05ea8:

    # mc_t "They wanted to build an experimental city, far from all the chaos."
    mc_t "They wanted to build an experimental city, far from all the chaos."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:51
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_2a72edec:

    # mc_t "A place to test new social models, to see if we could finally live without destroying ourselves..."
    mc_t "Un luogo dove sperimentare nuovi modelli sociali, per vedere se finalmente potremmo vivere senza distruggerci..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:54
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_16c16708:

    # mc_t "The land they chose was in the south of Tasmania." with dis_std_med
    mc_t "La terra che scelsero era nel sud della Tasmania." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:56
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_acb48816:

    # mc_t "Yes, Australia gave away the territory. It was insane! The entire world was shocked..."
    mc_t "Sì, l'Australia ha ceduto il territorio. Era pazzesco! Il mondo intero è rimasto scioccato..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:57
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_0a777655:

    # mc_t "But it was perfect. Do you know why?"
    mc_t "Ma è stato perfetto. Sai perché?"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:58
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_dd53c303:

    # mc_t "Tasmania is one of the most resilient places on Earth: remote, self-sufficient, rich in resources."
    mc_t "La Tasmania è uno dei luoghi più resilienti della Terra: remoto, autosufficiente, ricco di risorse."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:59
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_bcd838d4:

    # mc_t "These motherfuckers knew what they were doing..."
    mc_t "Questi figli di puttana sapevano cosa stavano facendo..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:60
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_827af57a:

    # mc_t "And somehow, they got funds from many governments and corporations. Treaties were signed to keep the city out of any conflict."
    mc_t "E in qualche modo hanno ottenuto fondi da molti governi e aziende. Furono firmati trattati per mantenere la città fuori da qualsiasi conflitto."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:61
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_767933b3:

    # mc_t "The biggest social experiment in human history was about to begin! And they called it..."
    mc_t "Il più grande esperimento sociale della storia umana stava per iniziare! E lo chiamavano..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:64
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_af51697c:

    # mc_t "The Verona Project." with dis_std_long
    mc_t "Il Progetto Verona." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:66
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_48c721df:

    # mc_t "Thanks to AI and automation, the first part of the city rose in just a few years."
    mc_t "Grazie all’intelligenza artificiale e all’automazione, la prima parte della città è cresciuta in pochi anni."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:67
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_67a72a79:

    # mc_t "It was... incredible. The kind of life I always dreamed of."
    mc_t "È stato... incredibile. Il tipo di vita che ho sempre sognato."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:68
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_0f4faabc:

    # mc_t "Machines were doing all the work. No need for money, barely any laws, stunning places, lots of free time..."
    mc_t "Le macchine facevano tutto il lavoro. Non c'è bisogno di soldi, quasi nessuna legge, posti meravigliosi, tanto tempo libero..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:69
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_2e44f49e:

    # mc_t "It looked like a utopia! Everyone wanted to live there!"
    mc_t "Sembrava un'utopia! Tutti volevano vivere lì!"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:70
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_0e29deca:

    # mc_t "And the best part?"
    mc_t "E la parte migliore?"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:71
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_3fa6d2c3:

    # mc_t "Anyone could apply for citizenship, regardless of their origin, culture or economic status."
    mc_t "Chiunque poteva richiedere la cittadinanza, indipendentemente dalla propria origine, cultura o condizione economica."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:72
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_dd889f2b:

    # mc_t "But the more people arrived, the harder it became to manage the city."
    mc_t "Ma più persone arrivavano, più diventava difficile gestire la città."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:73
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_7cd9b27b:

    # mc_t "Costs exploded, investors started pulling out... The project's survival was at risk."
    mc_t "I costi esplosero, gli investitori cominciarono a ritirarsi... La sopravvivenza del progetto era a rischio."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:76
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_263f1649:

    # mc_t "Then, the countries involved claimed the experiment was over." with dis_std_long
    mc_t "Quindi, i paesi coinvolti hanno affermato che l’esperimento era finito." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:78
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_5c25ebfe:

    # mc_t "They said Verona should only exist as a neutral fortress, guarding humanity's most valuable assets."
    mc_t "Dicevano che Verona dovrebbe esistere solo come fortezza neutrale, a guardia dei beni più preziosi dell'umanità."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:79
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_2db0be3e:

    # mc_t "Like a “bank” of resources, knowledge... and people."
    mc_t "Come una “banca” di risorse, conoscenze... e persone."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:80
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_c3487686:

    # mc "{act}sighs{/act} {think}I guess that was their real plan all along...{/think}"
    mc "{act}sospira{/act} {think}Immagino che quello fosse il loro vero piano fin dall'inizio...{/think}"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:81
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_da13e56d:

    # mc_t "In 2035, they stopped the expansion of the original city, now known as Verona's Center."
    mc_t "Nel 2035 si fermò l'espansione della città originaria, oggi conosciuta come Centro di Verona."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:82
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_48234648:

    # mc_t "The first thing they did was to bring back money. And from that moment on, ordinary people could no longer afford to live in Verona."
    mc_t "La prima cosa che fecero fu riportare indietro i soldi. E da quel momento in poi la gente comune non poté più permettersi di vivere a Verona."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:83
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_69cee8ad:

    # mc_t "There were many protests... The city was becoming nothing more than a refuge for billionaires."
    mc_t "Ci furono molte proteste... La città stava diventando niente più che un rifugio per miliardari."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:84
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_1b6fd6f0:

    # mc_t "And how did they respond?"
    mc_t "E come hanno risposto?"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:87
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_119e2ad0:

    # mc_t "They built cheap neighborhoods for the masses." with dis_std_long
    mc_t "Costruirono quartieri economici per le masse." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:89
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_d47c47d2:

    # mc_t "Pretty shabby, yeah..."
    mc_t "Abbastanza squallido, sì..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:90
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_b4a6a557:

    # mc_t "Though some streets had a certain charm. They even copied styles from different cities around the world."
    mc_t "Anche se alcune strade avevano un certo fascino. Hanno persino copiato stili da diverse città del mondo."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:91
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_f6a0db58:

    # mc_t "In this new area, the Traditional Districts, every citizen got a Universal Basic Income. Robots took care of basic services."
    mc_t "In questa nuova area, i Quartieri Tradizionali, ogni cittadino riceveva un Reddito di Base Universale. I robot si occupavano dei servizi di base."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:92
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_c7d27cc9:

    # mc_t "It worked surprisingly well. In fact, other countries started implementing similar policies."
    mc_t "Ha funzionato sorprendentemente bene. In effetti, altri paesi hanno iniziato ad attuare politiche simili."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:93
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_12890a8a:

    # mc_t "Because with the arrival of AI, humanity was facing an existential crisis..."
    mc_t "Perché con l’arrivo dell’intelligenza artificiale, l’umanità si trovava ad affrontare una crisi esistenziale…"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:96
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_a3abbd9a:

    # mc_t "Most people weren't necessary anymore. They felt lost, with too much time and no purpose." with dis_std_long
    mc_t "La maggior parte delle persone non era più necessaria. Si sentivano persi, con troppo tempo e senza scopo." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:98
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_00b113fd:

    # mc_t "Even the rich in the Center weren't satisfied. They always wanted more, and more..."
    mc_t "Anche i ricchi del Centro non erano soddisfatti. Volevano sempre di più, e di più..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:99
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_71cb33a6:

    # mc_t "Oh, and Verona itself was bleeding money. As you can imagine, the Center was too expensive to sustain."
    mc_t "Oh, e la stessa Verona perdeva soldi. Come puoi immaginare, il Centro era troppo costoso da sostenere."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:100
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_83a55b8a:

    # mc_t "So in 2038, they announced a third and final expansion of the city."
    mc_t "Così nel 2038 annunciarono una terza e ultima espansione della città."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:101
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_0df0851b:

    # mc_t "There, in the Periphery, almost anything could be bought or sold: prostitution, drugs, you name it."
    mc_t "Lì, in periferia, si poteva comprare o vendere quasi tutto: prostituzione, droga, tutto quello che vuoi."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:102
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_1038bd01:

    # mc_t "Unimaginable amounts of money poured in..."
    mc_t "Sono state versate somme di denaro inimmaginabili..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:105
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_90a64469:

    # mc_t "...and Verona grew very quickly." with dis_std_long
    mc_t "...e Verona è cresciuta molto velocemente." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:107
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_dd77b25e:

    # mc_t "The Periphery is like a modern jungle, but silently supervised by the Center."
    mc_t "The Periphery is like a modern jungle, but silently supervised by the Center."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:108
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_d02c87a2:

    # mc_t "For many people, this was a paradise of “freedom”."
    mc_t "Per molti questo era il paradiso della “libertà”."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:109
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_80cc3349:

    # mc_t "But to me... it's a prison. A giant prison that crushes your spirit. Like other cities do."
    mc_t "Ma per me... è una prigione. Una prigione gigantesca che schiaccia il tuo spirito. Come fanno le altre città."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:112
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_3c995f41:

    # mc_t "In 2040, Verona declared its independence." with dis_std_long
    mc_t "Nel 2040 Verona dichiarò la propria indipendenza." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:114
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_f610252e:

    # mc_t "The original project was over, and a new city-state was born: the Republic of Verona."
    mc_t "Il progetto originario terminò e nacque una nuova città-stato: la Repubblica di Verona."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:115
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_868b423f:

    # mc_t "“One country. Three systems. All cultures at once.”"
    mc_t "'Un paese. Tre sistemi. Tutte le culture contemporaneamente.'"

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:116
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_78bd3ec2:

    # mc_t "It is said that here you can find the best and the worst of humanity. And it's probably right..."
    mc_t "Si dice che qui si possa trovare il meglio e il peggio dell'umanità. E probabilmente è giusto..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:117
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_c620b936:

    # mc_t "But this is no longer an experiment to give hope. It's just... a tiny replica of the world. A shelter for a few lucky ones."
    mc_t "Ma questo non è più un esperimento per dare speranza. È solo... una piccola replica del mondo. Un rifugio per pochi fortunati."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:120
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_239d1d99:

    # mc_t "As for me? I live in the Traditional Districts." with dis_std_long
    mc_t "Quanto a me? Vivo nei quartieri tradizionali." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:122
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_14c71684:

    # mc_t "I came with my family, looking for a better future. And now, here I am..."
    mc_t "Sono venuto con la mia famiglia, in cerca di un futuro migliore. E ora eccomi qui..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:124
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_b7ea2232:

    # mc_t "Surrounded{#female} by humans and robots."
    mc_t "Circondato{#female} da umani e robot."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:126
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_43bd29a3:

    # mc_t "Surrounded{#male} by humans and robots."
    mc_t "Circondato{#male} da umani e robot."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:127
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_da7760dd:

    # mc_t "For a while, entertainment was enough for me. But I hardly enjoy anything anymore..."
    mc_t "Per un po’ mi bastò il divertimento. Ma non mi godo quasi più niente..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:128
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_f5a66519:

    # mc_t "My life is boring and purposeless."
    mc_t "La mia vita è noiosa e senza scopo."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:129
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_5dbd51c8:

    # mc_t "Generally, I just watch. No initiative. Because deep down, I feel a profound contempt for society."
    mc_t "In genere mi limito a guardare. Nessuna iniziativa. Perché nel profondo provo un profondo disprezzo per la società."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:132
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_e3aa7a23:

    # mc_t "Our civilization feels like a poorly built stage." with dis_std_long
    mc_t "La nostra civiltà sembra un palcoscenico mal costruito." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:134
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_85406c61:

    # mc_t "People act to hide who they are, and pretend to be happy. Surrendering to immediate fake pleasures is the norm."
    mc_t "Le persone agiscono per nascondere chi sono e fingono di essere felici. Arrendersi a piaceri finti immediati è la norma."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:135
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_fe5bbe48:

    # mc_t "I guess it's always been that way..."
    mc_t "Immagino che sia sempre stato così..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:136
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_7e17d85d:

    # mc_t "But it's sad. Very sad."
    mc_t "Ma è triste. Molto triste."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:137
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_4186cd72:

    # mc_t "No one gives a shit about the future anymore. It's all about consuming products, trends, even people."
    mc_t "A nessuno frega più niente del futuro. Si tratta di consumare prodotti, tendenze e persino persone."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:138
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_f612cdab:

    # mc_t "I live in a world with more than 9 billion inhabitants, and yet..."
    mc_t "Vivo in un mondo con più di 9 miliardi di abitanti, eppure..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:142
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_8cd8ae01:

    # mc_t "I feel completely alone{#female}." with dis_std_long
    mc_t "Mi sento completamente solo{#female}." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:144
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_947e0cd2:

    # mc_t "I feel completely alone{#male}." with dis_std_long
    mc_t "Mi sento completamente solo{#male}." with dis_std_long

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:146
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_c5f64930:

    # mc_t "It's like there's no one around me. Like the world is... empty."
    mc_t "È come se non ci fosse nessuno intorno a me. Come se il mondo fosse... vuoto."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:147
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_3caa81e5:

    # mc_t "I can't find any meaning in life."
    mc_t "Non riesco a trovare alcun significato nella vita."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:148
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_3f9b94ef:

    # mc_t "I have no real friends. My family's back in Canada. And I've stayed here, waiting..."
    mc_t "Non ho veri amici. La mia famiglia è tornata in Canada. E sono rimasto qui, ad aspettare..."

# game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/script.rpy:149
translate italian scene__book1__c1_awakening__e02_coming_home__s01_gloomy_world_da18e339:

    # mc_t "Waiting for something to change."
    mc_t "In attesa che qualcosa cambi."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
