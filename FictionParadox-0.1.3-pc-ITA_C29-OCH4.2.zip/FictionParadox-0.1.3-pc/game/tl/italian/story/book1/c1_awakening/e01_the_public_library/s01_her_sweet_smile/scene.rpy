﻿
translate italian strings:

    # game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/scene.rpy:6
    old "Her Sweet Smile{#story-scene}"
    new "Il suo dolce sorriso{#story-scene}"

    # game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/scene.rpy:9
    old "His Sweet Smile{#story-scene}"
    new "Il suo dolce sorriso{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
