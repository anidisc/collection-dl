﻿
# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:13
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:15
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_088154be:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:18
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_cc463226:

    # mc "{act}mumbling{/act} No..." with dis_std_med
    mc "{act}mormorio{/act} No..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:19
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_05798bfe:

    # mc "{act}mumbling{/act} I can't... accept it..."
    mc "{act}mormora{/act} Non posso... accettarlo..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:20
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_680c1b60:

    # mc "{act}mumbling{/act} There... must be... a way..."
    mc "{act}mormorio{/act} Ci... deve esserci... un modo..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:21
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_6a7a5bf5:

    # unknown "[mc.name!t]?"
    unknown "[mc.name!t]?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:22
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:25
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_bb782475:

    # mc "{act}slowly straightening up{/act}"
    mc "{act}raddrizzandosi lentamente{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:37
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_088154be_1:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:38
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_81fc2a9d:

    # mc "W-Who said my name...?"
    mc "C-Chi ha detto il mio nome...?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:41
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ea9a1376:

    # unknown "{act}looking at you{/act}" with dis_open_eyes_slow
    unknown "{act}ti guarda{/act}" with dis_open_eyes_slow

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:44
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_24a550b8:

    # unknown "Are you [mc.name!t] [mc.surname!t], from high school?"
    unknown "Sei [mc.name!t] [mc.surname!t], del liceo?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:54
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b3008901:

    # mc "Oh..." with dis_std
    mc "Oh..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:55
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ebc92ccb:

    # mc "It's you, [dd.name!t]..."
    mc "Sei tu, [dd.name!t]..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:61
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_6b167fe5:

    # mc "Long time no see..." with dis_std
    mc "È da tanto che non ci vediamo..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:62
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f99dca8c:

    # dd ". . ."
    dd ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:65
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f99cc11b:

    # dd "Are you okay?"
    dd "Stai bene?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:68
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d3fdf7c0:

    # mc "Huh? What do you mean?"
    mc "Eh? Cosa intendi?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:71
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_fb039160:

    # dd "Well..."
    dd "BENE..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:76
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_596669ae:

    # dd "You were sleeping!{w} In the public library!{w} On a Saturday evening!"
    dd "Stavi dormendo!{w} Nella biblioteca pubblica!{w} Un sabato sera!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:78
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_850f3c85:

    # dd "And you look a bit... worn out{#female}."
    dd "E sembri un po'... stanco{#female}."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:80
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5b5a9abe:

    # dd "And you look a bit... worn out{#male}."
    dd "E sembri un po'... stanco{#male}."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:83
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_7b133a1c:

    # mc "{act}looking away{/act} {think}Damn it...{/think}" with dis_std_med
    mc "{act}guardare altrove{/act} {think}Dannazione...{/think}" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:84
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_cf73b2df:

    # mc "{act}looking away{/act} {think}I didn't expect to meet [dd.name!t] again...{/think}"
    mc "{act}guardando lontano{/act} {think}Non mi aspettavo di incontrare di nuovo [dd.name!t]...{/think}"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:85
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_061292b8:

    # dd "[mc.name!t]?"
    dd "[mc.name!t]?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:88
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_e79df68d:

    # mc "I'm fine."
    mc "Sto bene."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:91
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ff8bb2fc:

    # dd "No, you don't look fine..."
    dd "No, non hai un bell'aspetto..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:92
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4bc9012f:

    # dd "Did something happen? You can tell me if you want to!"
    dd "È successo qualcosa? Puoi dirmelo se vuoi!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:95
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d39246a6:

    # mc "{act}sighs{/act} Please..."
    mc "{act}sospira{/act} Per favore..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:96
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f9656652:

    # mc "Don't waste your time with me."
    mc "Non perdere tempo con me."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:97
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9e50859e:

    # mc "I'm just an empty person... I have nothing to say."
    mc "Sono solo una persona vuota... non ho niente da dire."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:100
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_12eca6d1:

    # dd "{act}chuckles softly{/act}"
    dd "{act}ridacchia piano{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:103
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5444be0e:

    # mc "Huh...?" with dis_std
    mc "Eh...?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:108
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_a4f2c7ae:

    # dd "{act}smiles{/act}" with dis_std_biglong
    dd "{act}sorride{/act}" with dis_std_biglong

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:109
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_130deb4b:

    # mc "W-Why are you smiling?"
    mc "W-perché sorridi?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:112
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9c47e465:

    # dd "That's not true."
    dd "Non è vero."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:115
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ecbb05fc:

    # mc "Yeah, whatever you say..."
    mc "Sì, qualunque cosa tu dica..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:118
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_44b2b9ec:

    # dd "I'm serious! To me, you're like the opposite of an empty person!"
    dd "Sono serio! Per me sei l'opposto di una persona vuota!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:121
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_c31e9950:

    # mc "But you don't know me..."
    mc "Ma tu non mi conosci..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:125
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_28715496:

    # dd "From what I remember, you are smart{#female}, creative{#female}, funny{#female}..."
    dd "Da quello che ricordo, sei intelligente{#female}, creativo{#female}, divertente{#female}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:127
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0a5223b4:

    # dd "From what I remember, you are smart{#male}, creative{#male}, funny{#male}..."
    dd "Da quello che ricordo, sei intelligente{#male}, creativo{#male}, divertente{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:128
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9f34384c:

    # dd "That doesn't sound empty to me!"
    dd "Non mi sembra vuoto!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:131
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0f240219:

    # mc "If you say so..."
    mc "Se lo dici tu..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:133
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f94b4d70:

    # mc_t "She hasn't changed at all."
    mc_t "Non è cambiata affatto."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:135
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_dccf1ca9:

    # mc_t "He hasn't changed at all."
    mc_t "Non è cambiato affatto."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:140
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d0b80fb3:

    # mc_t "[dd.name!t] Fernandez..." with dis_std_med
    mc_t "[dd.name!t] Fernandez..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:143
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_8eb5e9fc:

    # mc_t "She was a classmate{#female} from Argentina."
    mc_t "Era una compagna di classe{#female} dell'Argentina."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:144
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_bd1794ea:

    # mc_t "At that time, all of us were 18, since high school lingers an extra year in our city, and I met her then."
    mc_t "A quel tempo avevamo tutti 18 anni, dato che nella nostra città il liceo dura un anno in più, e allora l'ho incontrata."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:145
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_93706455:

    # mc_t "She was beautiful{#female}, intelligent{#female}, responsible{#female}, kind{#female}..."
    mc_t "Era bella{#female}, intelligente{#female}, responsabile{#female}, gentile{#female}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:146
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_42a251c0:

    # mc_t "Authentic{#female} and original{#female}. Always ready{#female} to instill motivation and hope in any person, no matter the situation."
    mc_t "Autentico{#female} e originale{#female}. Sempre pronto{#female} a infondere motivazione e speranza in chiunque, indipendentemente dalla situazione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:147
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_52133a75:

    # mc_t "With that personality and that body, she could have an easy life..."
    mc_t "Con quella personalità e quel corpo, potrebbe avere una vita facile..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:149
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9d305639:

    # mc_t "He was a classmate{#male} from Argentina."
    mc_t "Era un compagno di classe{#male} dell'Argentina."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:150
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_95cf6ef2:

    # mc_t "At that time, all of us were 18, since high school lingers an extra year in our city, and I met him then."
    mc_t "A quel tempo avevamo tutti 18 anni, dato che nella nostra città il liceo dura un anno in più, e allora l'ho incontrato."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:151
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_3aa3d751:

    # mc_t "He was handsome{#male}, intelligent{#male}, responsible{#male}, kind{#male}..."
    mc_t "Era bello{#male}, intelligente{#male}, responsabile{#male}, gentile{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:152
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4655f686:

    # mc_t "Authentic{#male} and original{#male}. Always ready{#male} to instill motivation and hope in any person, no matter the situation."
    mc_t "Autentico{#male} e originale{#male}. Sempre pronto{#male} a infondere motivazione e speranza in chiunque, qualunque sia la situazione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:153
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0b541750:

    # mc_t "With that personality and that body, he could have an easy life..."
    mc_t "Con quella personalità e quel corpo, avrebbe potuto avere una vita facile..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:157
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_1bc69400:

    # mc_t "But she studied hard." with dis_std_med
    mc_t "Ma ha studiato molto." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:158
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_998be018:

    # mc_t "Always attentive, doing things with care and dedication."
    mc_t "Sempre attento, facendo le cose con cura e dedizione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:159
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9def629c:

    # mc_t "Her dream was to become an architect{#female}, a real one! Which is difficult nowadays..."
    mc_t "Il suo sogno era diventare architetto{#female}, un sogno vero! Cosa difficile al giorno d'oggi..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:160
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_2a7066de:

    # mc_t "But as she always said: “You only live once!”"
    mc_t "Ma come diceva sempre: “Si vive una volta sola!”"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:161
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_7d5f3002:

    # mc_t "So in the end, she managed to get into the best university. I was really happy for her!"
    mc_t "Quindi alla fine è riuscita a entrare nella migliore università. Ero davvero felice per lei!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:162
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9c4c466b:

    # mc_t "In fact... I admired her."
    mc_t "In effetti... la ammiravo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:164
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_1be19646:

    # mc_t "But he studied hard." with dis_std_med
    mc_t "Ma ha studiato molto." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:165
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_998be018_1:

    # mc_t "Always attentive, doing things with care and dedication."
    mc_t "Sempre attento, facendo le cose con cura e dedizione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:166
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_758ae020:

    # mc_t "His dream was to become an architect{#male}, a real one! Which is difficult nowadays..."
    mc_t "Il suo sogno era diventare architetto{#male}, davvero! Cosa difficile al giorno d'oggi..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:167
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f6adbf45:

    # mc_t "But as he always said: “You only live once!”"
    mc_t "Ma come diceva sempre: “Si vive una volta sola!”"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:168
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_76d2bf6d:

    # mc_t "So in the end, he managed to get into the best university. I was really happy for him!"
    mc_t "Quindi alla fine è riuscito a entrare nella migliore università. Ero davvero felice per lui!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:169
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_dc38aea5:

    # mc_t "In fact... I admired him."
    mc_t "In effetti... lo ammiravo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:170
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ca6fd479:

    # mc "{act}sighs{/act} {think}I wish I had that determination.{/think}"
    mc "{act}sospira{/act} {think}Vorrei avere questa determinazione.{/think}"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:175
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_54588216:

    # mc_t "Time flies..." with dis_std_med
    mc_t "Il tempo vola..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:177
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b92222c7:

    # mc_t "And she looks as beautiful as ever."
    mc_t "E sembra più bella che mai."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:178
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_440ef761:

    # mc_t "Although if she keeps smiling like that, I'll die of love."
    mc_t "Anche se continua a sorridere così, morirò d'amore."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:180
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d1dc8573:

    # mc_t "And he looks as beautiful as ever."
    mc_t "E sembra più bello che mai."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:181
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b6ded26d:

    # mc_t "Although if he keeps smiling like that, I'll die of love."
    mc_t "Anche se continua a sorridere così, morirò d'amore."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:182
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_3908daec:

    # mc "Weeeeell..."
    mc "Weeeee..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:183
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0720616e:

    # mc "And what are {i}you{/i} doing here on a Saturday evening? [ll.name!t] told me you were studying abroad."
    mc "E tu, {i}tu{/i} cosa ci fai qui sabato sera? [ll.name!t] mi ha detto che stavi studiando all'estero."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:186
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_2e8417bf:

    # dd "Yes, I went to do a master's degree in Spain!"
    dd "Sì, sono andata a fare un master in Spagna!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:187
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4da94418:

    # dd "I already finished it, so I returned to Verona a few days ago."
    dd "L'ho già finito, quindi sono tornato a Verona qualche giorno fa."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:190
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_afb45c96:

    # mc "I didn't know."
    mc "Non lo sapevo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:193
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_a90e0de7:

    # dd "Today I had a bit of free time, so I decided to take a walk here."
    dd "Oggi ho avuto un po' di tempo libero, quindi ho deciso di fare una passeggiata qui."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:194
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d7b0b8e2:

    # dd "I love Verona's Library!"
    dd "Adoro la Biblioteca di Verona!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:197
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_9b21c085:

    # mc "{act}smiles{/act} I see."
    mc "{act}sorride{/act} Capisco."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:200
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_3a0e0e22:

    # dd "{act}looking at desk{/act} Hmm..." with dis_std_med
    dd "{act}guardando la scrivania{/act} Hmm..." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:203
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_c5509f82:

    # dd "{act}looking at desk{/act} What were you doing?"
    dd "{act}guardando la scrivania{/act} Cosa stavi facendo?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:206
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_c1dff962:

    # mc "Oh..."
    mc "Oh..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:209
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4ee3ee37:

    # mc "Just reading a book." with dis_std_med
    mc "Basta leggere un libro." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:210
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_261961fc:

    # dd "You like to read physical books? Me too!"
    dd "Ti piace leggere libri fisici? Anche io!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:211
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_8082ba42:

    # mc "Y-Yeah, haha."
    mc "S-Sì, ahah."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:212
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_27f157fc:

    # mc "It's a new hobby I started a few months ago."
    mc "È un nuovo hobby che ho iniziato qualche mese fa."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:216
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b6522aab:

    # mc "{act}grabbing the book{/act} Lately I'm reading essays, like this one." with dis_std_med
    mc "{act}prendendo il libro{/act} Ultimamente sto leggendo dei saggi, come questo." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:218
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5bcf392b:

    # mc "I already read half of it, but... to be honest{#female} with you..."
    mc "Ne ho già letto la metà, ma... a essere sincero{#female} con te..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:220
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_3e8cc7f4:

    # mc "I already read half of it, but... to be honest{#male} with you..."
    mc "Ne ho già letto la metà, ma... a essere sincero{#male} con te..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:221
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_24ac32ca:

    # mc "I don't understand shit."
    mc "Non capisco un cazzo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:223
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_c03570ab:

    # dd "{act}laughs{/act} Don't worry!"
    dd "{act}ride{/act} Non preoccuparti!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:227
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f44fa46f:

    # mc "{act}closes the book{/act}" with dis_std_med
    mc "{act}chiude il libro{/act}" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:228
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d2f4b749:

    # mc "I guess I'll try to read it again, someday."
    mc "Immagino che proverò a leggerlo di nuovo, un giorno."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:229
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_493c9a55:

    # dd "I like the cover! Looks interesting."
    dd "Mi piace la copertina! Sembra interessante."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:231
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_67179e66:

    # mc "Yeah, it reels you in, makes you think you're smart{#female}..."
    mc "Sì, ti coinvolge, ti fa credere di essere intelligente{#female}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:233
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_58166b6c:

    # mc "Yeah, it reels you in, makes you think you're smart{#male}..."
    mc "Sì, ti coinvolge, ti fa credere di essere intelligente{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:234
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_bd2afa69:

    # mc "And then, BANG!"
    mc "E poi, BANG!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:235
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5070d68b:

    # mc "It hits you with differential equations in the first chapter."
    mc "Ti colpisce con le equazioni differenziali nel primo capitolo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:236
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_811793b9:

    # dd "{act}laughs{/act} Oops! Those are difficult!"
    dd "{act}ride{/act} Ops! Quelli sono difficili!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:237
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_f8b1f354:

    # mc "I don't even know why I kept reading..."
    mc "Non so nemmeno perché ho continuato a leggere..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:240
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_00daf18a:

    # mc "{act}standing up{/act} Okay, enough of my nonsense for today." with dis_std_med
    mc "{act}alzarsi{/act} Ok, per oggi basta con le mie sciocchezze." with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:244
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d8d40682:

    # dd "You are more capable{#female} than you think, [mc.name!t]. All you need is a spark to ignite your inner flame!"
    dd "Sei più capace{#female} di quanto pensi, [mc.name!t]. Tutto ciò di cui hai bisogno è una scintilla per accendere la tua fiamma interiore!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:246
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d4299e21:

    # dd "You are more capable{#male} than you think, [mc.name!t]. All you need is a spark to ignite your inner flame!"
    dd "Sei più capace{#male} di quanto pensi, [mc.name!t]. Tutto ciò di cui hai bisogno è una scintilla per accendere la tua fiamma interiore!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:249
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_571bf29f:

    # mc "A spark?"
    mc "Una scintilla?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:252
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_af363f34:

    # dd "Yes! Like a new experience, you know?"
    dd "SÌ! Come una nuova esperienza, sai?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:255
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0a382cb9:

    # dd "We all{#female} have special moments that changed our lives. And if you don't have any..."
    dd "Tutti noi{#female} abbiamo momenti speciali che ci hanno cambiato la vita. E se non ne hai..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:257
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b63b462a:

    # dd "We all{#male} have special moments that changed our lives. And if you don't have any..."
    dd "Tutti noi{#male} abbiamo momenti speciali che ci hanno cambiato la vita. E se non ne hai..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:259
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b0e5fdac:

    # dd "We all{#both-genders} have special moments that changed our lives. And if you don't have any..."
    dd "Tutti noi{#both-genders} abbiamo momenti speciali che ci hanno cambiato la vita. E se non ne hai..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:262
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_20ea00ab:

    # dd "You can always create them yourself{#female}!"
    dd "Puoi sempre crearli tu stesso{#female}!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:263
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_bc2a0593:

    # dd "Just be honest{#female} with what your heart truly wants, and start your own adventure!"
    dd "Sii onesto{#female} con ciò che il tuo cuore vuole veramente e inizia la tua avventura!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:265
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_fb37bca8:

    # dd "You can always create them yourself{#male}!"
    dd "Puoi sempre crearli tu stesso{#male}!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:266
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_0eab9408:

    # dd "Just be honest{#male} with what your heart truly wants, and start your own adventure!"
    dd "Sii onesto{#male} con ciò che il tuo cuore vuole veramente e inizia la tua avventura!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:269
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4a2ef417:

    # mc "I don't know..."
    mc "non lo so..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:270
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5e40ff38:

    # mc "I've never had that much initiative."
    mc "Non ho mai avuto così tanta iniziativa."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:273
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_bf67d348:

    # dd "You only live once, [mc.name!t]!"
    dd "Si vive una volta sola, [mc.name!t]!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:274
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_51e1b126:

    # dd "At least give it some thought, okay?"
    dd "Almeno pensaci un po', ok?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:277
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_84f16542:

    # mc "Okay..."
    mc "Ok..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:278
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_22ca1f19:

    # mc "Thanks for the encouragement, [dd.name!t]."
    mc "Grazie per l'incoraggiamento, [dd.name!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:281
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_214cded6:

    # dd "You're welcome!"
    dd "Prego!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:284
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_5e27a909:

    # mc "{act}slowly looking down{/act} {think}Damn...{/think}" with dis_std_long
    mc "{act}guardando lentamente in basso{/act} {think}Dannazione...{/think}" with dis_std_long

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:291
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_140f77d8:

    # mc_t "What a pair of melons!" with dis_std
    mc_t "Che coppia di meloni!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:292
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b16967d3:

    # mc_t "They look like they are going to explode at any mom—"
    mc_t "Sembra che stiano per esplodere contro qualsiasi mamma..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:294
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_314e7772:

    # mc_t "What a chest!" with dis_std
    mc_t "Che petto!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:295
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_6e2bacca:

    # mc_t "It looks like it's going to explode at any mom—"
    mc_t "Sembra che esploderà contro qualsiasi mamma..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:299
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_072c17a4:

    # dd "Shall we leave, then?"
    dd "Partiamo allora?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:303
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_7010251b:

    # mc "Y-Yeah! Let's go."
    mc "S-sì! Andiamo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:305
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_6fbc4865:

    # mc "Yeah, let's go."
    mc "Sì, andiamo."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:308
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_43b4b1d3:

    # dd "Have you thought about going to college?" with dis_std_long
    dd "Hai pensato di andare al college?" with dis_std_long

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:311
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_4c663d4e:

    # mc "Who, me? Nah, I'm not that smart{#female}..."
    mc "Chi, io? No, non sono così intelligente{#female}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:313
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_e53593b7:

    # mc "Who, me? Nah, I'm not that smart{#male}..."
    mc "Chi, io? No, non sono così intelligente{#male}..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:315
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_da0a80fd:

    # dd "I think you could get in! Nowadays creativity is valued more than knowledge."
    dd "Penso che potresti entrare! Al giorno d’oggi la creatività è valutata più della conoscenza."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:317
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ad909a8e:

    # mc "Hmmm..."
    mc "Hmm..."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:319
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_ecd00905:

    # mc "I'm great{#female} at creatively spiraling into despair."
    mc "Sono bravissimo{#female} a precipitare creativamente nella disperazione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:321
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_038cc2a2:

    # mc "I'm great{#male} at creatively spiraling into despair."
    mc "Sono bravissimo{#male} a precipitare creativamente nella disperazione."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:322
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_d1d568de:

    # mc "Does that count?"
    mc "Conta?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:324
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_a3b06d69:

    # dd "{act}laughs{/act} No, that doesn't count."
    dd "{act}ride{/act} No, questo non conta."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:329
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_3e05d547:

    # civic_assistant_white "Excuse me, lady."
    civic_assistant_white "Mi scusi, signora."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:331
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_c54c2f5c:

    # civic_assistant_white "Excuse me, gentleman."
    civic_assistant_white "Mi scusi, signore."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:334
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_6546369d:

    # mc "Huh?" with dis_std
    mc "Eh?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:337
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_01de9861:

    # civic_assistant_white "Before you leave, would you be so kind as to return the book?"
    civic_assistant_white "Prima di partire, saresti così gentile da restituire il libro?"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:338
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_616a3a09:

    # civic_assistant_white "In case you wish to borrow it, you must fill in the corresponding form."
    civic_assistant_white "Nel caso in cui desideri prenderlo in prestito, devi compilare il modulo corrispondente."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:339
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_fe02fc19:

    # mc_t "Oops, I forgot about the book."
    mc_t "Ops, mi ero dimenticato del libro."

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:342
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_cd77915c:

    # mc "Sorry! Here it is." with dis_std
    mc "Scusa! Ecco qui." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:343
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_49b47c9a:

    # civic_assistant_white "Thank you!"
    civic_assistant_white "Grazie!"

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:346
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_b8748bdf:

    # civic_assistant_white "{act}starts moving{/act}" with dis_std_med
    civic_assistant_white "{act}inizia a muoversi{/act}" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:349
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_2db98dcf:

    # dd "Verona's Civic Assistants are so cute! I missed them!" with dis_std_med
    dd "Che carini gli Assistenti Civici di Verona! Mi sono mancati!" with dis_std_med

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:350
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_aca3a0c8:

    # mc "Yes, they're quite nice."
    mc "Sì, sono piuttosto carini."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e01_the_public_library/s01_her_sweet_smile/script.rpy:310
translate italian scene__book1__c1_awakening__e01_the_public_library__s01_her_sweet_smile_8c7b98f8:

    # dd "Have you thought about going to college?" with dis_std_med
    dd "Hai pensato di andare al college?" with dis_std_med

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
