﻿
translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/scene.rpy:6
    old "The Best Friends{#both-genders}{#story-scene}"
    new "I migliori amici{#both-genders}{#story-scene}"

    # game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/scene.rpy:9
    old "The Best Friends{#female}{#story-scene}"
    new "I migliori amici{#female}{#story-scene}"

    # game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/scene.rpy:12
    old "The Best Friends{#male}{#story-scene}"
    new "I migliori amici{#male}{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
