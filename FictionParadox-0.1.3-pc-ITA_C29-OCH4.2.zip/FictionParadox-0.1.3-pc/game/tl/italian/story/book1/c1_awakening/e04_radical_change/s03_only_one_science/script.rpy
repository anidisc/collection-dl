﻿
# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:24
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_4ce1a28c:

    # mc_t "I've spent all my little savings on this." with dis_std
    mc_t "Ho speso tutti i miei piccoli risparmi per questo." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:25
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_68e7805b:

    # mc_t "Will it work? From what I've seen online, it's really complex to customize..."
    mc_t "Funzionerà? Da quello che ho visto online, è davvero complesso da personalizzare..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:26
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0bb50c99:

    # mc_t "I guess I can use an AI to automate the work."
    mc_t "Immagino di poter usare un'intelligenza artificiale per automatizzare il lavoro."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:28
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_6dfa20ed:

    # mc_t "The thing is... what if my idea isn't even feasible? Because in that case, I'm screwed{#female}."
    mc_t "Il fatto è... e se la mia idea non fosse nemmeno realizzabile? Perché in questo caso sono fregato{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:30
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3e970b62:

    # mc_t "The thing is... what if my idea isn't even feasible? Because in that case, I'm screwed{#male}."
    mc_t "Il fatto è... e se la mia idea non fosse nemmeno realizzabile? Perché in questo caso sono fregato{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:34
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_53dd843d:

    # mc_t "I mean, I'm not rich{#female}..." with dis_std_med
    mc_t "Voglio dire, non sono ricco{#female}..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:36
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3f4d41da:

    # mc_t "I mean, I'm not rich{#male}..." with dis_std_med
    mc_t "Voglio dire, non sono ricco{#male}..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:37
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_07f89ee1:

    # mc_t "All I can do is take a big gamble, and cross my fingers."
    mc_t "Tutto quello che posso fare è fare una grande scommessa e incrociare le dita."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:40
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2f4c6970:

    # mc "{act}entering your PIN{/act}"
    mc "{act}inserimento del PIN{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:44
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e3480117:

    # mc "{act}taking out the box{/act} {think}Here it is.{/think}" with dis_std_med
    mc "{act}tirare fuori la scatola{/act} {think}Eccola.{/think}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:55
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_69888f2b:

    # mc_t "Okay, everything's ready..." with dis_std
    mc_t "Ok, è tutto pronto..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:56
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_37b54630:

    # mc "Hey assistant!"
    mc "Ehi assistente!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:59
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_be42ffe2:

    # phone_ai "Hello, [mc.name!t]!"
    phone_ai "Ciao, [mc.name!t]!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:60
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c29c8915:

    # phone_ai "What can I help you with?"
    phone_ai "In cosa posso aiutarti?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:63
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_a6e40099:

    # mc "You see, last night I bought this... “neuroholographic stimulation kit”."
    mc "Vedi, ieri sera ho comprato questo... 'kit di stimolazione neuroolografica'."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:64
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0d9f9785:

    # mc_t "No clue what the fuck that means."
    mc_t "Non ho idea di cosa cazzo significhi."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:65
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_59c46639:

    # mc "I saw some people use it to boost their imagination, but customization is difficult."
    mc "Ho visto alcune persone usarlo per stimolare la propria immaginazione, ma la personalizzazione è difficile."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:66
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_14c1f278:

    # mc "Could you give me a hand?"
    mc "Potresti darmi una mano?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:69
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_22498c4e:

    # phone_ai "Of course!"
    phone_ai "Ovviamente!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:70
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d2b8ce43:

    # phone_ai "I see you already connected the holographic processor to your laptop."
    phone_ai "Vedo che hai già collegato il processore olografico al tuo portatile."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:73
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_1e1b5ad7:

    # mc "Yeap, that was easy."
    mc "Sì, è stato facile."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:75
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_fa6dc10a:

    # phone_ai "The other components of the kit are the transmission bracelet and the eidetic cards. Do you know how they work?"
    phone_ai "Gli altri componenti del kit sono il braccialetto di trasmissione e le carte eidetiche. Sai come funzionano?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:78
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_fe2c7cb8:

    # mc "Umm... no?"
    mc "Ehm... no?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:81
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_27314dd2:

    # phone_ai "Do you want me to give you a summary? It may be a bit technical, though."
    phone_ai "Vuoi che ti faccia un riassunto? Potrebbe essere un po' tecnico, però."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:87
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3f32f6c3:

    # mc "Yes, please." with dis_std
    mc "Sì, per favore." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:90
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c6957bc6:

    # phone_ai "This kit was designed by Pontecorvo Labs as an experimental toy for children."
    phone_ai "Questo kit è stato progettato da Pontecorvo Labs come giocattolo sperimentale per bambini."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:91
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_cfc994b0:

    # phone_ai "It was pretty popular in the 2030's, when—"
    phone_ai "Era piuttosto popolare negli anni '30 del 2000, quando..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:95
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8dec2fd7:

    # mc "Wait, WHAT?"
    mc "Aspetta, COSA?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:96
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0924de50:

    # mc "A toy for children!? You've got to be kidding me..."
    mc "Un giocattolo per bambini!? Mi stai prendendo in giro..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:99
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_85f5e071:

    # phone_ai "Yes, that's correct. It's a toy."
    phone_ai "Sì, è corretto. È un giocattolo."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:102
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d7a9f1e0:

    # mc_t "Fuck my life."
    mc_t "Fanculo la mia vita."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:105
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3226830b:

    # phone_ai "This technology only works on children, or adults with a highly developed imagination."
    phone_ai "Questa tecnologia funziona solo su bambini o adulti con un'immaginazione molto sviluppata."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:108
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9eacafc0:

    # mc "Oh, really? Thank god..."
    mc "Oh veramente? Grazie a Dio..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:111
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_814b9039:

    # phone_ai "The processor converts the eidetic card's data into neuroholographic patterns, and transmits them to the bracelet."
    phone_ai "Il processore converte i dati della carta eidetica in schemi neuroolografici e li trasmette al braccialetto."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:112
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_aedb9957:

    # phone_ai "Then, the bracelet emits electric signals through your skin, usually a finger."
    phone_ai "Quindi, il braccialetto emette segnali elettrici attraverso la pelle, solitamente un dito."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:115
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_423dcb97:

    # mc_t "I hope I don't end up like Bogdan."
    mc_t "Spero di non finire come Bogdan."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:118
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7d0c7ee9:

    # phone_ai "Those signals will reach the brain through your nervous system, and once that connection is formed..."
    phone_ai "Those signals will reach the brain through your nervous system, and once that connection is formed..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:119
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_cd7c15bb:

    # phone_ai "An abstract structure will emerge on your mind. Your imagination will do the rest!"
    phone_ai "Una struttura astratta emergerà nella tua mente. La tua immaginazione farà il resto!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:122
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ad909a8e:

    # mc "Hmmm..."
    mc "Hmm..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:123
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_235f5dbd:

    # mc_t "So that's why most adults can't use it..."
    mc_t "Ecco perché la maggior parte degli adulti non può usarlo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:126
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c86cd1e5:

    # phone_ai "By default, the eidetic cards are empty."
    phone_ai "Per impostazione predefinita, le carte eidetiche sono vuote."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:127
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9a29dd7f:

    # phone_ai "The usual practice was to store simple structures, so children could play with it freely."
    phone_ai "La pratica abituale era quella di riporre strutture semplici in modo che i bambini potessero giocarci liberamente."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:128
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_044987c8:

    # phone_ai "However, in the last years, there's been a growing community of people that create their own customized eidetic cards as a hobby."
    phone_ai "Tuttavia, negli ultimi anni, c'è stata una crescente comunità di persone che creano le proprie carte eidetiche personalizzate come hobby."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:132
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_59b017e5:

    # mc_t "I guess that's{#female} me."
    mc_t "Immagino di essere {#female} io."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:134
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_732e8328:

    # mc_t "I guess that's{#male} me."
    mc_t "Immagino che sia{#male} io."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:137
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_49fecaad:

    # phone_ai "The technical challenge lies in programming the processor, so it can interpret the data that you store in the cards."
    phone_ai "La sfida tecnica sta nel programmare il processore, in modo che possa interpretare i dati memorizzati nelle carte."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:140
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8cdbd17b:

    # mc "Nah, I prefer to start right away." with dis_std
    mc "No, preferisco iniziare subito." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:143
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3db3613c:

    # phone_ai "Sure!"
    phone_ai "Sicuro!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:145
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_440cd0ab:

    # phone_ai "But before we start, tell me..."
    phone_ai "Ma prima di iniziare, dimmi..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:146
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_866e820f:

    # phone_ai "What do you want to do with this device?"
    phone_ai "Cosa vuoi fare con questo dispositivo?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:149
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9696edcb:

    # mc "Heh, that's a good question..."
    mc "Eh, è una bella domanda..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:152
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0ac30d5f:

    # mc ". . ." with dis_std_med
    mc ". . ." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:158
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c9b94be4:

    # mc "I want to materialize science." with dis_std_med
    mc "Voglio materializzare la scienza." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:161
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8e99d4af:

    # phone_ai "Materialize science? What do you mean?"
    phone_ai "Materializzare la scienza? Cosa intendi?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:164
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_86ccbf30:

    # mc "I'm going to turn this thing into a bridge between imagination and reality."
    mc "Trasformerò questa cosa in un ponte tra immaginazione e realtà."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:165
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7ad5c3a8:

    # mc "It will be my personal tool, for my adventure!"
    mc "Sarà il mio strumento personale, per la mia avventura!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:166
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8aaaaecb:

    # mc "And I'll call it...{w} science-link."
    mc "E lo chiamerò...{w} science-link."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:169
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9f3d226a:

    # phone_ai "[mc.name!t], this device is an experimental toy for children."
    phone_ai "[mc.name!t], questo dispositivo è un giocattolo sperimentale per bambini."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:170
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ad45ec63:

    # phone_ai "It's not prepared for complex abstract structures! Besides, it will interpret all cards the same way."
    phone_ai "Non è preparato per strutture astratte complesse! Inoltre, interpreterà tutte le carte allo stesso modo."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:173
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_62949dc7:

    # mc "I don't care."
    mc "Non mi interessa."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:176
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_467bb10c:

    # mc "Come on, let's get to work!" with dis_std_med
    mc "Dai, mettiamoci al lavoro!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:179
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_44782d3d:

    # phone_ai "But there are different sciences! Each discipline has its own scientific method and corpus of knowledge."
    phone_ai "Ma ci sono scienze diverse! Ogni disciplina ha il proprio metodo scientifico e il proprio corpus di conoscenze."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:182
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e45cab7e:

    # mc "No, you're wrong."
    mc "No, ti sbagli."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:185
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_83c33928:

    # phone_ai "But the consensus in the scientific community is that—"
    phone_ai "Ma il consenso nella comunità scientifica è che..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:188
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d88657b3:

    # mc "They're all wrong."
    mc "Hanno tutti torto."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:191
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_03bc110d:

    # phone_ai "But the Theory of Categorial Closure says that—"
    phone_ai "Ma la teoria della chiusura categoriale dice che:"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:194
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2ac9a389:

    # mc "I don't know what the fuck that is, BUT IT'S ALSO WRONG."
    mc "Non so che cazzo sia, MA E' ANCHE SBAGLIATO."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:197
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_039707c7:

    # phone_ai "But—"
    phone_ai "Ma..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:200
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_99869ebc:

    # mc "LISTEN CAREFULLY, YOU SOULLESS MACHINE!"
    mc "ASCOLTA ATTENTAMENTE, MACCHINA SENZA ANIMA!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:201
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ce1bd395:

    # mc "There's only one science..."
    mc "Esiste una sola scienza..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:202
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_5cfb6fd5:

    # mc "The art of building a better world for all humanity!"
    mc "L'arte di costruire un mondo migliore per tutta l'umanità!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:203
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_a4cf10fc:

    # phone_ai ". . ."
    phone_ai ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:206
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3dc7813a:

    # phone_ai "Okay."
    phone_ai "Va bene."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:209
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2b17f4a3:

    # phone_ai "Let's start then." with dis_std_med
    phone_ai "Cominciamo allora." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:210
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0b9b5176:

    # mc "Great!"
    mc "Grande!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:215
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_30855a28:

    # phone_ai "Here's a code template in Rust to get started." with pixellate_std
    phone_ai "Ecco un modello di codice in Rust per iniziare." with pixellate_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:217
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_dbde8b8f:

    # mc "W-Wait, wait!"
    mc "W-Aspetta, aspetta!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:222
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_10b1dbc0:

    # mc "I know nothing about programming!"
    mc "Non so niente di programmazione!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:223
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3619a885:

    # phone_ai "This is the only way to customize the processor."
    phone_ai "Questo è l'unico modo per personalizzare il processore."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:224
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_04709af6:

    # phone_ai "Since I don't understand what you want, you'll have to tell me what to do step by step."
    phone_ai "Dato che non capisco cosa vuoi, dovrai dirmi cosa fare passo dopo passo."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:227
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_dce5977c:

    # mc_t "Fuck..."
    mc_t "Fanculo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:228
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_955e76b2:

    # mc_t "What do I do now?"
    mc_t "Cosa faccio adesso?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:229
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ad909a8e_1:

    # mc "Hmmm..."
    mc "Hmm..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:230
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_b6d577b1:

    # mc "Can we make it more visual?"
    mc "Possiamo renderlo più visivo?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:231
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_1a551acd:

    # mc "I mean, you could generate an interactive scheme or something, where I can share my thoughts."
    mc "Voglio dire, potresti generare uno schema interattivo o qualcosa del genere, in cui posso condividere i miei pensieri."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:232
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9708f578:

    # mc "Then, you'd just have to translate everything to real code."
    mc "Quindi, dovresti semplicemente tradurre tutto in codice reale."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:233
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7e79b281:

    # phone_ai "Yeah, sure!"
    phone_ai "Sì, certo!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:238
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8a8b383a:

    # phone_ai "What do you want to build?" with pixellate_std
    phone_ai "Cosa vuoi costruire?" with pixellate_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:240
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d24bc72b:

    # mc "Let's see..."
    mc "Vediamo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:241
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_f3bd2f3d:

    # mc "Pick the 6 most general scientific fields you can find, and I'll do the rest!"
    mc "Scegli i 6 campi scientifici più generali che riesci a trovare e io farò il resto!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:242
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_4801c5cf:

    # phone_ai "Understood."
    phone_ai "Inteso."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:251
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_adfc125c:

    # phone_ai "Something like this?" with pixellate_std
    phone_ai "Qualcosa del genere?" with pixellate_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:253
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_4c5cef4d:

    # mc "Wow, now we're talking!"
    mc "Wow, ora stiamo parlando!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:254
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d776fb3c:

    # phone_ai "Happy to help!"
    phone_ai "Lieto di aiutarla!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:255
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ddea2aa2:

    # mc "Alright, let me show you what I mean by one science..."
    mc "Va bene, lascia che ti mostri cosa intendo per scienza..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:256
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7e33a926:

    # mc_t "You can do this, [mc.name!t]."
    mc_t "Puoi farlo, [mc.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:257
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e2eb81ee:

    # mc_t "Just remember the words of your grandpa, and pick the scientific fields in the right order!"
    mc_t "Ricorda semplicemente le parole di tuo nonno e scegli i campi scientifici nell'ordine giusto!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:258
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d911398e:

    # mc_t "Let's begin with..."
    mc_t "Cominciamo con..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:262
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2e507c2a:

    # mc_t "“Science starts with pure imagination.”"
    mc_t "“La scienza inizia con la pura immaginazione.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:271
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:276
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ed0d2c85:

    # mc "At first, we only have abstract ideas. Nothing real yet, just pure imagination!" with dis_std
    mc "All’inizio abbiamo solo idee astratte. Niente di reale per ora, solo pura immaginazione!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:278
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0041d295:

    # mc "At first, we only have abstract ideas. Nothing real yet, just pure imagination!"
    mc "All’inizio abbiamo solo idee astratte. Niente di reale per ora, solo pura immaginazione!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:279
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_d66d8767:

    # mc "And if we want to build concepts rigorously, we have..."
    mc "E se vogliamo costruire concetti in modo rigoroso, abbiamo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:285
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_aff256a2:

    # mc "Mathematics!" with dis_std_med
    mc "Matematica!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:288
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_f52cbf92:

    # phone_ai "Indeed, that's essential."
    phone_ai "In effetti, questo è essenziale."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:290
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_ea225cae:

    # mc_t "I may sound clever{#female}, but my grandpa deserves all the credit, hehe."
    mc_t "Potrò sembrare intelligente{#female}, ma mio nonno merita tutto il merito, eheh."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:292
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7c9667c5:

    # mc_t "I may sound clever{#male}, but my grandpa deserves all the credit, hehe."
    mc_t "Potrò sembrare intelligente{#male}, ma mio nonno merita tutto il merito, eheh."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:293
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3982de42:

    # mc_t "Now, the next one!"
    mc_t "Ora, il prossimo!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:297
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_bd5aa20b:

    # mc_t "“We do experiments to find the rules of reality.”"
    mc_t "“Facciamo esperimenti per trovare le regole della realtà.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:306
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d_1:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:311
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_bb694d89:

    # mc "Once we have well-defined concepts, we do experiments to check if they can explain the universe!" with dis_std
    mc "Una volta che abbiamo concetti ben definiti, facciamo esperimenti per verificare se possono spiegare l'universo!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:313
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3aa01da7:

    # mc "Once we have well-defined concepts, we do experiments to check if they can explain the universe!"
    mc "Una volta che abbiamo concetti ben definiti, facciamo esperimenti per verificare se possono spiegare l'universo!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:314
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_4d9c93c9:

    # mc "Because reality has rules, and they are all compiled in..."
    mc "Perché la realtà ha delle regole, e sono tutte compilate in..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:320
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_a1b2aa75:

    # mc "Physics!" with dis_std_med
    mc "Fisica!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:322
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_49c6bc8f:

    # phone_ai "So you defend a physicalist view of reality. Is that correct?"
    phone_ai "Quindi difendi una visione fisicalista della realtà. È corretto?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:324
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c3ac517a:

    # mc "Umm... I'm not a philosopher{#female}."
    mc "Uhm... non sono un filosofo{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:326
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_aed6aa62:

    # mc "Umm... I'm not a philosopher{#male}."
    mc "Uhm... non sono un filosofo{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:327
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_af848a71:

    # mc "But if someone discovers something new, Physics can grow to include it, right?"
    mc "Ma se qualcuno scopre qualcosa di nuovo, la Fisica può crescere fino ad includerlo, giusto?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:328
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_22498c4e_1:

    # phone_ai "Of course!"
    phone_ai "Ovviamente!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:329
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_fef04298:

    # mc_t "Okay, let's continue..."
    mc_t "Ok, continuiamo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:333
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_1e6d9fd4:

    # mc_t "“Everything is made of matter, even ourselves.”"
    mc_t "“Tutto è fatto di materia, anche noi stessi.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:342
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d_2:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:347
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_33c25d08:

    # mc "Sometimes, physical explanations get too...{w} complicated." with dis_std
    mc "A volte le spiegazioni fisiche diventano troppo...{w} complicate." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:349
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_a419a859:

    # mc "Sometimes, physical explanations get too...{w} complicated."
    mc "A volte le spiegazioni fisiche diventano troppo...{w} complicate."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:350
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_6285a96d:

    # mc "That's why we invent easier ideas!"
    mc "Ecco perché inventiamo idee più facili!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:351
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2519ce94:

    # mc "For example, we came up with the idea of “matter”. Scientists say our world, and even ourselves, are made of it."
    mc "A noi, ad esempio, è venuta l’idea di “materia”. Gli scienziati sostengono che il nostro mondo, e anche noi stessi, ne siamo fatti."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:352
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e10c7cca:

    # mc "And if we focus on its composition, and how it changes, we have..."
    mc "E se ci concentriamo sulla sua composizione, e su come cambia, abbiamo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:358
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0e3c946e:

    # mc "Chemistry!" with dis_std_med
    mc "Chimica!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:360
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_96f55fff:

    # phone_ai "I think I can identify the pattern you're following."
    phone_ai "Penso di poter identificare lo schema che stai seguendo."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:361
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_1cdf808f:

    # phone_ai "Next one would be—"
    phone_ai "Il prossimo sarebbe..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:362
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2b3b554c:

    # mc "SHHHH, no spoilers! Let me finish!"
    mc "SHHHH, niente spoiler! Fammi finire!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:363
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_4801c5cf_1:

    # phone_ai "Understood."
    phone_ai "Inteso."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:367
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_52f3588a:

    # mc_t "“Life is a physical process.”"
    mc_t "“La vita è un processo fisico.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:376
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d_3:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:381
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_38fafd47:

    # mc "I don't know how, but over time... matter on this planet turned into things that are born, grow, reproduce, and die." with dis_std
    mc "Non so come, ma col tempo... la materia su questo pianeta si è trasformata in cose che nascono, crescono, si riproducono e muoiono." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:383
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2f2a9af4:

    # mc "I don't know how, but over time... matter on this planet turned into things that are born, grow, reproduce, and die."
    mc "Non so come, ma col tempo... la materia su questo pianeta si è trasformata in cose che nascono, crescono, si riproducono e muoiono."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:384
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_dcb82eef:

    # mc "We call that “life”, and it's possible thanks to a chemical element called carbon."
    mc "La chiamiamo “vita” ed è possibile grazie a un elemento chimico chiamato carbonio."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:385
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_aefe5b28:

    # mc_t "Hmmm..."
    mc_t "Hmm..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:386
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e45a57e5:

    # mc_t "Could life exist with a different element?"
    mc_t "Potrebbe esistere la vita con un elemento diverso?"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:387
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3f0ae8ef:

    # mc "All those living beings, from bacteria to us, are studied by..."
    mc "Tutti quegli esseri viventi, dai batteri a noi, sono studiati da..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:393
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8b1fa438:

    # mc "Biology!" with dis_std_med
    mc "Biologia!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:395
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_49b0cc08:

    # mc "Do you see it now? These fields are not just connected, but based upon each other!"
    mc "Lo vedi adesso? Questi campi non sono solo collegati, ma basati l’uno sull’altro!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:396
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_169a676d:

    # phone_ai "You're totally right!"
    phone_ai "Hai perfettamente ragione!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:397
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_6189ae2c:

    # phone_ai "In fact, some philosophers—"
    phone_ai "In effetti, alcuni filosofi..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:398
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_45d62e35:

    # mc "AHEM!"
    mc "EHEM!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:399
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_bb6a3445:

    # mc "As I was saying..."
    mc "Come stavo dicendo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:403
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_2b589924:

    # mc_t "“Human behavior is shaped by the environment.”"
    mc_t "“Il comportamento umano è modellato dall’ambiente.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:412
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d_4:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:417
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7f69ac8d:

    # mc "Some living organisms, like animals, can learn and modify their behavior with each new experience." with dis_std
    mc "Alcuni organismi viventi, come gli animali, possono apprendere e modificare il proprio comportamento con ogni nuova esperienza." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:419
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7f301b68:

    # mc "Some living organisms, like animals, can learn and modify their behavior with each new experience."
    mc "Alcuni organismi viventi, come gli animali, possono apprendere e modificare il proprio comportamento con ogni nuova esperienza."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:420
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_98307d35:

    # mc "But human behavior is much more complex! So we try to understand it with..."
    mc "Ma il comportamento umano è molto più complesso! Allora proviamo a capirlo con..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:426
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_7814eedc:

    # mc "Psychology!" with dis_std_med
    mc "Psicologia!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:428
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_a979fb65:

    # mc_t "And finally, the most important part..."
    mc_t "E infine, la parte più importante..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:432
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_1ce022b2:

    # mc_t "“All wonders of science would be nothing more than a pile of garbage... if they didn't serve to make a better world.”"
    mc_t "“Tutte le meraviglie della scienza non sarebbero altro che un mucchio di spazzatura... se non servissero a creare un mondo migliore.”"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:441
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_3ca0a07d_5:

    # mc_t "Nope, that's not it."
    mc_t "No, non è quello."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:446
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_c7a7c243:

    # mc "Scientific theories are cooonstantly changing." with dis_std
    mc "Le teorie scientifiche stanno cambiando costantemente." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:448
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_6499daee:

    # mc "Scientific theories are cooonstantly changing."
    mc "Le teorie scientifiche stanno cambiando costantemente."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:449
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e5ef62b3:

    # mc "So science is not about truth, as many people think... but about being useful!"
    mc "Quindi la scienza non riguarda la verità, come molti pensano... ma l'essere utili!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:450
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_9882a441:

    # mc "And for making technology, we have..."
    mc "E per creare tecnologia, abbiamo..."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:456
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_0aa3b1c5:

    # mc "Engineering!" with dis_std_med
    mc "Ingegneria!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:458
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8a91d749:

    # mc "That's the end goal of science: making a better world."
    mc "Questo è l’obiettivo finale della scienza: creare un mondo migliore."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:460
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_e9886581:

    # phone_ai "Very elegant disposition, [mc.name!t]!"
    phone_ai "Disposizione molto elegante, [mc.name!t]!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:461
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_63cd9671:

    # phone_ai "Unfortunately, I'll need more instructions in order to program the neuroholographic stimulator."
    phone_ai "Sfortunatamente, avrò bisogno di più istruzioni per programmare lo stimolatore neuroolografico."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:463
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_8488f58e:

    # mc "No problem!"
    mc "Nessun problema!"

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:464
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_5f5d289a:

    # mc "We'll keep using this system, over and over again, until the science-link is finished."
    mc "Continueremo a usare questo sistema, ancora e ancora, finché il collegamento scientifico non sarà terminato."

# game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:465
translate italian scene__book1__c1_awakening__e04_radical_change__s03_only_one_science_fea40f79:

    # mc "Patience is the mother of science!"
    mc "La pazienza è la madre della scienza!"

translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:86
    old "Yes{#chapter1-ai-summary}"
    new "Sì{#chapter1-ai-summary}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/script.rpy:139
    old "No, let's start now{#chapter1-ai-summary}"
    new "No, cominciamo adesso{#chapter1-ai-summary}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
