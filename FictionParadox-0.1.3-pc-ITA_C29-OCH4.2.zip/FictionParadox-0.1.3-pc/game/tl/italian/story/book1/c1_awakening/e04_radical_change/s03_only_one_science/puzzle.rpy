﻿
translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:14
    old "BIOLOGY{#chapter1-puzzle}"
    new "BIOLOGIA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:24
    old "CHEMISTRY{#chapter1-puzzle}"
    new "CHIMICA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:34
    old "MATHEMATICS{#chapter1-puzzle}"
    new "MATEMATICA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:44
    old "ENGINEERING{#chapter1-puzzle}"
    new "INGEGNERIA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:54
    old "PSYCHOLOGY{#chapter1-puzzle}"
    new "PSICOLOGIA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:64
    old "PHYSICS{#chapter1-puzzle}"
    new "FISICA{#chapter1-puzzle}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:208
    old "PURE IMAGINATION:{#chapter1-puzzle-clue}"
    new "PURA IMMAGINAZIONE:{#chapter1-puzzle-clue}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:215
    old "THE RULES OF REALITY:{#chapter1-puzzle-clue}"
    new "LE REGOLE DELLA REALTÀ:{#chapter1-puzzle-clue}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:222
    old "COMPOSITION OF MATTER:{#chapter1-puzzle-clue}"
    new "COMPOSIZIONE DELLA MATERIA:{#chapter1-puzzle-clue}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:229
    old "LIVING BEINGS:{#chapter1-puzzle-clue}"
    new "ESSERI VIVENTI:{#chapter1-puzzle-clue}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:236
    old "PEOPLE'S BEHAVIOR:{#chapter1-puzzle-clue}"
    new "COMPORTAMENTO DELLE PERSONE:{#chapter1-puzzle-clue}"

    # game/story/book1/c1_awakening/e04_radical_change/s03_only_one_science/puzzle.rpy:243
    old "TRANSFORM THE WORLD:{#chapter1-puzzle-clue}"
    new "TRASFORMA IL MONDO:{#chapter1-puzzle-clue}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
