﻿
translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s01_gloomy_world/scene.rpy:6
    old "Gloomy World{#story-scene}"
    new "Mondo cupo{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
