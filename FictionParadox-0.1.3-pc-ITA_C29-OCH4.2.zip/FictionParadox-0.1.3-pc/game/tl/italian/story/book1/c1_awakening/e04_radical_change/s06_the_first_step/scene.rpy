﻿
translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s06_the_first_step/scene.rpy:6
    old "The First Step{#story-scene}"
    new "Il primo passo{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
