﻿
translate italian strings:

    # game/story/book1/c1_awakening/chapter.rpy:15
    old "Awakening{#story-chapter}"
    new "Risveglio{#story-chapter}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
