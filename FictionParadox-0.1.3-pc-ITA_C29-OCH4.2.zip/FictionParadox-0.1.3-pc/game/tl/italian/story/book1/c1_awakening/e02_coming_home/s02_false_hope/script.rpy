﻿
# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:33
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7a05e4be:

    # mc_t "Almost home." with dis_std
    mc_t "Quasi a casa." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:34
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d2c95f16:

    # mc_t "At least this neighborhood is not as crowded as other parts of Verona."
    mc_t "Almeno questo quartiere non è affollato come altre parti di Verona."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:35
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2b534ab7:

    # mc_t "I like it that way..."
    mc_t "Mi piace così..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:38
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ad2bc309:

    # mc "Hm?" with dis_std
    mc "Ehm?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:41
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_53f14257:

    # mc_t "Wait, that guy..." with dis_std_med
    mc_t "Aspetta, quel ragazzo..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:44
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1d5cc967:

    # mc_t "Is that Bogdan?"
    mc_t "Quello è Bogdan?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:45
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b0f804f0:

    # mc_t "Oh no... Please no... Don't tell me he's messing around with a robot AGAIN..."
    mc_t "Oh no... Per favore no... Non dirmi che sta ANCORA scherzando con un robot..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:46
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_95582817:

    # mc_t "I have to see what he's up to!"
    mc_t "Devo vedere cosa sta combinando!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:50
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_35862e70:

    # mc "Hey, Bogdan!" with dis_std_med
    mc "Ehi, Bogdan!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:53
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8dce6d31:

    # bogdan "Hello [mc.name!t]!"
    bogdan "Ciao [mc.name!t]!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:54
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_12782af7:

    # bogdan "You good today, or face still like sad potato?"
    bogdan "Stai bene oggi, o hai ancora la faccia triste come una patata?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:57
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_039141ba:

    # mc "Uh... sad potato, I guess."
    mc "Uh... triste patata, immagino."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:59
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_78e6f770:

    # mc_t "Holy shit, today's robot looks creepy as fuck!"
    mc_t "Santo cielo, il robot di oggi è dannatamente inquietante!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:60
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_06f89b02:

    # mc "Can I ask what is that... thing?"
    mc "Posso chiederti cos'è quella... cosa?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:63
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_db47cf3c:

    # bogdan "This is Telegrim! My new best buddy!"
    bogdan "Questo è Telegrim! Il mio nuovo migliore amico!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:64
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4089323a:

    # bogdan "He dance, he talk, he... uh, not explode. Bogdan promise!"
    bogdan "Balla, parla, lui... uh, non esplode. Promessa di Bogdan!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:67
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_3d865c91:

    # mc "T-That's cool, haha..."
    mc "T-Che bello, ahah..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:70
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_01dbaa18:

    # mc "{act}comes closer{/act}" with dis_std_med
    mc "{act}si avvicina{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:71
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_60a04d89:

    # mc "Did you assemble it yourself?"
    mc "L'hai assemblato tu stesso?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:74
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1258ccc6:

    # bogdan "Yes."
    bogdan "SÌ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:77
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_3b0ff327:

    # mc "That's admirable!"
    mc "È ammirevole!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:78
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_39a4c9f0:

    # mc "But... why does it look like a retro TV? I don't get it."
    mc "Ma... perché sembra un televisore retrò? Non capisco."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:81
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_43104e44:

    # bogdan "It is real TV."
    bogdan "È la vera televisione."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:84
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:88
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_701d2464:

    # mc "What!?"
    mc "Che cosa!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:89
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_aaf1da9b:

    # mc "You recycled an actual TV!?"
    mc "Hai riciclato una vera TV!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:92
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8bdc254e:

    # bogdan "As we say in Serbia: “ko hoće nađe način”."
    bogdan "Come diciamo in Serbia: “ko hoće nađe način”."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:95
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_05500ff6:

    # mc "Huh?"
    mc "Eh?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:98
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4d065b48:

    # bogdan "“If there is will, there is way”."
    bogdan "“Se c’è la volontà, c’è la strada”."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:101
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_054c5ee0:

    # mc "I see."
    mc "Vedo."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:104
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_cd62ee6f:

    # bogdan "Bogdan like retro robots. They cute."
    bogdan "A Bogdan piacciono i robot retrò. Sono carini."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:105
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d6fd350f:

    # bogdan "And Telegrim is funny! When plug in, wires go ZZZT, ZZZT!"
    bogdan "E Telegrim è divertente! Quando si collega, i cavi fanno ZZZT, ZZZT!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:108
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_77a89e99_1:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:111
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d16ad01c:

    # mc "Look, Bogdan..." with dis_std_med
    mc "Guarda, Bogdan..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:112
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4ae8d20e:

    # mc "I don't think this is a good idea."
    mc "Non penso che questa sia una buona idea."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:113
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d3a77b7f:

    # mc "Why not take up gardening? This neighborhood could use more plants!"
    mc "Perché non dedicarsi al giardinaggio? Questo quartiere potrebbe usare più piante!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:116
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c35f754c:

    # bogdan "Don't worry!" with dis_std
    bogdan "Non preoccuparti!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:118
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a378177d:

    # bogdan "Follow guide from forum. Easy peasy!"
    bogdan "Segui la guida dal forum. Facile facile!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:121
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fd8589ff:

    # mc "Yeah, right, “easy peasy”..." with dis_std
    mc "Sì, giusto, 'facile facile'..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:122
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d310b876:

    # mc "Last time you configured a robot, your house nearly went up in flames!"
    mc "L'ultima volta che hai configurato un robot, la tua casa è quasi andata in fiamme!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:125
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_5be10ae2:

    # bogdan "Nah, Telegrim is good boy."
    bogdan "No, Telegrim è un bravo ragazzo."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:128
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_eab330a2:

    # unknown "{act}passing by{/act} Hey Bogdan."
    unknown "{act}passando{/act} Ciao Bogdan."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:132
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6afa0a10:

    # bogdan "Hey [ll.name!t]!" with dis_std
    bogdan "Ehi [ll.name!t]!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:135
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fad3f6d0:

    # ll "{act}going up the stairs{/act} Don't mess up, please!" with dis_std
    ll "{act}salendo le scale{/act} Non fare confusione, per favore!" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:138
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_77288975:

    # bogdan "Don't wo—"
    bogdan "Non fare—"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:142
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a0745aa0:

    # mc "Wait, [ll.name!t]!"
    mc "Aspetta, [ll.name!t]!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:143
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7e6be3d9:

    # mc "I have to tell you something!"
    mc "Devo dirti una cosa!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:146
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fa80866a:

    # ll "{act}looks at you{/act}" with dis_std_med
    ll "{act}ti guarda{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:149
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4ed0a713:

    # ll "{act}keeps walking{/act}" with dis_std_med
    ll "{act}continua a camminare{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:150
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_189531c6:

    # mc "H-HEY! I'M SERIOUS!"
    mc "H-EHI! DICO SUL SERIO!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:152
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_691ab580:

    # mc_t "Why does she always ignore me!?"
    mc_t "Perché mi ignora sempre!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:154
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b71c498f:

    # mc_t "Why does he always ignore me!?"
    mc_t "Perché mi ignora sempre!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:162
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7e4ec3eb:

    # mc "{act}panting{/act} Thanks... for... waiting for me..." with dis_std
    mc "{act}ansima{/act} Grazie... per... avermi aspettato..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:165
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_db02c467:

    # ll "What do you want?"
    ll "Cosa vuoi?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:169
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_bf0ac226:

    # mc_t "That's [ll.name!t], my neighbor{#female}."
    mc_t "Quello è [ll.name!t], il mio vicino{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:171
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7877ecc9:

    # mc_t "That's [ll.name!t], my neighbor{#male}."
    mc_t "Quello è [ll.name!t], il mio vicino{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:178
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_48e07de2:

    # mc_t "She's the closest thing I have to a friend{#female}." with dis_std
    mc_t "È la cosa più vicina a un'amica che ho{#female}." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:180
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_31552e9d:

    # mc_t "He's the closest thing I have to a friend{#male}." with dis_std
    mc_t "È la cosa più vicina a un amico che ho{#male}." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:184
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f5b57679:

    # ll "You look like a damn junkie{#female}."
    ll "Sembri un dannato drogato{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:186
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_454a062e:

    # ll "You look like a damn junkie{#male}."
    ll "Sembri un maledetto drogato{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:189
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8888c25c:

    # mc "Wow, that outfit's cool. Coming from the gym?"
    mc "Wow, che bel vestito. Vieni dalla palestra?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:192
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c6a0cc4c:

    # ll "Boxing."
    ll "Boxe."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:195
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_05500ff6_1:

    # mc "Huh?"
    mc "Eh?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:198
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_5970ab1c:

    # ll "Coming from boxing class."
    ll "Proveniente dal corso di boxe."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:199
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_76681154:

    # ll "Now get to the point. What do you want?"
    ll "Ora arriviamo al punto. Cosa vuoi?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:202
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c14c584c:

    # mc "Well..."
    mc "BENE..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:203
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_715a4429:

    # mc "I saw [dd.name!t] today!"
    mc "Ho visto [dd.name!t] oggi!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:206
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_e69c6dfd:

    # ll "Oh shit! [dd.name!t]!?" with dis_std
    ll "Oh merda! [dd.name!t]!?" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:209
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_92f6b9bd:

    # mc "Yeah, in the library!"
    mc "Sì, in biblioteca!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:213
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_71074840:

    # ll "But she told me she wouldn't arrive until next week!"
    ll "Ma lei mi ha detto che non sarebbe arrivata prima della prossima settimana!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:215
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a59d6589:

    # ll "But he told me he wouldn't arrive until next week!"
    ll "Ma mi ha detto che non sarebbe arrivato prima della prossima settimana!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:219
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7558a367:

    # mc "You should turn on your phone! She texted you, but her messages didn't go through."
    mc "Dovresti accendere il telefono! Ti ha mandato un messaggio, ma i suoi messaggi non sono arrivati."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:221
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_35be3e0a:

    # mc "You should turn on your phone! He texted you, but his messages didn't go through."
    mc "Dovresti accendere il telefono! Ti ha mandato un messaggio, ma i suoi messaggi non sono arrivati."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:225
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8c3745f6:

    # ll "Did you talk with her!? How is she!?"
    ll "Hai parlato con lei!? Come sta!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:227
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b48e9723:

    # ll "Did you talk with him!? How is he!?"
    ll "Hai parlato con lui!? Come sta!?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:231
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6dbc181c:

    # mc "She's fine, relax..."
    mc "Sta bene, rilassati..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:233
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d1de8ed4:

    # mc "He's fine, relax..."
    mc "Sta bene, rilassati..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:236
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1b0868a2:

    # mc "You know, it's been years since the last time I saw her." with dis_std_med
    mc "Sai, sono passati anni dall'ultima volta che l'ho vista." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:239
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c03c5f6e:

    # ll "And?"
    ll "E?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:242
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2387202e:

    # mc "Just feeling a bit nostalgic, I guess..."
    mc "Mi sento solo un po' nostalgico, immagino..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:243
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_79f078ac:

    # mc "Adult life is tough."
    mc "La vita adulta è dura."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:246
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_994dfe24:

    # ll "Complaining won't change anything."
    ll "Lamentarsi non cambierà nulla."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:249
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_916f0429:

    # ll "But yeah, adult life sucks." with dis_std_med
    ll "Ma sì, la vita adulta fa schifo." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:250
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_71f8359b:

    # ll "Best we can do is keep moving forward."
    ll "La cosa migliore che possiamo fare è continuare ad andare avanti."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:253
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_e0594448:

    # mc "I guess you're right..."
    mc "Immagino che tu abbia ragione..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:256
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2802c467:

    # mc "I never imagined Verona would end up like this..." with dis_std_med
    mc "Non avrei mai immaginato che Verona sarebbe finita così..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:258
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_87b3229c:

    # mc "It keeps growing... and growing... and here we are, watching from the sidelines."
    mc "Continua a crescere... e a crescere... ed eccoci qui, a guardare da bordocampo."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:259
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_92a5a37b:

    # ll "That's all we can do."
    ll "Questo è tutto ciò che possiamo fare."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:260
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_723b594d:

    # mc "But this city was supposed to be different! I mean, we all moved here to build the future!"
    mc "Ma questa città avrebbe dovuto essere diversa! Voglio dire, ci siamo trasferiti tutti qui per costruire il futuro!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:261
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_9fb719bf:

    # mc "I feel bad for not being able to... do anything."
    mc "Mi sento male per non poter fare nulla."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:262
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_42f48362:

    # ll "You keep blaming the city, but the city ain't the problem."
    ll "Continui a incolpare la città, ma il problema non è la città."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:263
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c36d8448:

    # ll "It's human nature."
    ll "È la natura umana."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:264
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6bf92d30:

    # ll "Verona just shows the scumbags we really are: selfish, lazy, cowards. It cannot be changed."
    ll "Verona mostra solo i furfanti che siamo veramente: egoisti, pigri, codardi. Non può essere cambiato."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:266
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_171acdc5:

    # ll "So stop thinking like a kid{#female}, and accept it already."
    ll "Quindi smetti di pensare come un bambino{#female} e accettalo già."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:268
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_69e8ea10:

    # ll "So stop thinking like a kid{#male}, and accept it already."
    ll "Quindi smetti di pensare come un bambino{#male} e accettalo già."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:269
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_780c04f1:

    # mc "I can't..."
    mc "non posso..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:270
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d34a00b4:

    # ll "{act}sighs{/act} You'll never grow up."
    ll "{act}sospira{/act} Non crescerai mai."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:273
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ee06439d:

    # mc_t "If only I could turn back time..." with dis_std_med
    mc_t "Se solo potessi tornare indietro nel tempo..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:274
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_cd6ae2bb:

    # mc_t "Back to when I still had a dream to believe in."
    mc_t "A quando avevo ancora un sogno in cui credere."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:285
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_31ffea3c:

    # mc_t "This is it. I can't believe it..." with dis_std
    mc_t "Questo è tutto. Non posso crederci..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:286
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_062aab0f:

    # mc_t "High school is over!"
    mc_t "Il liceo è finito!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:287
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b41f3a66:

    # mc_t "My grades aren't enough, so... college is out of the picture."
    mc_t "I miei voti non sono sufficienti, quindi... il college è fuori dai giochi."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:288
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4bd937ac:

    # mc_t "But screw it, I'll find my way!"
    mc_t "Ma al diavolo, troverò la mia strada!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:291
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f1c3e005:

    # mc "What will you do in the end, [ll.name!t]?" with dis_std_med
    mc "Cosa farai alla fine, [ll.name!t]?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:294
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ddd13b8e:

    # ll ". . ." with dis_std
    ll ". . ." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:297
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6fca96df:

    # ll "Meh."
    ll "Mah."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:300
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_53067240:

    # mc "You don't sound very happy."
    mc "Non sembri molto felice."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:303
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c76b17db:

    # ll "My family keeps nagging me about going back to China, to take the goddamn Gaokao."
    ll "La mia famiglia continua a tormentarmi chiedendomi di tornare in Cina, per prendere il dannato Gaokao."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:304
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d57e1229:

    # ll "I've told them a thousand times that I hate studying!"
    ll "Gli ho detto mille volte che odio studiare!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:305
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2b0e58cd:

    # ll "But they don't give a shit..."
    ll "Ma non gliene frega niente..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:308
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_01c24d8a:

    # mc "I think they just want the best for you."
    mc "Penso che vogliano solo il meglio per te."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:311
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_48ac276f:

    # ll "Yeah, I know, but this is MY life." with dis_std_med
    ll "Sì, lo so, ma questa è la MIA vita." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:312
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_0580edba:

    # ll "I'd rather train my body than memorize words like a parrot."
    ll "Preferisco allenare il mio corpo piuttosto che memorizzare le parole come un pappagallo."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:315
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_bad9eb65:

    # mc_t "God, [ll.name!t] has a special charm today..." with dis_std_med
    mc_t "Dio, [ll.name!t] ha un fascino speciale oggi..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:317
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b2d8f429:

    # mc_t "She's so strong, but so fucking cute at the same time. That pose with the foot is killing me!"
    mc_t "È così forte, ma così dannatamente carina allo stesso tempo. Quella posa con il piede mi sta uccidendo!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:319
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2f89e624:

    # mc_t "He's so strong, but so fucking cute at the same time. That pose with the foot is killing me!"
    mc_t "È così forte, ma così dannatamente carino allo stesso tempo. Quella posa con il piede mi sta uccidendo!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:323
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fcb5564c:

    # ll "Stop looking at my body like that, or I'll punch you."
    ll "Smettila di guardare il mio corpo in quel modo o ti prendo a pugni."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:326
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_9def9063:

    # mc "S-Sorry, I just couldn't help it."
    mc "S-Sorry, I just couldn't help it."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:329
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_0fc6d7e8:

    # ll "Then control yourself."
    ll "Allora controlla te stesso."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:331
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fdd1af99:

    # ll "You perv{#female}..."
    ll "Pervertito{#female}..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:333
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ccd15371:

    # ll "You perv{#male}..."
    ll "Pervertito{#male}..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:336
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_62252f54:

    # mc "So you're staying in Verona then?"
    mc "Allora rimarrai a Verona?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:339
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1ad52796:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:342
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_766e1dc2:

    # ll "Yeah."
    ll "Sì."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:343
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ddcb0f88:

    # ll "How about you?"
    ll "E tu?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:346
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_94b7cff1:

    # mc "{act}turning around{/act} Of course I'll stay." with dis_std_med
    mc "{act}voltandosi{/act} Certo che resterò." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:348
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d9d1f030:

    # mc "After all, my dream was to live here! I feel so lucky{#female} a humble family like mine got the chance."
    mc "Dopotutto il mio sogno era vivere qui! Mi sento davvero fortunato{#female} che una famiglia umile come la mia abbia avuto questa possibilità."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:350
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b18ecd11:

    # mc "After all, my dream was to live here! I feel so lucky{#male} a humble family like mine got the chance."
    mc "Dopotutto il mio sogno era vivere qui! Mi sento davvero fortunato{#male} che una famiglia umile come la mia abbia avuto questa possibilità."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:351
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8e18b528:

    # mc "Although I still don't know what I want to be..."
    mc "Anche se ancora non so cosa voglio essere..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:354
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4c1565b4:

    # ll "And what are you waiting for?"
    ll "E cosa stai aspettando?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:357
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4a2ef417:

    # mc "I don't know..."
    mc "non lo so..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:358
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_0e13514a:

    # mc "I guess I'll live on basic income for now."
    mc "Immagino che per ora vivrò con il reddito di base."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:359
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_5cf1faeb:

    # mc "And you?"
    mc "E tu?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:362
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fd44d394:

    # ll "Yeah, me too."
    ll "Sì, anch'io."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:363
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_82739d5e:

    # ll "If I need more money, I'll look for a job at a gym or something..."
    ll "Se avrò bisogno di più soldi, cercherò un lavoro in una palestra o qualcosa del genere..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:366
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f661beb5:

    # mc "Sounds good."
    mc "Sembra buono."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:369
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a8b7f359:

    # mc "{act}looking to your left{/act}" with dis_std_med
    mc "{act}guardando alla tua sinistra{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:372
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2f2b43f2:

    # mc "[dd.name!t]'s still there..." with dis_std_med
    mc "[dd.name!t] è ancora lì..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:376
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_e37e1099:

    # ll "Yeah, she loves to debate with the nerds after each exam."
    ll "Sì, adora discutere con i nerd dopo ogni esame."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:378
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8e056005:

    # ll "Yeah, he loves to debate with the nerds after each exam."
    ll "Già, gli piace discutere con i nerd dopo ogni esame."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:379
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_44f4e651:

    # ll "{act}sighs{/act} Even the teacher{#male} has already left..."
    ll "{act}sospira{/act} Anche l'insegnante{#male} se n'è già andato..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:382
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_cbd1f6dc:

    # mc "Oh, you were waiting for her?"
    mc "Oh, la stavi aspettando?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:384
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_78f0fd41:

    # mc "Oh, you were waiting for him?"
    mc "Oh, lo stavi aspettando?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:386
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_29c2af45:

    # ll "Of course!"
    ll "Ovviamente!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:388
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2f80270c:

    # ll "Unlike you, I don't get lost{#female} in daydreaming."
    ll "A differenza di te, io non mi perdo{#female} nei sogni ad occhi aperti."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:390
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_9ac0a069:

    # ll "Unlike you, I don't get lost{#male} in daydreaming."
    ll "A differenza di te, io non mi perdo{#male} nei sogni ad occhi aperti."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:392
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2ff566c9:

    # mc "So you noticed my superpower!"
    mc "Quindi hai notato il mio superpotere!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:395
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8afe1b06:

    # ll "Superpower? Come on, don't make me laugh..." with dis_std_med
    ll "Superpotenza? Dai, non farmi ridere..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:396
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_07a8d00f:

    # mc "{act}laughs{/act}"
    mc "{act}ride{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:400
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7624345f:

    # mc "Dreams are the only place where I feel truly alive{#female}..." with dis_std
    mc "I sogni sono l'unico posto in cui mi sento veramente vivo{#female}..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:402
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f7a1b420:

    # mc "Dreams are the only place where I feel truly alive{#male}..." with dis_std
    mc "I sogni sono l'unico posto in cui mi sento veramente vivo{#male}..." with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:405
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_04320222:

    # ll "It's clear you don't need drugs."
    ll "È chiaro che non hai bisogno di farmaci."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:406
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a11f8607:

    # ll "Knowing you, who knows what dirty thoughts you're picturing in your head..."
    ll "Conoscendoti, chissà quali pensieri sporchi stai immaginando nella tua testa..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:409
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_3b203626:

    # mc "I'm not talking about that."
    mc "Non sto parlando di quello."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:410
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_42584bd9:

    # mc "What I meant, is that I like to imagine the future. There are so many possibilities!"
    mc "Quello che volevo dire è che mi piace immaginare il futuro. Ci sono così tante possibilità!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:414
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_0ebf777d:

    # ll "{act}gets up from the chair{/act}"
    ll "{act}si alza dalla sedia{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:417
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ce2ab49c:

    # mc "You know, I've never told anyone this, but..."
    mc "Sai, non l'ho mai detto a nessuno, ma..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:418
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8e934200:

    # mc "I didn't value real life until very recently."
    mc "Non davo valore alla vita reale fino a poco tempo fa."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:419
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_37d2f840:

    # mc "Crazy, right?"
    mc "Pazzesco, vero?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:420
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_813fa53f:

    # mc "Here in Verona, I feel like I'm part of something bigger, something that gives meaning to my life..."
    mc "Qui a Verona mi sento parte di qualcosa di più grande, qualcosa che dà senso alla mia vita..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:421
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_4a76dd7b:

    # mc "It's so exciting to participate in this experiment!"
    mc "È così emozionante partecipare a questo esperimento!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:424
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1dd29cea:

    # mc "Don't you think, [ll.name!t]?" with dis_std_med
    mc "Non credi, [ll.name!t]?" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:429
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ccbe1b70:

    # ll "{act}running{/act}" with dis_std_med
    ll "{act}in corsa{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:433
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_e09a7e22:

    # dd "WOAH!!"
    dd "WOAH!!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:435
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_694bea2a:

    # michael "Once again, [ll.name!t] and her surprise attacks..."
    michael "Ancora una volta, [ll.name!t] e i suoi attacchi a sorpresa..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:437
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_7e8b515e:

    # michael "Once again, [ll.name!t] and his surprise attacks..."
    michael "Ancora una volta, [ll.name!t] e i suoi attacchi a sorpresa..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:438
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a73d7444:

    # ll "Hehe."
    ll "Eheh."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:441
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6cf88783:

    # ll "{act}smiling{/act} Hmmm~" with dis_std_med
    ll "{act}sorride{/act} Hmmm~" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:444
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_5df0eda7:

    # ll "I love you, [dd.name!t]."
    ll "Ti amo, [dd.name!t]."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:445
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_703dee43:

    # ll "Don't ever change, okay?"
    ll "Non cambiare mai, ok?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:449
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c68d2582:

    # dd "{act}flushed{#female}{/act}" with dis_std_med
    dd "{act}arrossato{#female}{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:451
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_61e5d9f5:

    # dd "{act}flushed{#male}{/act}" with dis_std_med
    dd "{act}arrossato{#male}{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:454
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_92d3c5cf:

    # dd "{act}smiles{/act}" with dis_std_med
    dd "{act}sorride{/act}" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:457
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c9df4839:

    # dd "I love you too, [ll.name!t]."
    dd "Ti amo anch'io, [ll.name!t]."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:460
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d291dc7c:

    # ll "They opened a new café! It's in the French neighbourhood." with dis_std_med
    ll "Hanno aperto una nuova caffetteria! È nel quartiere francese." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:461
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_d3dbc709:

    # dd "Mm-hm."
    dd "Mm-hm."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:462
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_df2c80a5:

    # ll "How about we go for a drink there?"
    ll "Che ne dici di andare a bere qualcosa lì?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:463
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_225f50bf:

    # bong "Ohh~! Like a couple?"
    bong "Ohh~! Come una coppia?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:467
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c33a7c61:

    # dd "{act}flushed{#female}{/act} B-Bong, I have a boyfriend!" with dis_std_med
    dd "{act}arrossata{#female}{/act} B-Bong, ho un fidanzato!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:469
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_76503a05:

    # dd "{act}flushed{#male}{/act} B-Bong, I have a girlfriend!" with dis_std_med
    dd "{act}arrossato{#male}{/act} B-Bong, ho una ragazza!" with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:471
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_5d6f5263:

    # bong "So where's the problem? You could be secret lovers{#female}..."
    bong "Allora dov'è il problema? You could be secret lovers{#female}..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:472
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2b90595c:

    # dd "No no, we're friends{#female}! Just friends{#female}!"
    dd "No no, siamo amici{#female}! Solo amici{#female}!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:474
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_87534386:

    # bong "So where's the problem? You could be secret lovers{#male}..."
    bong "Allora dov'è il problema? Potreste essere amanti segreti{#male}..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:475
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_9cfbba61:

    # dd "No no, we're friends{#male}! Just friends{#male}!"
    dd "No no, siamo amici{#male}! Solo amici{#male}!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:477
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a7d27aa8:

    # bong "So where's the problem? You could be secret lovers{#both-genres}..."
    bong "Allora dov'è il problema? Potreste essere amanti segreti{#both-genres}..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:478
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_8b06d203:

    # dd "No no, we're friends{#both-genres}! Just friends{#both-genres}!"
    dd "No no, siamo amici{#both-genres}! Solo amici{#both-genres}!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:480
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_57359c63:

    # dd "Right, [ll.name!t]?"
    dd "Giusto, [ll.name!t]?"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:481
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_1ad52796_1:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:482
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_766e1dc2_1:

    # ll "Yeah."
    ll "Sì."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:484
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_e941dcdf:

    # michael "{act}laughs{/act} You read too much yuri, Bong."
    michael "{act}ride{/act} Leggi troppo Yuri, Bong."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:486
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f2c49688:

    # michael "{act}laughs{/act} You read too much yaoi, Bong."
    michael "{act}ride{/act} Leggi troppo yaoi, Bong."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:488
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2f0ec1f8:

    # michael "{act}laughs{/act} You read too much hentai, Bong."
    michael "{act}ride{/act} Leggi troppi hentai, Bong."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:489
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2f0c023e:

    # bong "WHAT!? T-That's not true!"
    bong "CHE COSA!? T-Non è vero!"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:492
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_feeb92b0:

    # mc "{act}smiles{/act}" with dis_std
    mc "{act}sorride{/act}" with dis_std

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:501
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_a685f159:

    # mc_t "The others were building their lives..." with dis_std_med
    mc_t "Gli altri stavano costruendo le loro vite..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:503
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_6beacd98:

    # mc_t "Meanwhile, I kept postponing mine. Always acting as a mere spectator{#female}."
    mc_t "Nel frattempo continuavo a rimandare il mio. Agisce sempre come semplice spettatore{#female}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:505
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_f688fbe2:

    # mc_t "Meanwhile, I kept postponing mine. Always acting as a mere spectator{#male}."
    mc_t "Nel frattempo continuavo a rimandare il mio. Agisce sempre come semplice spettatore{#male}."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:506
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_b7e36584:

    # mc "{act}keeps watching the city{/act}"
    mc "{act}continua a guardare la città{/act}"

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:509
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_96b65bf7:

    # mc_t "This city..." with dis_std_med
    mc_t "Questa città..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:511
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_242221bb:

    # mc_t "I thought this city was what I was looking for."
    mc_t "Pensavo che questa città fosse quello che stavo cercando."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:512
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_34fa1e38:

    # mc_t "The original idea of Verona was wonderful! Technically it's viable, but..."
    mc_t "L'idea originale di Verona era meravigliosa! Tecnicamente è fattibile, ma..."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:513
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_fde71125:

    # mc_t "It's clear humanity wants a different path."
    mc_t "È chiaro che l'umanità vuole un percorso diverso."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:516
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_2aef57c8:

    # mc_t "A path I don't agree with..." with dis_std_med
    mc_t "Un percorso che non condivido..." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:518
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_77a89e99_2:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:521
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_bcf430d9:

    # mc "{act}looks towards [ll.name!t]{/act}" with dis_std_med
    mc "{act}guarda verso [ll.name!t]{/act}" with dis_std_med

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:239
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_c9654d16:

    # mc "You know, it's been years since the last time I saw him." with dis_std_med
    mc "Sai, sono passati anni dall'ultima volta che l'ho visto." with dis_std_med

# game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/script.rpy:318
translate italian scene__book1__c1_awakening__e02_coming_home__s02_false_hope_ea94f33a:

    # ll "Yeah, I know, but this is MY life."
    ll "Sì, lo so, ma questa è la MIA vita."

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
