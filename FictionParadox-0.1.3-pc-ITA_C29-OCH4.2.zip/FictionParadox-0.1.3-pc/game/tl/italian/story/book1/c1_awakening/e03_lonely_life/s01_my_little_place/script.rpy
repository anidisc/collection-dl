﻿
# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:44
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place_122930f4:

    # mc_t "Home sweet home..." with dis_std
    mc_t "Casa dolce casa..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:47
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place_0b734ef0:

    # mc_t "I've been very distracted{#female} today. Better open the closet and get changed now, or I'll be late for work!"
    mc_t "Sono stato molto distratto{#female} oggi. Meglio aprire l'armadio e cambiarsi adesso, altrimenti farò tardi al lavoro!"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:49
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place_6f95e2b3:

    # mc_t "I've been very distracted{#male} today. Better open the closet and get changed now, or I'll be late for work!"
    mc_t "Sono stato molto distratto{#male} oggi. Better open the closet and get changed now, or I'll be late for work!"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:100
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__dresser_5930a10e:

    # mc_t "Crap's starting to pile up again..." with dis_std
    mc_t "Le schifezze cominciano ad accumularsi di nuovo..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:101
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__dresser_f85fa36b:

    # mc "{act}sighs{/act} {think}I really hate cleaning.{/think}"
    mc "{act}sospira{/act} {think}Odio davvero pulire.{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:102
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__dresser_1a6f2881:

    # mc_t "Wish I had one of those robots for house chores, but I can't afford it..."
    mc_t "Vorrei avere uno di quei robot per le faccende domestiche, ma non posso permettermelo..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:103
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__dresser_ee1ced50:

    # mc_t "By the way, I should probably hang that picture back up someday. It fell months ago, and I just left it there..."
    mc_t "A proposito, probabilmente un giorno o l'altro dovrei appendere quella foto. È caduto mesi fa e l'ho lasciato lì..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:111
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_53a5eeb3:

    # mc_t "People live here only because the rent is cheap." with dis_std
    mc_t "La gente vive qui solo perché l'affitto è basso." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:112
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_7b5c05d5:

    # mc_t "I mean, this is the shabbiest part of Verona. Grey, lifeless, nothing to do... and that endless noise from the highway."
    mc_t "Voglio dire, questa è la parte più squallida di Verona. Grigio, senza vita, niente da fare... e quel rumore interminabile che arriva dall'autostrada."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:113
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_4126d26f:

    # mc_t "Years ago it was full of people! But once they built better neighborhoods, many left."
    mc_t "Anni fa era pieno di gente! Ma una volta costruiti quartieri migliori, molti se ne sono andati."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:114
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_79b31c3f:

    # mc_t "At least we've got a nice view of the Periphery..."
    mc_t "Almeno abbiamo una bella visuale della periferia..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:115
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_fcfb60c4:

    # mc_t "Looks cool. Although if you ask me, it's just aesthetics. Real life's still shit..."
    mc_t "Sembra bello. Anche se secondo me è solo estetica. La vita reale è ancora una merda..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:118
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_fbc18137:

    # mc_t "Which reminds me I have to fix the air conditioner." with dis_std_med
    mc_t "Il che mi ricorda che devo riparare il condizionatore." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:119
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_2c912e83:

    # mc_t "Last summer was unbearable!"
    mc_t "L'estate scorsa è stata insopportabile!"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:120
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__window_1de2763d:

    # mc_t "And they say every summer will be hotter than the previous one..."
    mc_t "E dicono che ogni estate sarà più calda della precedente..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:128
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_4dc6d1e8:

    # mc_t "This is what the shelf of an empty person looks like..." with dis_std
    mc_t "Ecco come appare lo scaffale di una persona vuota..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:129
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_9a7e450e:

    # mc_t "The only things of value are some legal papers and old documents."
    mc_t "Le uniche cose di valore sono alcune carte legali e vecchi documenti."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:130
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_53a2f670:

    # mc_t "Not that I'd know what else to put here anyway..."
    mc_t "Non che saprei cos'altro mettere qui comunque..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:133
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_e17a15e6:

    # mc_t "And then we have this." with dis_std_med
    mc_t "E poi abbiamo questo." with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:134
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_92926927:

    # mc_t "I barely had an appetite last night, so I ate a bit of pizza, and left it here."
    mc_t "Ieri sera avevo a malapena appetito, quindi ho mangiato un po' di pizza e l'ho lasciata qui."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:136
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_7d3300b2:

    # mc "{act}sighs{/act} {think}No wonder I'm so thin{#female}.{/think}"
    mc "{act}sospira{/act} {think}Non c'è da stupirsi che io sia così magro{#female}.{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:138
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_24c9bdfc:

    # mc "{act}sighs{/act} {think}No wonder I'm so thin{#male}.{/think}"
    mc "{act}sospira{/act} {think}Non c'è da stupirsi che io sia così magro{#male}.{/think}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:139
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__shelves_f28c9cff:

    # mc_t "I'd like to eat better, but... I don't know how to cook."
    mc_t "Vorrei mangiare meglio, ma... non so cucinare."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:191
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bed_0009e9a5:

    # mc_t "This is my bed." with dis_std
    mc_t "Questo è il mio letto." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:192
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bed_7556d336:

    # mc_t "I never bother making it. I mean, what's the point? No one's going to see it..."
    mc_t "Non mi prendo mai la briga di farlo. Voglio dire, qual è il punto? Nessuno lo vedrà..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:193
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bed_bf0d76a0:

    # mc_t "The mattress is crap, but the worst part is the ceiling. I've lost count of how many times I've smashed my head waking up..."
    mc_t "Il materasso è pessimo, ma la cosa peggiore è il soffitto. Ho perso il conto di quante volte mi sono rotta la testa svegliandomi..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:237
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__kitchen_zoom_01f346d1:

    # mc_t "Ugh, what a mess..." with dis_std
    mc_t "Uffa, che confusione..." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:238
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__kitchen_zoom_ad36d340:

    # mc_t "And those burger buns are still waiting..."
    mc_t "E quei panini per hamburger stanno ancora aspettando..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:239
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__kitchen_zoom_200dd1b1:

    # mc_t "What do I do now? I don't want to throw food away, but I'm not going to eat it either..."
    mc_t "Cosa faccio adesso? Non voglio buttare via il cibo, ma non lo mangerò nemmeno..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:246
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bathroom_1049edf9:

    # mc_t "My bathroom is tiny, but has everything I need." with dis_std
    mc_t "Il mio bagno è piccolo, ma ha tutto ciò di cui ho bisogno." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:247
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bathroom_d548ad16:

    # mc_t "Not much else to say..."
    mc_t "Non c'è molto altro da dire..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:248
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__bathroom_e7e2ab5d:

    # mc_t "Always thought it was strange the shower takes up more than half the space, haha."
    mc_t "Ho sempre pensato che fosse strano che la doccia occupasse più della metà dello spazio, ahah."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:258
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_131cb25c:

    # mc "{act}changing clothes{/act}" with dis_std
    mc "{act}cambiare i vestiti{/act}" with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:263
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_2e69777c:

    # mc "{act}adjusting your cap{/act}" with dis_std_long
    mc "{act}regolare il berretto{/act}" with dis_std_long

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:265
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_57fda913:

    # mc_t "Okay, I'm ready{#female}."
    mc_t "Ok, sono pronto{#female}."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:267
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_f880bda4:

    # mc_t "Okay, I'm ready{#male}."
    mc_t "Ok, sono pronto{#male}."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:268
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_f328ae78:

    # mc_t "I'll never get used to this uniform..."
    mc_t "Non mi abituerò mai a questa uniforme..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:271
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_c6fe9f94:

    # mc "{act}sighs{/act} {think}It's too obvious that it's recycled... Not to mention the sticker on the cap.{/think}" with dis_std_med
    mc "{act}sospira{/act} {think}È troppo evidente che è riciclato... Per non parlare dell'adesivo sul tappo.{/think}" with dis_std_med

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:272
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_a163fe25:

    # mc_t "Anyway, let's go."
    mc_t "Comunque, andiamo."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:281
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_0b0bbaae:

    # mc_t "The glider's already there." with dis_std
    mc_t "L'aliante è già lì." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:282
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_2366f45b:

    # mc_t "On time, as always."
    mc_t "Puntuali, come sempre."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:283
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:284
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_cf98a8d5:

    # mc_t "{bt=5}{color=aee7ff}WHYYYYYYYYY...{/color}{/bt}"
    mc_t "{bt=5}{color=aee7ff}PERCHÉYYYYYYYY...{/color}{/bt}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:285
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_7629ac97:

    # mc_t "{bt=5}{color=aee7ff}I don't want to go to wooooooork...{/color}{/bt}"
    mc_t "{bt=5}{color=aee7ff}Non voglio andare a wooooooork...{/color}{/bt}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:286
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_1dd9a20b:

    # mc "{act}sighs{/act}"
    mc "{act}sospira{/act}"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:287
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_95ab3255:

    # mc_t "Unfortunately, it's the only way to live in my own apartment. Basic income is not enough."
    mc_t "Sfortunatamente, è l'unico modo per vivere nel mio appartamento. Il reddito di base non basta."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:293
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_afc0568c:

    # mc_t "At least my glider is cool." with dis_std
    mc_t "Almeno il mio aliante è bello." with dis_std

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:294
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_a4fcfaff:

    # mc_t "I'd love to say it's mine, but it's a rental. This is the only thing my asshole boss was willing to pay for..."
    mc_t "Mi piacerebbe dire che è mio, ma è un noleggio. Questa è l'unica cosa per cui il mio stronzo capo era disposto a pagare..."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:295
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_2b6e7386:

    # mc_t "The first day I thought: is this thing even safe?"
    mc_t "Il primo giorno ho pensato: questa cosa è sicura?"

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:296
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_8c211e29:

    # mc_t "And yeah, it is. Nowadays almost everything is self-driving, so accidents are pretty rare."
    mc_t "E sì, lo è. Al giorno d’oggi quasi tutto si guida da soli, quindi gli incidenti sono piuttosto rari."

# game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/script.rpy:301
translate italian scene__book1__c1_awakening__e03_lonely_life__s01_my_little_place__end_scene_eb3510af:

    # mc "{act}heading to work{/act}" with dis_std_long
    mc "{act}vado al lavoro{/act}" with dis_std_long

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
