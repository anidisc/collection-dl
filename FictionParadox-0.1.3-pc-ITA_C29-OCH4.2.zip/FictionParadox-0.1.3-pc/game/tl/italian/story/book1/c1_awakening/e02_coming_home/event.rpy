﻿
translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/event.rpy:4
    old "Coming Home{#story-event}"
    new "Ritorno a casa{#story-event}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
