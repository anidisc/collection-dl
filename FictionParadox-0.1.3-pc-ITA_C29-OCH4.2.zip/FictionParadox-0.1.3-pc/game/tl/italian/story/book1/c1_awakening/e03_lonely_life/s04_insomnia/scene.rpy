﻿
translate italian strings:

    # game/story/book1/c1_awakening/e03_lonely_life/s04_insomnia/scene.rpy:6
    old "Insomnia{#story-scene}"
    new "Insonnia{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
