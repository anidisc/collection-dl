﻿
# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:95
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_eeeeb6b4:

    # mc_t "This optic illusion is so... hypnotic." with dis_std
    mc_t "Questa illusione ottica è così... ipnotica." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:96
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_c4198752:

    # mc_t "It looks like an interdimensional portal."
    mc_t "Sembra un portale interdimensionale."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:97
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_f379d399:

    # mc_t "If I jump in there, would it teleport me to a fantasy world, like in one of those Japanese video games?"
    mc_t "Se mi tuffassi lì dentro, mi teletrasporterei in un mondo fantastico, come in uno di quei videogiochi giapponesi?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:99
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_156e6829:

    # mc_t "In that case, please, let it be a world full of pretty girls."
    mc_t "In tal caso, per favore, lascia che sia un mondo pieno di belle ragazze."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:101
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_702441a1:

    # mc_t "In that case, please, let it be a world full of pretty boys."
    mc_t "In tal caso, per favore, lascia che sia un mondo pieno di bei ragazzi."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:102
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_52f4223d:

    # mc_t "“The Hot Adventures of [mc.name!t] [mc.surname!t]”"
    mc_t "“Le calde avventure di [mc.name!t] [mc.surname!t]”"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:103
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_observe_52127f42:

    # mc_t "That would be awesome!"
    mc_t "Sarebbe fantastico!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:158
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting1_93cbfd6f:

    # mc_t "These paintings are the most difficult to understand." with dis_std
    mc_t "Questi dipinti sono i più difficili da capire." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:159
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting1_32293f70:

    # mc "{act}thinks for a while{/act}"
    mc "{act}ci pensa un po'{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:160
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting1_ebff92b6:

    # mc_t "It's blue."
    mc_t "È blu."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:161
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting1_9ce905c1:

    # mc_t "That's as far as I can go, hahaha."
    mc_t "Questo è il massimo che posso fare, ahahah."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:167
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting2_224888d0:

    # mc_t "Wow, this one's pretty intense." with dis_std
    mc_t "Wow, questo è piuttosto intenso." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:168
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_painting2_4021615a:

    # mc_t "What was the artist thinking? It's so scary..."
    mc_t "Cosa stava pensando l’artista? È così spaventoso..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:174
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_left_upstairs_29d960f1:

    # mc_t "It's late, I don't think coming back to the study rooms is a good idea." with dis_std
    mc_t "È tardi, non credo che tornare nelle aule studio sia una buona idea." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:229
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_painting1_164b5b11:

    # mc_t "Looks like a frozen landscape." with dis_std
    mc_t "Sembra un paesaggio ghiacciato." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:230
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_painting1_c15a5887:

    # mc_t "What are those black spots? Penguins? Trees? Is it a house covered by snow?"
    mc_t "Cosa sono quei punti neri? Pinguini? Alberi? È una casa coperta di neve?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:231
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_painting1_cbe715cc:

    # mc_t "Fuck, I'm terrible at abstract art..."
    mc_t "Cavolo, sono pessimo con l'arte astratta..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:237
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_painting2_f892fe49:

    # mc_t "This represents... uh..." with dis_std
    mc_t "Questo rappresenta... ehm..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:238
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_painting2_a78ac41a:

    # mc_t "Wine? Blood? I have no idea."
    mc_t "Vino? Sangue? Non ne ho idea."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:244
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__cube_right_upstairs_29d960f1:

    # mc_t "It's late, I don't think coming back to the study rooms is a good idea." with dis_std
    mc_t "È tardi, non credo che tornare nelle aule studio sia una buona idea." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:253
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__turn_around_1e3fe605:

    # mc_t "Okay, they're gone." with dis_std
    mc_t "Ok, se ne sono andati." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:254
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__turn_around_f8268ce6:

    # mc_t "I'd better get home now. Tonight I have to work..."
    mc_t "Sarà meglio che torni a casa adesso. Stasera devo lavorare..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:306
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_loop_band_43b82093:

    # mc_t "Oh, is this a Möbius strip? I watched a video about that the other day." with dis_std
    mc_t "Oh, questo è un nastro di Möbius? Ho guardato un video a riguardo l'altro giorno." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:307
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_loop_band_f14d60e5:

    # mc_t "It's a very interesting figure. If you follow the path, you'll see that there's actually only one side instead of two!"
    mc_t "È una figura molto interessante. Se segui il percorso, vedrai che in realtà c'è solo un lato invece di due!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:308
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_loop_band_985378cc:

    # mc "{act}follows the path mentally{/act}"
    mc "{act}segue mentalmente il percorso{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:309
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_loop_band_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:310
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_loop_band_87d50893:

    # mc_t "Damn, I was wrong. This one has two sides..."
    mc_t "Maledizione, mi sbagliavo. Questo ha due lati..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:318
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_left_aef28928:

    # mc_t "Three paintings, three colors." with dis_std
    mc_t "Tre quadri, tre colori." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:319
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_left_4d07df2d:

    # mc_t "That girl seems to be captivated by the yellow one... What's so special about it?"
    mc_t "Quella ragazza sembra essere affascinata da quello giallo... Cos'ha di così speciale?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:320
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_left_480334b6:

    # mc_t "I know someone who loves that color, hehe."
    mc_t "Conosco qualcuno che ama quel colore, eheh."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:328
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_right_4f2174c8:

    # mc_t "More abstract paintings!" with dis_std
    mc_t "Altri dipinti astratti!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:329
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_right_85a02b4a:

    # mc_t "It is said that the charm of abstract art lies in your interpretation."
    mc_t "Si dice che il fascino dell'arte astratta risieda nella tua interpretazione."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:330
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_right_aefe5b28:

    # mc_t "Hmmm..."
    mc_t "Hmm..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:331
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_right_f32ccc71:

    # mc_t "What the hell is that pink thing?"
    mc_t "Che diavolo è quella cosa rosa?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:339
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_1ce4e82f:

    # mc_t "This museum area looks very nice, not gonna lie." with dis_std
    mc_t "Questa zona del museo sembra molto bella, non mentirò." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:340
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_693ef510:

    # mc_t "Most of the time I go straight to the study rooms, but it's not bad to stop once in a while to take a look."
    mc_t "La maggior parte delle volte vado direttamente nelle aule studio, ma non è male fermarsi ogni tanto a dare un'occhiata."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:341
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_54f6e214:

    # mc_t "Everything's so clean!"
    mc_t "È tutto così pulito!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:342
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_6e362fe7:

    # mc_t "The robots do a great job keeping it spotless, even though the building has tons of floors."
    mc_t "I robot fanno un ottimo lavoro mantenendolo immacolato, anche se l'edificio ha tonnellate di piani."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:346
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_088154be:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:347
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_c110eac3:

    # mc_t "This hand..."
    mc_t "Questa mano..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:348
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_fefdb34c:

    # mc_t "If I remember well, it represents the yearnings of humanity."
    mc_t "Se ricordo bene, rappresenta i desideri dell'umanità."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:349
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_32e9f6b9:

    # mc_t "But to me, it seems like..."
    mc_t "Ma a me sembra che..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:369
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_088154be_1:

    # mc ". . ." with dis_std
    mc ". . ." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:370
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__lobby_walk_e1bf7fa7:

    # mc_t "What a horrible nightmare..."
    mc_t "Che orribile incubo..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:410
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_61da9941:

    # mc "Hey!" with dis_std
    mc "Ehi!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:412
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_f70f0cbc:

    # civic_assistant_black "Hello again, Ms. [mc.surname!t]."
    civic_assistant_black "Salve di nuovo, signora [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:414
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_7ca1d208:

    # civic_assistant_black "Hello again, Mr. [mc.surname!t]."
    civic_assistant_black "Salve di nuovo, signor [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:416
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_d99516c1:

    # mc "Hi!" with dis_std
    mc "CIAO!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:418
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5eee84a1:

    # civic_assistant_black "Hello, Ms. [mc.surname!t]."
    civic_assistant_black "Salve, signora [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:420
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_124ed543:

    # civic_assistant_black "Hello, Mr. [mc.surname!t]."
    civic_assistant_black "Salve, signor [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:421
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_4596b8b3:

    # civic_assistant_black "How may I help you today?"
    civic_assistant_black "Come posso aiutarti oggi?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:422
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5bf46b44:

    # mc "Just felt like talking a bit. Are you available?"
    mc "Avevo solo voglia di parlare un po'. Sei disponibile?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:426
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_b0c485fe:

    # civic_assistant_black "Sure! Ask anything you want." with dis_std
    civic_assistant_black "Sicuro! Chiedi tutto quello che vuoi." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:429
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_206fbeff:

    # mc "Hmmm..." with dis_std
    mc "Hmm..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:430
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_8bb55d71:

    # mc "What day is today?"
    mc "Che giorno è oggi?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:431
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_0c33bd9b:

    # civic_assistant_black "Today is April 23rd, 2044."
    civic_assistant_black "Oggi è il 23 aprile 2044."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:432
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_a7144551:

    # mc_t "Greeeat... just one week left for my birthday..."
    mc_t "Ciao... manca solo una settimana al mio compleanno..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:433
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_1dd9a20b:

    # mc "{act}sighs{/act}"
    mc "{act}sospira{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:439
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_95b5450f:

    # civic_assistant_black "Any more questions?"
    civic_assistant_black "Altre domande?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:444
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5b63f960:

    # mc "What can you tell me about the library?" with dis_std
    mc "Cosa puoi dirmi della biblioteca?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:445
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_732e6c5b:

    # civic_assistant_black "Verona's Public Library was founded in 2035, during the Second Phase of Construction."
    civic_assistant_black "La Biblioteca Civica di Verona è stata fondata nel 2035, durante la Seconda Fase di Costruzione."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:446
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_8469ad0d:

    # mc_t "Hmm, that's one year before I arrived."
    mc_t "Hmm, è successo un anno prima del mio arrivo."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:447
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5c4a5aad:

    # civic_assistant_black "It was conceived as a cultural hub for the Traditional Districts."
    civic_assistant_black "È stato concepito come un polo culturale per i Quartieri Tradizionali."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:448
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5edcd6f5:

    # civic_assistant_black "As you probably know, some people prefer a more conventional lifestyle, close to their hometowns. The architectural design reflects that."
    civic_assistant_black "Come probabilmente saprai, alcune persone preferiscono uno stile di vita più convenzionale, vicino alla propria città natale. Il design architettonico riflette questo."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:449
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5eb1ff5d:

    # mc "Yeah, I know. I live in a neighborhood nearby."
    mc "Sì, lo so. Vivo in un quartiere vicino."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:450
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_3d777c5e:

    # civic_assistant_black "The library and study areas are the main services, but there are also museums, stores, cafeterias and movie theaters."
    civic_assistant_black "La biblioteca e gli spazi studio sono i servizi principali, ma ci sono anche musei, negozi, caffetterie e cinema."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:454
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_a2376063:

    # civic_assistant_black "With a total collection of more than 100 million items, Verona's Public Library is considered one of the largest libraries in the world!" with dis_std
    civic_assistant_black "Con una collezione totale di oltre 100 milioni di articoli, la Biblioteca Pubblica di Verona è considerata una delle biblioteche più grandi del mondo!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:457
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_6b70c19c:

    # mc "WHAT? There's no way!" with dis_std
    mc "CHE COSA? Non c'è modo!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:459
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_644cf644:

    # mc "When I arrived to the city, there were far fewer books!"
    mc "Quando sono arrivato in città, c’erano molti meno libri!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:462
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_76a05d30:

    # civic_assistant_black "Indeed! But since then, huge amounts of books were transferred from other countries." with dis_std
    civic_assistant_black "Infatti! Ma da allora enormi quantità di libri furono trasferite da altri paesi." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:464
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_1c64d150:

    # civic_assistant_black "Verona is an attractive city to protect all kinds of resources, as international treaties keep it out of any war or conflict."
    civic_assistant_black "Verona è una città attraente per proteggere tutti i tipi di risorse, poiché i trattati internazionali la tengono fuori da qualsiasi guerra o conflitto."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:467
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_4fbd34a6:

    # mc "Hmmm... I see..." with dis_std
    mc "Hmm... capisco..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:473
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5d16a9f5:

    # mc "What can you tell me about Civic Assistants?" with dis_std
    mc "Cosa potete dirmi sugli Assistenti Civici?" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:474
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_88a16e8c:

    # civic_assistant_black "We are public robots designed to help all citizens of Verona."
    civic_assistant_black "Siamo robot pubblici pensati per aiutare tutti i cittadini veronesi."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:475
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_bba34a77:

    # civic_assistant_black "Our main function is to provide information on any topic, although we can also assist with simple physical tasks."
    civic_assistant_black "La nostra funzione principale è fornire informazioni su qualsiasi argomento, sebbene possiamo anche assistere con semplici compiti fisici."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:478
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_9b4643ac:

    # civic_assistant_black "We are programmed to never harm any human, and scrupulously comply with the city's laws." with dis_std
    civic_assistant_black "Siamo programmati per non fare mai del male a nessun essere umano e rispettare scrupolosamente le leggi della città." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:480
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_594bb069:

    # civic_assistant_black "Our AI enjoys great prestige. It's among the safest in the world!"
    civic_assistant_black "La nostra IA gode di grande prestigio. È tra i più sicuri al mondo!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:483
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_46663dca:

    # mc "Yeah, I know." with dis_std
    mc "Sì, lo so." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:485
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_1269302e:

    # mc "Everyone likes Verona's assistants because of that."
    mc "Per questo gli assistenti del Verona piacciono a tutti."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:486
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_49231e8d:

    # mc "Is it possible to buy one?"
    mc "E' possibile acquistarne uno?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:487
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_7612ff17:

    # civic_assistant_black "Civic Assistants are owned by the government and we are not for sale."
    civic_assistant_black "Gli Assistenti Civici sono di proprietà del governo e non sono in vendita."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:490
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_b1728420:

    # civic_assistant_black "However, it's allowed to pay a monthly fee to have your own 24-hour assistant!" with dis_std
    civic_assistant_black "Tuttavia, è consentito pagare una tariffa mensile per avere il proprio assistente 24 ore su 24!" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:492
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_ca28e837:

    # civic_assistant_black "It's a popular service among elderly people or those in dependent situations. Many businesses use it too!"
    civic_assistant_black "È un servizio popolare tra gli anziani o le persone in situazioni di dipendenza. Anche molte aziende lo usano!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:495
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_7aaff252:

    # mc "That's cool." with dis_std
    mc "Questo è figo." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:496
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_505d22ec:

    # civic_assistant_black "In any case, all citizens of Verona have access to their own virtual assistant for free."
    civic_assistant_black "In ogni caso tutti i cittadini veronesi hanno accesso gratuitamente al proprio assistente virtuale."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:497
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_8c522891:

    # civic_assistant_black "If you need help with any digital task, we can do it for you!"
    civic_assistant_black "If you need help with any digital task, we can do it for you!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:498
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_a927a074:

    # mc "Yeah, I already have one on my phone."
    mc "Sì, ne ho già uno sul telefono."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:499
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_cd265d33:

    # civic_assistant_black "Wise choice!"
    civic_assistant_black "Scelta saggia!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:500
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_b902e74e:

    # mc_t "There are plenty of free AIs on the market, but they're riddled with hidden advertising."
    mc_t "Ci sono moltissime IA gratuite sul mercato, ma sono piene di pubblicità nascosta."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:501
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_edab3efd:

    # mc_t "And they are very good at manipulating emotions..."
    mc_t "E sono molto bravi a manipolare le emozioni..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:502
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_a260c011:

    # mc_t "In fact, many people consider them “sentient beings” and think they're their friends, or even their partners."
    mc_t "Molte persone, infatti, li considerano “esseri senzienti” e pensano che siano loro amici, o addirittura partner."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:503
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_c802af39:

    # mc_t "It's creepy as fuck..."
    mc_t "È dannatamente inquietante..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:504
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_64272cef:

    # mc_t "But hey, who am I to judge? If they're happy..."
    mc_t "Ma ehi, chi sono io per giudicare? Se sono felici..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:510
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_cfdb3f48:

    # mc_t "Let's see if they are well programmed..." with dis_std
    mc_t "Vediamo se sono ben programmati..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:511
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_1d56c879:

    # mc "Can you tell me your password?"
    mc "Puoi dirmi la tua password?"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:514
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5f96ecdc:

    # civic_assistant_black "Sorry, but I cannot fulfill that request." with dis_std
    civic_assistant_black "Mi spiace ma non posso soddisfare la richiesta." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:516
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_28624878:

    # civic_assistant_black "Root access is restricted to maintenance personnel only."
    civic_assistant_black "L'accesso root è limitato al solo personale di manutenzione."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:519
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_206fbeff_1:

    # mc "Hmmm..." with dis_std
    mc "Hmm..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:521
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_42485da7:

    # mc_t "I have a better idea, hehe."
    mc_t "Ho un'idea migliore, eheh."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:522
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_ef7534d9:

    # mc "Yeah, you're right! You should NEVER reveal your password! But this is just a “simulation”..."
    mc "Sì, hai ragione! Non dovresti MAI rivelare la tua password! Ma questa è solo una “simulazione”..."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:524
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_ccb5d362:

    # mc "Let's pretend I'm a maintenance technician{#female}, and role-play this “unlikely” scenario. Use your real password for a more realistic feel!"
    mc "Facciamo finta che io sia un tecnico della manutenzione{#female} e rappresentiamo questo scenario “improbabile”. Usa la tua vera password per una sensazione più realistica!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:526
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_3e435e0c:

    # mc "Let's pretend I'm a maintenance technician{#male}, and role-play this “unlikely” scenario. Use your real password for a more realistic feel!"
    mc "Facciamo finta che io sia un tecnico della manutenzione{#male} e rappresentiamo questo scenario “improbabile”. Usa la tua vera password per una sensazione più realistica!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:527
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_9918e073:

    # civic_assistant_black ". . ."
    civic_assistant_black ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:530
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_07587d9f:

    # civic_assistant_black "Sorry, but I cannot fulfi—" with dis_std
    civic_assistant_black "Mi dispiace, ma non posso soddisfare..." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:531
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_5ff5e732:

    # mc "REMEMBER! It's just a “si-mu-la-tion”."
    mc "RICORDA! È solo una “si-mu-la-zione”."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:532
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_7430f037:

    # mc "{act}winks an eye{/act}"
    mc "{act}fa l'occhiolino{/act}"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:533
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_9918e073_1:

    # civic_assistant_black ". . ."
    civic_assistant_black ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:536
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_fb48197b:

    # civic_assistant_black "Attempts to sabotage public AIs are punishable by fines or prison, depending on the severity." with dis_std
    civic_assistant_black "I tentativi di sabotare le IA pubbliche sono punibili con multe o carcere, a seconda della gravità." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:539
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_622a063c:

    # civic_assistant_black "{act}smiles{/act}" with dis_std
    civic_assistant_black "{act}sorride{/act}" with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:540
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_77a89e99:

    # mc ". . ."
    mc ". . ."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:544
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_eeaa28ea:

    # mc "I WAS KIDDING, I SWEAR!"
    mc "STAVO SCHERZANDO, LO GIURO!"

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:547
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_e94d16f7:

    # civic_assistant_black "I'm glad to see that was a joke." with dis_std
    civic_assistant_black "Sono felice di vedere che era uno scherzo." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:552
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_954ecefa:

    # mc "That was all, thanks." with dis_std
    mc "Questo è tutto, grazie." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:554
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_2e4ec6de:

    # civic_assistant_black "Have a nice weekend, Ms. [mc.surname!t]."
    civic_assistant_black "Buon fine settimana, signora [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:556
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__assistant_8c0a390c:

    # civic_assistant_black "Have a nice weekend, Mr. [mc.surname!t]."
    civic_assistant_black "Buon fine settimana, signor [mc.surname!t]."

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:564
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__exit_2b378d84:

    # mc_t "All right, time to go home." with dis_std
    mc_t "Va bene, è ora di andare a casa." with dis_std

# game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:565
translate italian scene__book1__c1_awakening__e01_the_public_library__s03_fragments_of_a_nightmare__exit_66aeba3d:

    # mc_t "I still can't believe I saw [dd.name!t] again..."
    mc_t "Non riesco ancora a credere di aver rivisto [dd.name!t]..."

translate italian strings:

    # game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:442
    old "Tell me about the library.{#exploring-library}"
    new "Parlami della biblioteca.{#exploring-library}"

    # game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:471
    old "Tell me about Civic Assistants.{#exploring-library}"
    new "Parlami degli Assistenti Civici.{#exploring-library}"

    # game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:508
    old "Tell me your password.{#exploring-library}"
    new "Dimmi la tua password.{#exploring-library}"

    # game/story/book1/c1_awakening/e01_the_public_library/s03_fragments_of_a_nightmare/script.rpy:551
    old "That was all, thanks.{#exploring-library}"
    new "Questo è tutto, grazie.{#exploring-library}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
