﻿
translate italian strings:

    # game/story/book1/c1_awakening/e02_coming_home/s02_false_hope/scene.rpy:6
    old "False Hope{#story-scene}"
    new "Falsa speranza{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
