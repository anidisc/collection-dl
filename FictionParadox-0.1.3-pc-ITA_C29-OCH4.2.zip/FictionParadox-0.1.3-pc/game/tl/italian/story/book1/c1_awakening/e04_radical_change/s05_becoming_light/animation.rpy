﻿
translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:231
    old "Thorough clean, no excuses.{#chapter1-becoming-light}"
    new "Pulito a fondo, senza scuse.{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:234
    old "From now on, health comes first!{#chapter1-becoming-light}"
    new "D'ora in poi la salute viene prima di tutto!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:242
    old "Fuck, there's math everywhere...{#chapter1-becoming-light}"
    new "Cavolo, c'è matematica ovunque...{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:245
    old "Where do I start?{#chapter1-becoming-light}"
    new "Da dove comincio?{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:253
    old "This is exhausting...{#chapter1-becoming-light}"
    new "È estenuante...{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:256
    old "I need to gain weight...{#chapter1-becoming-light}"
    new "Ho bisogno di aumentare di peso...{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:264
    old "Okay, I think I got it.{#chapter1-becoming-light}"
    new "Ok, penso di aver capito.{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:267
    old "Thank god we have the Internet.{#chapter1-becoming-light}"
    new "Grazie a Dio abbiamo Internet.{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:275
    old "Writing is a wonderful invention!{#chapter1-becoming-light}"
    new "La scrittura è un'invenzione meravigliosa!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:278
    old "I can learn from the best scientists!{#chapter1-becoming-light}"
    new "Posso imparare dai migliori scienziati!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:286
    old "No matter how hard it is...{#chapter1-becoming-light}"
    new "Non importa quanto sia difficile...{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:289
    old "I'll keep moving forward!{#chapter1-becoming-light}"
    new "Continuerò ad andare avanti!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:302
    old "Coding feels like magic!{#chapter1-becoming-light}"
    new "La codifica è una magia!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:305
    old "I can make any idea come true!{#chapter1-becoming-light}"
    new "Posso realizzare qualsiasi idea!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:379
    old "I've never felt so alive{#female}!{#chapter1-becoming-light}"
    new "Non mi sono mai sentito così vivo{#female}!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:382
    old "My new self{#female} is taking shape!{#chapter1-becoming-light}"
    new "Il mio nuovo io{#female} sta prendendo forma!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:390
    old "I will defeat nature...{#chapter1-becoming-light}"
    new "Sconfiggerò la natura...{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:393
    old "...with the power of science.{#chapter1-becoming-light}"
    new "...con il potere della scienza.{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:721
    old "I've never felt so alive{#male}!{#chapter1-becoming-light}"
    new "Non mi sono mai sentito così vivo{#male}!{#chapter1-becoming-light}"

    # game/story/book1/c1_awakening/e04_radical_change/s05_becoming_light/animation.rpy:724
    old "My new self{#male} is taking shape!{#chapter1-becoming-light}"
    new "Il mio nuovo io{#male} sta prendendo forma!{#chapter1-becoming-light}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
