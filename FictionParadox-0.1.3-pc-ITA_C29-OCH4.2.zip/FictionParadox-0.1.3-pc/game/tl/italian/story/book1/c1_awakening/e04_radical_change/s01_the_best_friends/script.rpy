﻿
# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:27
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_af005811:

    # dd "{act}humming{/act}" with dis_std
    dd "{act}canticchiare{/act}" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:31
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_114701bd:

    # dd "{act}walking calmly{/act}" with dis_std_med
    dd "{act}camminare con calma{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:34
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_368f31de:

    # dd_t "What a beautiful morning..." with dis_std_med
    dd_t "Che bella mattinata..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:35
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_075e34f9:

    # dd_t "Verona's streets are so pretty in autumn! I think this one in the French district is one of my favorites."
    dd_t "Le strade di Verona sono così belle in autunno! Penso che questo nel quartiere francese sia uno dei miei preferiti."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:36
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_94f451ba:

    # dd_t "The fallen leaves, the sunrise, the quietness..."
    dd_t "Le foglie cadute, l'alba, la quiete..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:37
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_bbb77df3:

    # dd_t "I love it!"
    dd_t "Lo adoro!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:41
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_44f69e1c:

    # unknown "{act}runs towards her{/act}"
    unknown "{act}corre verso di lei{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:43
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7922300d:

    # unknown "{act}runs towards him{/act}"
    unknown "{act}corre verso di lui{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:49
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_75f09411:

    # ll "{act}hugging her{/act} [dd.name!t]~!"
    ll "{act}abbracciandola{/act} [dd.name!t]~!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:51
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e25aed35:

    # ll "{act}hugging him{/act} [dd.name!t]~!"
    ll "{act}abbracciandolo{/act} [dd.name!t]~!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:54
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e9070bc2:

    # dd "Hi [ll.name!t]!"
    dd "Ciao [ll.name!t]!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:57
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7c3c306e:

    # ll "I missed you..."
    ll "mi sei mancato..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:60
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_5cef2d94:

    # dd "Me too! I couldn't wait to see you again!"
    dd "Anche io! Non vedevo l'ora di rivederti!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:63
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_a37dbf4d:

    # dd "Whoa, your hair's gotten so long!" with dis_std_med
    dd "Whoa, i tuoi capelli sono diventati così lunghi!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:64
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ed7066c1:

    # dd "I like it!"
    dd "Mi piace!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:67
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_0b3a1a8c:

    # ll "Thanks! It's the first time I've let it grow this much."
    ll "Grazie! È la prima volta che lo lascio crescere così tanto."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:69
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_70621578:

    # ll "But I think I still prefer it short. It's just easier, though I've gotten used to training with braids, hehe."
    ll "Ma penso che lo preferisco ancora corto. È semplicemente più semplice, anche se mi sono abituata ad allenarmi con le trecce, eheh."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:71
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_11db0642:

    # ll "But I think I prefer it even longer, so I'll just wait until I find the proper length, hehe."
    ll "Ma penso che lo preferisco ancora più lungo, quindi aspetterò finché non troverò la lunghezza giusta, eheh."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:72
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_32ce9203:

    # ll "I'm trying to improve my style!"
    ll "Sto cercando di migliorare il mio stile!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:75
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_435681a9:

    # dd "{act}laughing{/act} Improve?"
    dd "{act}ride{/act} Migliorare?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:76
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_73463b44:

    # dd "No matter what hairstyle or clothing you wear, [ll.name!t]. You always look super cool!"
    dd "Non importa quale acconciatura o abbigliamento indossi, [ll.name!t]. Sei sempre super cool!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:80
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_47f2934d:

    # ll "Nah, I'm not as charming{#female} as you."
    ll "No, non sono affascinante{#female} come te."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:82
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_c7d31ddb:

    # ll "Nah, I'm not as charming{#male} as you."
    ll "No, non sono affascinante{#male} come te."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:86
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_8452c592:

    # ll "By the way, you look adorable{#female} in that outfit!" with dis_std_med
    ll "A proposito, sei adorabile{#female} con quel vestito!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:88
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_accf47ef:

    # ll "By the way, you look adorable{#male} in that outfit!" with dis_std_med
    ll "A proposito, sei adorabile{#male} con quel vestito!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:91
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_8a56c65c:

    # dd "T-Thanks!"
    dd "T-Grazie!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:95
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_368cb526:

    # ll "{act}inspecting her{/act} Hmmm..."
    ll "{act}la sto ispezionando{/act} Hmmm..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:97
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_476fad0d:

    # ll "{act}inspecting him{/act} Hmmm..."
    ll "{act}lo ispeziona{/act} Hmmm..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:99
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_05365249:

    # ll "Guess I'm not the only{#female} one who's changed."
    ll "Immagino di non essere l'unico{#female} ad essere cambiato."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:101
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ae895d17:

    # ll "Guess I'm not the only{#male} one who's changed."
    ll "Immagino di non essere l'unico{#male} ad essere cambiato."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:104
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_2792514f:

    # dd "W-What makes you say that?"
    dd "C-cosa te lo fa dire?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:107
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e8dffd7d:

    # ll "Something has definitely changed in you!"
    ll "Qualcosa è decisamente cambiato in te!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:109
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1b4b0cbc:

    # ll "I mean, you look gorgeous{#female}, as always. But I sense you're a little... withdrawn{#female}."
    ll "Voglio dire, sei stupenda{#female}, come sempre. Ma ho la sensazione che tu sia un po'... riservato{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:111
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_6d88da25:

    # ll "I mean, you look handsome{#male}, as always. But I sense you're a little... withdrawn{#female}."
    ll "Voglio dire, sei bellissimo{#male}, come sempre. Ma ho la sensazione che tu sia un po'... riservato{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:112
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9607f65e:

    # ll "Did something happen?"
    ll "È successo qualcosa?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:115
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f807344b:

    # dd "Nothing important."
    dd "Niente di importante."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:118
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_69236a28:

    # ll "Hmmmm..."
    ll "Hmmmm..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:121
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1f138ae4:

    # ll "Okay, we can discuss that later." with dis_std_med
    ll "Ok, ne possiamo discutere più tardi." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:122
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ba97efb9:

    # ll "Shall we go to the café?"
    ll "Andiamo al bar?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:125
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_af03b6b1:

    # dd "Yeah!"
    dd "Sì!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:130
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e02ab6a9:

    # dd "...so in the end, I graduated with honors." with dis_std_med
    dd "...quindi alla fine mi sono laureato con lode." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:131
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_79801fcf:

    # dd "Now that I've finished a master's degree abroad, I meet all the requirements to start my PhD in Verona."
    dd "Ora che ho concluso un master all'estero, ho tutti i requisiti per iniziare il dottorato a Verona."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:134
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_cc326bbb:

    # ll "Wow, they're pretty demanding."
    ll "Wow, sono piuttosto esigenti."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:137
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_0959fddd:

    # ll "But that's great, right? Now there's nothing stopping you from staying here!" with dis_std
    ll "Ma è fantastico, vero? Ora non c'è niente che ti impedisca di restare qui!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:138
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_dceae538:

    # ll "We'll get to see each other every week!"
    ll "Ci vedremo ogni settimana!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:141
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_6ff325c3:

    # dd "Well, about that..."
    dd "Beh, a questo proposito..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:144
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_66f09b97:

    # ll "What?"
    ll "Che cosa?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:149
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f3d49526:

    # dd "[oo.name!t] got a little upset when he found out we were having breakfast together{#female}..."
    dd "[oo.name!t] si è arrabbiato un po' quando ha scoperto che stavamo facendo colazione insieme{#female}..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:151
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_c3b6c769:

    # dd "[oo.name!t] got a little upset when she found out we were having breakfast together{#male}..."
    dd "[oo.name!t] si è arrabbiata un po' quando ha scoperto che stavamo facendo colazione insieme{#male}..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:153
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_df4a3d5d:

    # dd "[oo.name!t] got a little upset when he found out we were having breakfast together{#both-genders}..."
    dd "[oo.name!t] si è arrabbiato un po' quando ha scoperto che stavamo facendo colazione insieme{#both-genders}..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:155
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_4a1a3d6f:

    # dd "[oo.name!t] got a little upset when she found out we were having breakfast together{#both-genders}..."
    dd "[oo.name!t] si è arrabbiata un po' quando ha scoperto che stavamo facendo colazione insieme{#both-genders}..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:158
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1ad52796:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:161
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_2f75c1fa:

    # ll "Seriously?"
    ll "Sul serio?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:165
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7beb9f04:

    # ll "No wonder you were acting weird{#female} earlier..." with dis_std_med
    ll "Non c'è da stupirsi che ti comportassi in modo strano{#female} prima..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:167
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_aded76ed:

    # ll "No wonder you were acting weird{#male} earlier..." with dis_std_med
    ll "Non c'è da stupirsi che ti comportassi in modo strano{#male} prima..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:168
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_3b5dc8d7:

    # ll "And where the fuck is the problem, anyway? We haven't seen each other in a whole year!"
    ll "E comunque, dov'è il problema? Non ci vediamo da un anno intero!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:172
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ce7bec08:

    # dd "He says the high school days are over, and that I'm an adult woman now. He doesn't think it's “loyal” to meet with you alone..."
    dd "Dice che i tempi del liceo sono finiti e che ora sono una donna adulta. Non pensa che sia “leale” incontrarti da solo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:174
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_42c179b1:

    # dd "She says the high school days are over, and that I'm an adult man now. She doesn't think it's “loyal” to meet with you alone..."
    dd "Dice che i giorni del liceo sono finiti e che ora sono un uomo adulto. Non pensa che sia “leale” incontrarti da sola..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:177
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f2bb2b60:

    # ll "I don't get it."
    ll "Non capisco."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:181
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9b7f6c66:

    # dd "Well, he knows you're my best friend{#male}, and since you're a guy... he feels a bit insecure{#male}."
    dd "Beh, sa che sei il mio migliore amico{#male} e, dato che sei un ragazzo... si sente un po' insicuro{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:183
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_497df2f7:

    # dd "Well, she knows you're my best friend{#female}, and since you're a girl... she feels a bit insecure{#female}."
    dd "Beh, sa che sei la mia migliore amica{#female} e, dato che sei una ragazza... si sente un po' insicura{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:185
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f7d4793c:

    # dd "Well, he knows you're my best friend{#female}, and since you're bisexual... he feels a bit insecure{#male}."
    dd "Beh, sa che sei il mio migliore amico{#female} e, dato che sei bisessuale... si sente un po' insicuro{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:187
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9c7badf7:

    # dd "Well, she knows you're my best friend{#male}, and since you're bisexual... she feels a bit insecure{#female}."
    dd "Beh, sa che sei la mia migliore amica{#male} e, dato che sei bisessuale... si sente un po' insicura{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:190
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_364a8e36:

    # ll "For fuck's sake..."
    ll "Per l'amor del cielo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:193
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_532efffa:

    # ll "It's not like I'm gonna eat your pussy in the middle of the café!"
    ll "Non è che ti mangerò la figa in mezzo al bar!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:195
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_4f1db793:

    # ll "It's not like I'm gonna suck your dick in the middle of the café!"
    ll "Non è che ti succhierò il cazzo in mezzo al bar!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:197
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_b7fea6b5:

    # ll "It's not like I'm gonna kiss you in the middle of the café!"
    ll "Non è che ti bacerò in mezzo al bar!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:201
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_b84a8e91:

    # dd_t "She's so rude when she gets angry..."
    dd_t "È così scortese quando si arrabbia..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:203
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_969e722c:

    # dd_t "He's so rude when he gets angry..."
    dd_t "È così scortese quando si arrabbia..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:207
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ceebeb31:

    # dd "I think it's because of the podcasts she's been listening to, so I guess it'll pass." with dis_std
    dd "Penso che sia a causa dei podcast che sta ascoltando, quindi immagino che passerà." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:209
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_4d3d7471:

    # dd "I think it's because of the podcasts he's been listening to, so I guess it'll pass." with dis_std
    dd "Penso che sia a causa dei podcast che sta ascoltando, quindi immagino che passerà." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:210
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_0056e59e:

    # dd "How about you? Are you seeing anyone?"
    dd "E tu? Ti vedi con qualcuno?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:213
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_db9333bf:

    # ll "Nah, not really."
    ll "No, non proprio."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:214
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_42319a2c:

    # ll "I'm at a point where I just don't care about that anymore."
    ll "Sono a un punto in cui non mi interessa più questa cosa."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:217
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_825c55fb:

    # dd "But working at a gym you must know a lot of people, right?"
    dd "Ma lavorando in palestra devi conoscere molte persone, giusto?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:220
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_833485dc:

    # ll "Yeah, but I haven't met anyone I actually like."
    ll "Sì, ma non ho incontrato nessuno che mi piaccia davvero."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:221
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_270fab78:

    # ll "I don't care about looks, and most of the people who come up to me only care about my body..."
    ll "Non mi interessa l'aspetto fisico e alla maggior parte delle persone che vengono da me interessa solo il mio corpo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:222
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_87805401:

    # ll "I don't want someone who just keeps me company. I want a relationship with meaning, that makes me feel like I'm fighting for something, you know?"
    ll "Non voglio qualcuno che mi tenga solo compagnia. Voglio una relazione con un significato, che mi faccia sentire come se stessi lottando per qualcosa, sai?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:225
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_00ba69ea:

    # dd "Yeah, I think I get what you mean."
    dd "Sì, penso di capire cosa intendi."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:226
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e7a12597:

    # dd "Still, it's hard to believe there's no one out there for you. Don't you think you're closing yourself off a bit?"
    dd "Eppure, è difficile credere che non ci sia nessuno là fuori per te. Non pensi di chiuderti un po'?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:229
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7848d418:

    # ll "What do you mean?"
    ll "Cosa intendi?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:232
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_400062a8:

    # dd "Well, ever since we finished high school, all you've done is training and training. Which is great, [ll.name!t]!"
    dd "Beh, da quando abbiamo finito il liceo, non hai fatto altro che allenarti e allenarti. Che è fantastico, [ll.name!t]!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:233
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_d616ab28:

    # dd "But if you turn down everyone who tries to get close to you, you'll never find anyone."
    dd "Ma se rifiuti tutti quelli che cercano di avvicinarsi a te, non troverai mai nessuno."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:237
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f0a0e859:

    # ll "I train because I want to be strong{#female}!"
    ll "Mi alleno perché voglio essere forte{#female}!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:238
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_6888aac3:

    # ll "That way, if I ever need to protect someone, I'll be ready{#female}."
    ll "In questo modo, se mai avrò bisogno di proteggere qualcuno, sarò pronto{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:240
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ac17d2ff:

    # ll "I train because I want to be strong{#male}!"
    ll "Mi alleno perché voglio essere forte{#male}!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:241
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_03930ffb:

    # ll "That way, if I ever need to protect someone, I'll be ready{#male}."
    ll "In questo modo, se mai avrò bisogno di proteggere qualcuno, sarò pronto{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:244
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_5c386f39:

    # ll "Though I still haven't met anyone who deserves it..." with dis_std
    ll "Anche se non ho ancora incontrato nessuno che se lo meriti..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:245
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7f00d73d:

    # ll "Guess I'm out of luck when it comes to love."
    ll "Immagino di essere sfortunato quando si tratta di amore."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:248
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_88b1a29e:

    # dd "You and everyone else, [ll.name!t]."
    dd "Tu e tutti gli altri, [ll.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:251
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_4bbaa172:

    # dd "That kind of thing only happens in movies..." with dis_std_med
    dd "Queste cose succedono solo nei film..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:254
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_8076154f:

    # ll "Nah, I don't think so."
    ll "No, non credo."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:255
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_8c849f8b:

    # ll "It's all about being patient and being in the right place at the right time. At least, that's how I see it!"
    ll "L'importante è essere pazienti e trovarsi nel posto giusto al momento giusto. Almeno, questo è come la vedo io!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:258
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_46f23ae6:

    # dd_t "Love...?" with dis_std_med
    dd_t "Amore...?" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:259
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_29cbc9fb:

    # dd_t "I've always wondered what that must feel like..."
    dd_t "Mi sono sempre chiesto come deve essere..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:262
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_23d20203:

    # dd_t "[oo.name!t] is the only serious boyfriend I've ever had. We've been together for a few years now, and well... despite having his flaws, he's not a bad person."
    dd_t "[oo.name!t] è l'unico ragazzo serio che abbia mai avuto. Stiamo insieme ormai da qualche anno e beh... nonostante abbia i suoi difetti, non è una persona cattiva."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:263
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_b78a40e2:

    # dd_t "I feel like I bring a lot of good things into his life. Besides, I love helping and taking care of people!"
    dd_t "Sento di portare molte cose buone nella sua vita. Inoltre, amo aiutare e prendermi cura delle persone!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:264
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_af596b71:

    # dd_t "But it's obvious there's no real love in our relationship, he only wants me for my body..."
    dd_t "Ma è ovvio che non c'è vero amore nella nostra relazione, lui mi vuole solo per il mio corpo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:265
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1b4e6d31:

    # dd_t "We met at a party, he asked me out right away, and I said yes just to have a boyfriend. Since then it's been pretty standard, nothing special."
    dd_t "Ci siamo conosciuti ad una festa, mi ha chiesto subito di uscire e io ho detto di sì pur di avere un fidanzato. Da allora è stato abbastanza standard, niente di speciale."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:267
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1a225009:

    # dd_t "[oo.name!t] is the only serious girlfriend I've ever had. We've been together for a few years now, and well... despite having her flaws, she's not a bad person..."
    dd_t "[oo.name!t] è l'unica ragazza seria che abbia mai avuto. Stiamo insieme ormai da qualche anno e beh... nonostante abbia i suoi difetti, non è una persona cattiva..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:268
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_65dd223f:

    # dd_t "I feel like I bring a lot of good things into her life. Besides, I love helping and taking care of people!"
    dd_t "Sento di portare molte cose buone nella sua vita. Inoltre, amo aiutare e prendermi cura delle persone!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:269
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9d0b183f:

    # dd_t "But it's obvious there's no real love in our relationship, she only wants me for my body..."
    dd_t "Ma è ovvio che non c'è vero amore nella nostra relazione, lei mi vuole solo per il mio corpo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:270
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_e25ece9d:

    # dd_t "We met at a party, she asked me out right away, and I said yes just to have a girlfriend. Since then it's been pretty standard, nothing special."
    dd_t "Ci siamo conosciuti ad una festa, lei mi ha chiesto subito di uscire e io ho detto di sì pur di avere una ragazza. Da allora è stato abbastanza standard, niente di speciale."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:271
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_3a7c1087:

    # dd_t "I guess I'll never know what real love feels like..."
    dd_t "Immagino che non saprò mai cosa vuol dire il vero amore..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:272
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_8c7bfa8c:

    # ll "[dd.name!t]?"
    ll "[dd.name!t]?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:277
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ecaf5024:

    # dd "Y-Yes?"
    dd "S-Sì?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:280
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_3436bbbf:

    # ll "You okay?"
    ll "Stai bene?"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:283
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_337e8837:

    # dd "Of course!"
    dd "Ovviamente!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:286
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_69236a28_1:

    # ll "Hmmmm..."
    ll "Hmmmm..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:289
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_42941d5c:

    # ll "Bet it's something about [oo.name!t]..."
    ll "Scommetto che si tratta di [oo.name!t]..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:292
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_cf81c789:

    # dd "N-No, not at all! I just got distracted by the heart in the coffee, that's it."
    dd "N-No, per niente! Mi sono solo distratto dal cuore nel caffè, tutto qui."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:296
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f00297e8:

    # ll "That guy only keeps you around as decoration, [dd.name!t]."
    ll "Quel ragazzo ti tiene qui solo come decorazione, [dd.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:298
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_50f7b480:

    # ll "That girl only keeps you around as decoration, [dd.name!t]."
    ll "Quella ragazza ti tiene qui solo come decorazione, [dd.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:301
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_03797ae6:

    # ll "You deserve better! I've always told you that." with dis_std
    ll "Meriti di meglio! Te l'ho sempre detto." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:304
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_2f990534:

    # dd "Don't worry, I'm fine like I am."
    dd "Non preoccuparti, sto bene così come sono."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:307
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1ad52796_1:

    # ll ". . ."
    ll ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:310
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f99dca8c:

    # dd ". . ."
    dd ". . ."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:314
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_81c6dc14:

    # ll "{act}takes a sip{/act}"
    ll "{act}beve un sorso{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:317
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_ed3d6bb0:

    # dd "Changing the subject, yesterday I ran into [mc.name!t] at the library."
    dd "Cambiando argomento, ieri in biblioteca mi sono imbattuto in [mc.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:321
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_87d66800:

    # ll "Yeah, she told me..."
    ll "Sì, mi ha detto..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:322
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_c49963b7:

    # ll "I guess you saw what a mess she's become."
    ll "Immagino tu abbia visto che disastro è diventata."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:324
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1bbb30b9:

    # ll "Yeah, he told me..."
    ll "Sì, mi ha detto..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:325
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f01ae2b9:

    # ll "I guess you saw what a mess he's become."
    ll "Immagino tu abbia visto che disastro è diventato."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:329
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9258cfd3:

    # dd "I didn't realize she was doing that badly..."
    dd "Non avevo capito che stesse andando così male..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:330
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_bc60ba99:

    # dd "She's so thin!"
    dd "È così magra!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:332
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_a3d10e90:

    # dd "I didn't realize he was doing that badly..."
    dd "Non avevo capito che stesse facendo così male..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:333
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7810c7e7:

    # dd "He's so thin!"
    dd "È così magro!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:337
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_f74206a8:

    # ll "At this rate, she's going to ruin her life. She can't keep thinking like a kid{#female}!"
    ll "Di questo passo si rovinerà la vita. Non può continuare a pensare come una bambina{#female}!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:339
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_b2af4b9b:

    # ll "At this rate, he's going to ruin his life. He can't keep thinking like a kid{#male}!"
    ll "Di questo passo si rovinerà la vita. Non può continuare a pensare come un bambino{#male}!"

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:341
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_b15c4fd6:

    # ll "Always complaining about Verona and the world..."
    ll "Lamentarsi sempre di Verona e del mondo..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:344
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_c243e339:

    # ll "But doing nothing! Just empty words! It makes me sick{#female}, seriously..."
    ll "Ma non fare nulla! Solo parole vuote! Mi fa venire la nausea{#female}, sul serio..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:346
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_30677eb0:

    # ll "But doing nothing! Just empty words! It makes me sick{#male}, seriously..."
    ll "Ma non fare nulla! Solo parole vuote! Mi fa venire la nausea{#male}, sul serio..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:351
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_af5f2d8a:

    # dd "You're being too harsh{#female} on her, [ll.name!t]."
    dd "Sei troppo duro{#female} con lei, [ll.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:353
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_a88ba828:

    # dd "You're being too harsh{#male} on her, [ll.name!t]."
    dd "Sei troppo duro{#male} con lei, [ll.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:354
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_d8c41342:

    # dd "No one ends up like that on purpose... There must be something really painful eating away at her."
    dd "Nessuno finisce così di proposito... Deve esserci qualcosa di veramente doloroso che la divora."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:357
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_45b37187:

    # dd "You're being too harsh{#female} on him, [ll.name!t]."
    dd "Sei troppo duro con lui{#female}, [ll.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:359
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_7970f46a:

    # dd "You're being too harsh{#male} on him, [ll.name!t]."
    dd "Sei troppo duro{#male} con lui, [ll.name!t]."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:360
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_4d397d6d:

    # dd "No one ends up like that on purpose... There must be something really painful eating away at him."
    dd "Nessuno finisce così di proposito... Ci deve essere qualcosa di veramente doloroso che lo divora."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:363
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_d00f61cc:

    # ll "I know, I know..."
    ll "Lo so, lo so..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:365
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_1e225a02:

    # ll "It just frustrates me to see her like this, and... I don't know what to say."
    ll "È solo che mi frustra vederla così, e... non so cosa dire."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:367
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_065aa685:

    # ll "It just frustrates me to see him like this, and... I don't know what to say."
    ll "È solo che mi frustra vederlo così, e... non so cosa dire."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:371
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_670704c9:

    # dd "Well, I did everything I could to cheer her up..."
    dd "Beh, ho fatto tutto quello che potevo per tirarla su di morale..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:373
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_3179eff1:

    # dd "Well, I did everything I could to cheer him up..."
    dd "Beh, ho fatto tutto quello che potevo per tirarlo su di morale..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:377
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_d593b4ed:

    # ll "I know [mc.name!t] pretty well. She's the typical naive dreamer{#female}, and adult life must've hit her really hard..."
    ll "Conosco [mc.name!t] abbastanza bene. È la tipica sognatrice ingenua{#female}, e la vita adulta deve averla colpita davvero duramente..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:378
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9a3ca286:

    # ll "I think she needs a radical change."
    ll "Penso che abbia bisogno di un cambiamento radicale."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:380
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_21917fdb:

    # ll "I know [mc.name!t] pretty well. He's the typical naive dreamer{#male}, and adult life must've hit him really hard..."
    ll "Conosco [mc.name!t] abbastanza bene. È il tipico sognatore ingenuo{#male}, e la vita adulta deve averlo colpito duramente..."

# game/story/book1/c1_awakening/e04_radical_change/s01_the_best_friends/script.rpy:381
translate italian scene__book1__c1_awakening__e04_radical_change__s01_the_best_friends_9ce13db2:

    # ll "I think he needs a radical change."
    ll "Penso che abbia bisogno di un cambiamento radicale."

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
