﻿
# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:42
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_1217d078:

    # mc_t "Hnnngg..." with dis_std
    mc_t "Hnnngg..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:43
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_33193d91:

    # mc_t "Already daytime?"
    mc_t "Già giorno?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:48
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_65c1462b:

    # mc "{act}sitting on the edge{/act} {think}It's... 10:24 a.m.{/think}" with dis_std_med
    mc "{act}seduto sul bordo{/act} {think}Sono... le 10:24{/think}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:49
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_8752f3d2:

    # mc_t "Almost 6 hours of sleep? Wow, lucky me. First time in weeks!"
    mc_t "Quasi 6 ore di sonno? Wow, che fortuna. La prima volta da settimane!"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:50
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_32535c7b:

    # mc "{act}reading notifications{/act}"
    mc "{act}lettura notifiche{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:51
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_81106ab5:

    # mc_t "Okay, the order has arrived... I only have to pick it up."
    mc_t "Ok, l'ordine è arrivato... devo solo ritirarlo."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:54
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4b2d29ec:

    # phone "{act}notification{/act}"
    phone "{act}notifica{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:56
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_1b2569e2:

    # mc_t "Hmm?"
    mc_t "Ehm?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:57
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_c6ee65f1:

    # mc_t "A new post on [dd.name!t]'s profile?"
    mc_t "Un nuovo post sul profilo di [dd.name!t]?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:59
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_674be0ad:

    # mc_t "That's odd... I thought she no longer used this account."
    mc_t "È strano... pensavo che non utilizzasse più questo account."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:61
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_ad5fb0a6:

    # mc_t "That's odd... I thought he no longer used this account."
    mc_t "È strano... pensavo che non usasse più questo account."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:64
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_78e8d30a:

    # mc "{act}taps on the screen{/act}"
    mc "{act}tocchi sullo schermo{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:71
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_01f642b5:

    # mc_t "Ohhh, it's a selfie of her with [ll.name!t]!" with dis_std_long
    mc_t "Ohhh, è un suo selfie con [ll.name!t]!" with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:73
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_963eee42:

    # mc_t "Ohhh, it's a selfie of him with [ll.name!t]!" with dis_std_long
    mc_t "Ohhh, è un suo selfie con [ll.name!t]!" with dis_std_long

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:76
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4450aa0f:

    # mc_t "They look so pretty{#female}..."
    mc_t "Sono così carini{#female}..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:78
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_f59b54d0:

    # mc_t "They look so handsome{#male}..."
    mc_t "Sono così belli{#male}..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:80
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_8ba3ff74:

    # mc_t "They look so pretty{#both-genders}..."
    mc_t "Sono così carini{#both-genders}..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:83
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_1dd9862e:

    # mc_t "Hehe, [ll.name!t] seems like a completely different person. Where's the rude girl from yesterday?"
    mc_t "Eheh, [ll.name!t] sembra una persona completamente diversa. Dov'è la ragazza maleducata di ieri?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:85
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_2a519431:

    # mc_t "Hehe, [ll.name!t] seems like a completely different person. Where's the rude boy from yesterday?"
    mc_t "Eheh, [ll.name!t] sembra una persona completamente diversa. Dov'è il ragazzo maleducato di ieri?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:88
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_3b200895:

    # mc_t "Although I don't blame her. When [dd.name!t] is around, it's impossible not to be the best version of yourself{#female}."
    mc_t "Anche se non la biasimo. Quando [dd.name!t] è in giro, è impossibile non essere la versione migliore di te stesso{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:90
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4d76d09c:

    # mc_t "Although I don't blame her. When [dd.name!t] is around, it's impossible not to be the best version of yourself{#male}."
    mc_t "Anche se non la biasimo. Quando [dd.name!t] è in giro, è impossibile non essere la versione migliore di te stesso{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:92
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_d71a5fc8:

    # mc_t "Although I don't blame him. When [dd.name!t] is around, it's impossible not to be the best version of yourself{#female}."
    mc_t "Anche se non lo biasimo. Quando [dd.name!t] è in giro, è impossibile non essere la versione migliore di te stesso{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:94
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_53f2d32e:

    # mc_t "Although I don't blame him. When [dd.name!t] is around, it's impossible not to be the best version of yourself{#male}."
    mc_t "Anche se non lo biasimo. Quando [dd.name!t] è in giro, è impossibile non essere la versione migliore di te stesso{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:97
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_d28cd166:

    # mc_t "Whoa!" with dis_std_med
    mc_t "Ehi!" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:99
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4ac173ee:

    # mc_t "I see... They made one of those photos comparing past and present, right?"
    mc_t "Capisco... Hanno fatto una di quelle foto che mettono a confronto passato e presente, vero?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:102
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_98a17a29:

    # mc "{act}laughs{/act} {think}It's funny to see [ll.name!t] standing on tiptoes. She's adorable!{/think}"
    mc "{act}ride{/act} {think}È divertente vedere [ll.name!t] in punta di piedi. È adorabile!{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:104
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_e4915b6a:

    # mc "{act}laughs{/act} {think}It's funny to see [ll.name!t] standing on tiptoes. He's adorable!{/think}"
    mc "{act}ride{/act} {think}È divertente vedere [ll.name!t] in punta di piedi. È adorabile!{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:109
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_a8a7c117:

    # mc_t "Fuck, time flies..." with dis_std
    mc_t "Cavolo, il tempo vola..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:112
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_e872ef53:

    # mc_t "You can tell they're adults{#female} now. And even though they've chosen different paths, they're still best friends{#female}."
    mc_t "Si vede che sono adulti{#female} adesso. E anche se hanno scelto strade diverse, sono ancora migliori amici{#female}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:113
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_9f13a0e8:

    # mc_t "Their{#female} bond must be really strong..."
    mc_t "Il loro legame{#female} deve essere davvero forte..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:115
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_7249a51e:

    # mc_t "You can tell they're adults{#male} now. And even though they've chosen different paths, they're still best friends{#male}."
    mc_t "Si vede che sono adulti{#male} adesso. E anche se hanno scelto strade diverse, sono ancora migliori amici{#male}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:116
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_0b18ec06:

    # mc_t "Their{#male} bond must be really strong..."
    mc_t "Il loro legame{#male} deve essere davvero forte..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:118
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_03662619:

    # mc_t "You can tell they're adults{#both-genders} now. And even though they've chosen different paths, they're still best friends{#both-gender}."
    mc_t "Si vede che sono adulti{#both-genders} adesso. E anche se hanno scelto strade diverse, sono ancora migliori amici{#both-gender}."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:119
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_d8cc0ddc:

    # mc_t "Their{#both-genders} bond must be really strong..."
    mc_t "Il loro legame{#both-genders} deve essere davvero forte..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:123
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_cd3bf5da:

    # mc_t "Just look at them{#female}..." with dis_std_med
    mc_t "Basta guardarli{#female}..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:125
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_1faa43b8:

    # mc_t "Just look at them{#male}..." with dis_std_med
    mc_t "Basta guardarli{#male}..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:127
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_a18702e0:

    # mc_t "Just look at them{#both-genders}..." with dis_std_med
    mc_t "Basta guardarli{#both-genders}..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:130
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_a4667521:

    # mc_t "They look so... happy..."
    mc_t "Sembrano così... felici..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:131
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_485cf385:

    # mc_t "I wonder what would've happened if my attitude in high school had been different. Maybe if I'd played some sport, studied harder, and made some friends..."
    mc_t "Mi chiedo cosa sarebbe successo se il mio atteggiamento al liceo fosse stato diverso. Forse se avessi praticato qualche sport, studiato di più e fatto amicizia..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:132
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_904cdc2f:

    # mc_t "Maybe, just maybe... I could have a life like theirs."
    mc_t "Forse, solo forse... potrei avere una vita come la loro."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:134
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_d8769362:

    # mc_t "But it's too late for me. Although I envy them{#female} a little, now I don't even want a normal life."
    mc_t "Ma è troppo tardi per me. Anche se li invidio un po'{#female}, adesso non desidero nemmeno più una vita normale."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:136
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4a36f948:

    # mc_t "But it's too late for me. Although I envy them{#male} a little, now I don't even want a normal life."
    mc_t "Ma è troppo tardi per me. Anche se li invidio un po'{#male}, adesso non desidero nemmeno più una vita normale."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:138
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_9d05f0a4:

    # mc_t "But it's too late for me. Although I envy them{#both-genders} a little, now I don't even want a normal life."
    mc_t "Ma è troppo tardi per me. Anche se li invidio un po'{#both-genders}, adesso non desidero nemmeno più una vita normale."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:139
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_adb6a1e8:

    # mc_t "The question is... what do I want?"
    mc_t "La domanda è... cosa voglio?"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:145
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_8d0170f1:

    # mc_t "I don't know yet." with dis_std
    mc_t "Non lo so ancora." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:148
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_615d7c5c:

    # mc_t "And I'm completely alone{#female}..."
    mc_t "E sono completamente solo{#female}..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:150
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_89b05a83:

    # mc_t "And I'm completely alone{#male}..."
    mc_t "E sono completamente solo{#male}..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:152
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_6d59678d:

    # mc_t "But that's my biggest advantage, isn't it? I can start from scratch! No strings attached!"
    mc_t "Ma questo è il mio più grande vantaggio, no? Posso iniziare da zero! Senza obblighi!"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:153
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_80a04ae2:

    # mc "{act}yawns{/act}"
    mc "{act}sbadiglia{/act}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:154
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_2a53a54a:

    # mc_t "Alright, time to move my ass."
    mc_t "Va bene, è ora di muovere il culo."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:170
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_b3a50e13:

    # mc_t "Starting today, it's a clean slate!" with dis_std
    mc_t "A partire da oggi si ricomincia da capo!" with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:171
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_4ec6c31a:

    # mc_t "Let's leave the past behind. So no more nostalgia, and no more chasing other people's dreams..."
    mc_t "Lasciamo il passato alle spalle. Quindi basta nostalgia, e basta inseguire i sogni degli altri..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:172
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_df1339b1:

    # mc_t "I'll build my own dream!"
    mc_t "Costruirò il mio sogno!"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:174
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_cf0a684a:

    # mc_t "But first things first. I have to wash my face."
    mc_t "Ma prima le cose. Devo lavarmi la faccia."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:176
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch_e6045e91:

    # mc_t "But first things first. I have to wash my face, and shave this beard off."
    mc_t "Ma prima le cose. Devo lavarmi la faccia e radermi questa barba."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:228
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__dresser_7bfa532a:

    # mc_t "I think I'll clean another day." with dis_std
    mc_t "Penso che pulirò un altro giorno." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:229
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__dresser_b8445181:

    # mc_t "Sounds like a bad excuse, but today is different. I have something important to do!"
    mc_t "Sembra una brutta scusa, ma oggi è diverso. Ho qualcosa di importante da fare!"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:237
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_58cf4280:

    # mc_t "The city looks so different during mornings..." with dis_std
    mc_t "La città sembra così diversa la mattina..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:238
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_8fd91c97:

    # mc_t "They built that bridge to connect the Center with the Periphery, without needing to go through the Traditional Districts."
    mc_t "Hanno costruito quel ponte per collegare il Centro con la Periferia, senza bisogno di passare per i Quartieri Tradizionali."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:239
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_33f6f14f:

    # mc_t "Oh, but only a handful of privileged people can use it, of course."
    mc_t "Oh, ma solo una manciata di persone privilegiate possono usarlo, ovviamente."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:240
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_0d746d27:

    # mc_t "After all, access to the Center is restricted. Most of the vehicles crossing it don't even have humans inside..."
    mc_t "Dopotutto, l'accesso al Centro è limitato. La maggior parte dei veicoli che lo attraversano non hanno nemmeno esseri umani a bordo..."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:241
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_dd07f73b:

    # mc "{act}sighs{/act} {think}They make you feel insignificant.{/think}"
    mc "{act}sospiri{/act} {think}Ti fanno sentire insignificante.{/think}"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:244
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_af76702d:

    # mc "{act}looks to the air conditioner{/act}" with dis_std_med
    mc "{act}guarda al condizionatore{/act}" with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:245
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__window_6f09369a:

    # mc_t "Some day I'll fix it."
    mc_t "Un giorno lo sistemerò."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:253
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_5b8426e9:

    # mc_t "This bookshelf has no life..." with dis_std
    mc_t "Questa libreria non ha vita..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:254
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_3d482b70:

    # mc_t "But not for long!"
    mc_t "Ma non per molto!"

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:256
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_2977216a:

    # mc_t "At some point, I'm sure{#female} I'll find meaningful things to put here."
    mc_t "Ad un certo punto, sono sicuro{#female} troverò cose significative da mettere qui."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:258
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_6ef861dc:

    # mc_t "At some point, I'm sure{#male} I'll find meaningful things to put here."
    mc_t "Ad un certo punto, sono sicuro{#male} Troverò cose significative da mettere qui."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:261
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_82a0590b:

    # mc_t "Damn, I forgot to throw away that pizza slice..." with dis_std_med
    mc_t "Accidenti, ho dimenticato di buttare via quel trancio di pizza..." with dis_std_med

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:262
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__shelves_b7eef3c6:

    # mc_t "I'll do it later."
    mc_t "Lo farò più tardi."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:306
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__bed_d8c03c6c:

    # mc_t "I don't feel like making the bed..." with dis_std
    mc_t "Non ho voglia di rifare il letto..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:307
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__bed_b97c7eee:

    # mc_t "As always."
    mc_t "Come sempre."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:350
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__kitchen_zoom_01f346d1:

    # mc_t "Ugh, what a mess..." with dis_std
    mc_t "Uffa, che confusione..." with dis_std

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:351
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__kitchen_zoom_76e72015:

    # mc_t "I guess I have no choice but to clean it up before breakfast."
    mc_t "Immagino di non avere altra scelta che ripulirlo prima di colazione."

# game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:358
translate italian scene__book1__c1_awakening__e04_radical_change__s02_from_scratch__end_scene_8ff08e89:

    # mc_t "All right, here we go!" with dis_std
    mc_t "Va bene, eccoci qua!" with dis_std

translate italian strings:

    # game/story/book1/c1_awakening/e04_radical_change/s02_from_scratch/script.rpy:157
    old "JUMP{#first-apartment-from-bed}"
    new "SALTA{#first-apartment-from-bed}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
