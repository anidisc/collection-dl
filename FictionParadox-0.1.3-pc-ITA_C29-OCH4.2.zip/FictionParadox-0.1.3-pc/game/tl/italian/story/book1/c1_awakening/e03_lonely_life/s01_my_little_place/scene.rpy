﻿
translate italian strings:

    # game/story/book1/c1_awakening/e03_lonely_life/s01_my_little_place/scene.rpy:6
    old "My Little Place{#story-scene}"
    new "Il mio piccolo posto{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
