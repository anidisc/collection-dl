﻿
# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:74
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_d646f17b:

    # humanoid3 "Hello, human{#female}."
    humanoid3 "Ciao, umano{#female}."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:76
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_cd794c69:

    # humanoid3 "Hello, human{#male}."
    humanoid3 "Ciao, umano{#male}."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:77
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_6c9af413:

    # humanoid3 "The Cosmos weaves different paths, all leading to the same meeting point with destiny. That's why you are here."
    humanoid3 "Il Cosmo intreccia percorsi diversi, che conducono tutti allo stesso punto d'incontro con il destino. Ecco perché sei qui."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:78
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_4c1e9d25:

    # humanoid3 "But each person has its own way of moving forward..."
    humanoid3 "Ma ogni persona ha il suo modo di andare avanti..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:82
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_6536af3e:

    # humanoid3 "Some see life as a story." with dis_std_long
    humanoid3 "Alcuni vedono la vita come una storia." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:83
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_bbffc3d2:

    # humanoid3 "They just want to watch the events flow, one after another, until the end."
    humanoid3 "Vogliono solo osservare lo scorrere degli eventi, uno dopo l'altro, fino alla fine."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:87
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_62b9f58a:

    # humanoid3 "Others, however, see life as a game." with dis_std_long
    humanoid3 "Altri, invece, vedono la vita come un gioco." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:88
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_6fe0782e:

    # humanoid3 "They prefer to do things by themselves, even if they have to try again several times."
    humanoid3 "Preferiscono fare le cose da soli, anche se devono riprovarci più volte."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:91
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_0eca58b9:

    # humanoid3 "Same path, different way to live it." with dis_std
    humanoid3 "Stesso percorso, modo diverso di viverlo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:92
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_d5623031:

    # humanoid3 "And you? How do you see the path that lies before you?"
    humanoid3 "E tu? Come vedi il percorso che si trova davanti a te?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:96
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_aedf8ef2:

    # system "If you just want to read and enjoy the story, choose novel mode. Game mode only adds quick actions and small puzzles from time to time."
    system "Se vuoi solo leggere e goderti la storia, scegli la modalità romanzo. La modalità di gioco aggiunge solo azioni rapide e piccoli enigmi di tanto in tanto."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:97
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_6e81f22b:

    # system "Don't worry about the content! It's identical in both modes."
    system "Non preoccuparti del contenuto! È identico in entrambe le modalità."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:115
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_6eb559ee:

    # humanoid3 "Now close your eyes."
    humanoid3 "Ora chiudi gli occhi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:122
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_5e4a503a:

    # humanoid3 "Take a deep breath." with dis_std
    humanoid3 "Fai un respiro profondo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:128
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_945cbb65:

    # humanoid3 "That's it." with dis_std
    humanoid3 "Questo è tutto." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:130
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_bc20561c:

    # humanoid3 "You sound a little congested{#female}, but it's okay."
    humanoid3 "Sembri un po' congestionato{#female}, ma va bene."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:132
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_047296b4:

    # humanoid3 "You sound a little congested{#male}, but it's okay."
    humanoid3 "Sembri un po' congestionato{#male}, ma va bene."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:135
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_856c6490:

    # humanoid3 "Sometimes, you will have to perform some actions in order to succeed."
    humanoid3 "A volte, dovrai eseguire alcune azioni per avere successo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:137
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_70d221d7:

    # humanoid3 "Can you imagine yourself{#female} doing that?"
    humanoid3 "Riesci a immaginarti{#female} mentre fai una cosa del genere?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:139
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_2ba5ea91:

    # humanoid3 "Can you imagine yourself{#male} doing that?"
    humanoid3 "Riesci a immaginarti{#male} mentre fai una cosa del genere?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:162
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_bbf6691b:

    # system "Click on the proper side of the screen to perform an action." with dis_std
    system "Fare clic sul lato corretto dello schermo per eseguire un'azione." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:163
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_576b66ff:

    # system "Keep in mind that there's no need to click on the text. You can click on any place from that side of the screen."
    system "Tieni presente che non è necessario fare clic sul testo. Puoi fare clic in qualsiasi punto da quel lato dello schermo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:178
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_406a6852:

    # system "Well done!" with dis_std
    system "Ben fatto!" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:179
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_27e72599:

    # system "Some actions require continuous movements. A single click is enough, but this may change in the future..."
    system "Alcune azioni richiedono movimenti continui. Basta un solo clic, ma questo potrebbe cambiare in futuro..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:180
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_27a2039d:

    # system "Now, let's continue."
    system "Ora continuiamo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:181
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_59a1b757:

    # system ". . ."
    system ". . ."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:182
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_a8527aa5:

    # system "Okay, I know you're having fun, but let's move on."
    system "Ok, so che ti stai divertendo, ma andiamo avanti."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:190
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_f46cd70a:

    # system "Let's try with the other side of the screen." with dis_std
    system "Proviamo con l'altro lato dello schermo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:191
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_e6ad64ae:

    # system "Can you do it?"
    system "Puoi farlo?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:205
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_406a6852_1:

    # system "Well done!" with dis_std
    system "Ben fatto!" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:206
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_64086bb4:

    # system "Let's try a combo of 3 hits in a row."
    system "Proviamo una combo di 3 colpi di fila."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:207
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_b8a21a3e:

    # system "You chose game mode, so the second and third hits will wait only for a limited period of time. Stay alert!"
    system "Hai scelto la modalità di gioco, quindi il secondo e il terzo colpo attenderanno solo per un periodo di tempo limitato. Stai attento!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:232
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_a9428be9:

    # system "You didn't click in time. Try again!"
    system "Non hai fatto clic in tempo. Riprova!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:246
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_a9428be9_1:

    # system "You didn't click in time. Try again!"
    system "Non hai fatto clic in tempo. Riprova!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:251
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_42e68d9f:

    # system "{size=*1.5}BE CAREFUL!{/size}"
    system "{size=*1.5}FAI ATTENZIONE!{/size}"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:252
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_c30251e8:

    # system "This is just a tutorial. Don't overdo it, or you'll hurt yourself!"
    system "Questo è solo un tutorial. Non esagerare o ti farai male!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:258
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_1a2877aa:

    # humanoid3 "I don't know what you imagined, but you seem determined{#female}." with dis_std
    humanoid3 "Non so cosa immaginavi, ma sembri determinato{#female}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:260
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_f6a6aedb:

    # humanoid3 "I don't know what you imagined, but you seem determined{#male}." with dis_std
    humanoid3 "Non so cosa immaginavi, ma sembri determinato{#male}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:262
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_d796628e:

    # humanoid3 "Now, take a deep breath again."
    humanoid3 "Ora fai di nuovo un respiro profondo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:266
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_7f14bc77:

    # humanoid3 "Feel the air flowing through your body." with dis_std
    humanoid3 "Senti l'aria che scorre attraverso il tuo corpo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:268
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_e7d6879e:

    # humanoid3 "Just relax and feel the air flowing through your body..."
    humanoid3 "Rilassati e senti l'aria che scorre attraverso il tuo corpo..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:269
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_dbe26730:

    # humanoid3 "As you can see, even in the deepest darkness, you can still interact with your environment."
    humanoid3 "Come puoi vedere, anche nell'oscurità più profonda, puoi ancora interagire con il tuo ambiente."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:270
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_3c1f8c9f:

    # humanoid3 "Every thought, every feeling, every action leaves a mark that time can never erase. But not all marks are the same..."
    humanoid3 "Ogni pensiero, ogni sentimento, ogni azione lascia un segno che il tempo non potrà mai cancellare. Ma non tutti i segni sono uguali..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:271
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_1cf2974d:

    # humanoid3 "When a shooting star fades away, no one forgets its path in the sky."
    humanoid3 "Quando una stella cadente svanisce, nessuno dimentica il suo percorso nel cielo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:275
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_db659033:

    # humanoid3 "That path is your Life Trail." with dis_std
    humanoid3 "Quel percorso è il tuo percorso di vita." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:276
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_97b63646:

    # system "You can open your Life Trail from the heart icon in the top-left corner."
    system "Puoi aprire il tuo percorso di vita dall'icona del cuore nell'angolo in alto a sinistra."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:277
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_f7b60aaf:

    # system "On that screen, you can see the profiles of the potential love interests (as you get to know them), and your memories."
    system "Su quella schermata puoi vedere i profili dei potenziali interessi amorosi (man mano che li conosci) e i tuoi ricordi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:278
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_f27bcf0a:

    # system "When something strengthens a bond with a character, the icon glows red, like this:"
    system "Quando qualcosa rafforza un legame con un personaggio, l'icona si illumina di rosso, in questo modo:"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:280
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_dd402e77:

    # system "On the other hand, when something weakens a bond, the glow turns blue, like this:" with dis_std
    system "D'altra parte, quando qualcosa indebolisce un legame, il bagliore diventa blu, in questo modo:" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:282
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_5f4fcc12:

    # system "Your choices won't affect the main story, but they will affect the bonds you form with the characters." with dis_std
    system "Le tue scelte non influenzeranno la storia principale, ma influenzeranno i legami che formerai con i personaggi." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:283
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_31b2ab69:

    # system "Choose wisely. ;)"
    system "Scegli saggiamente. ;)"

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:151
    old "Try the hoop{#actions tutorial}"
    new "Prova il cerchio{#actions tutorial}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:154
    old "Try the stick{#actions tutorial}"
    new "Prova il bastoncino{#actions tutorial}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:157
    old "Stop imagining{#game mode tutorial}"
    new "Smettila di immaginare{#game mode tutorial}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:165
    old "SPIN{#action;hula-hoop}"
    new "GIRA{#action;hula-hoop}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:194
    old "HIT{#action;stick}"
    new "COLPI{#action;stick}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:163
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_0002a17e:

    # system "Tap on the proper side of the screen to perform an action." with dis_std
    system "Tocca il lato corretto dello schermo per eseguire un'azione." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:164
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_852c376c:

    # system "Keep in mind that there's no need to tap on the text. You can tap on any place from that side of the screen."
    system "Tieni presente che non è necessario toccare il testo. Puoi toccare qualsiasi punto da quel lato dello schermo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:184
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_1eac178b:

    # system "Some actions require continuous movements. A single tap is enough, but this may change in the future..."
    system "Alcune azioni richiedono movimenti continui. È sufficiente un solo tocco, ma la situazione potrebbe cambiare in futuro..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:240
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_42557434:

    # system "You didn't tap in time. Try again!"
    system "Non hai intercettato in tempo. Riprova!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/script.rpy:257
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s03_ways_of_living_42557434_1:

    # system "You didn't tap in time. Try again!"
    system "Non hai intercettato in tempo. Riprova!"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
