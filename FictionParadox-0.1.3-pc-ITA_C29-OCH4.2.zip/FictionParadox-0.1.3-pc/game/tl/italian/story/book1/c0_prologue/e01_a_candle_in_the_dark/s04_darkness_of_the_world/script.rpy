﻿
# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:183
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_10ae8a4e:

    # humanoid3 "{act}talking behind you{/act} Most people make it this far." with dis_std_med
    humanoid3 "{act}parla dietro di te{/act} La maggior parte delle persone arriva fin qui." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:186
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_b8598f8e:

    # humanoid3 "Your light has proven to be very useful, but it's not enough." with dis_std_long
    humanoid3 "La tua luce si è rivelata molto utile, ma non basta." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:187
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_6f54a30c:

    # humanoid3 "Darkness is too strong from now on."
    humanoid3 "L'oscurità è troppo forte da ora in poi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:192
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_83d32b6a:

    # voice_abyss "That's right." with dis_std_med
    voice_abyss "Giusto." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:193
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_5a121611:

    # voice_abyss "Hello again, [mc.name!t]. I hope you enjoyed the journey."
    voice_abyss "Salve di nuovo, [mc.name!t]. Spero che il viaggio ti sia piaciuto."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:194
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_7e2f533e:

    # voice_abyss "But this light won't be able to protect you here. I'm sorry..."
    voice_abyss "Ma questa luce non sarà in grado di proteggerti qui. mi dispiace..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:198
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_066f905a:

    # voice_abyss "What? You still want to continue?" with dis_std
    voice_abyss "Cosa? Vuoi ancora continuare?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:199
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_0e8088a7:

    # voice_abyss ". . ."
    voice_abyss ". . ."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:200
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_19b3a354:

    # voice_abyss "Very well..."
    voice_abyss "Molto bene..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:230
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a51265aa:

    # voice_abyss "You are about to face the most voracious and terrifying darkness!"
    voice_abyss "Stai per affrontare l'oscurità più vorace e terrificante!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:232
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a3844855:

    # voice_abyss "As you can see, you're not the first{#female} one who came here..."
    voice_abyss "Come puoi vedere, non sei il primo{#female} che è venuto qui..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:234
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_5ad44243:

    # voice_abyss "As you can see, you're not the first{#male} one who came here..."
    voice_abyss "Come puoi vedere, non sei il primo{#male} che è venuto qui..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:237
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_9f2ea315:

    # voice_abyss "These lights are from other travelers who arrived before you." with dis_std_long
    voice_abyss "Queste luci provengono da altri viaggiatori arrivati ​​prima di te." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:238
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a2fa06f9:

    # voice_abyss "Unfortunately, they are too fragile in this place. Without the protection of these boxes, they would end up being corrupted by darkness."
    voice_abyss "Sfortunatamente, sono troppo fragili in questo posto. Senza la protezione di queste scatole, finirebbero per essere corrotte dall’oscurità."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:239
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a6a6ea5a:

    # voice_abyss "Some of those adventurers kept moving forward, and were completely devoured... Nobody remembers them now."
    voice_abyss "Alcuni di quegli avventurieri continuarono ad avanzare e furono completamente divorati... Nessuno si ricorda più di loro."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:240
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_7b82a003:

    # voice_abyss "Others were smarter. They feared death, and saved their lights before it was too late."
    voice_abyss "Altri erano più intelligenti. Temevano la morte e salvarono le loro luci prima che fosse troppo tardi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:244
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_229b3f84:

    # voice_abyss "Oh, but don't worry... You don't have to keep going if you don't want to." with dis_woosh_medium
    voice_abyss "Oh, ma non preoccuparti... Non sei obbligato ad andare avanti se non vuoi." with dis_woosh_medium

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:246
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_c18fa73b:

    # voice_abyss "Considering that you are the weakest person who has come here, the wisest option is to put your light in a box."
    voice_abyss "Considerando che sei la persona più debole che è venuta qui, l’opzione più saggia è mettere la tua luce in una scatola."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:247
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_d7808927:

    # voice_abyss "After all, its creators would not want it to be corrupted..."
    voice_abyss "Dopotutto, i suoi creatori non vorrebbero che fosse corrotto..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:250
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_b1260ac1:

    # voice_abyss "Hmm?" with dis_std_med
    voice_abyss "Ehm?" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:252
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_11c3d8a8:

    # voice_abyss "What do you have in mind...?"
    voice_abyss "Cos'hai in mente...?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:258
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_696a0a75:

    # voice_abyss "Where do you think you're going?"
    voice_abyss "Dove pensi di andare?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:259
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_754a8f72:

    # voice_abyss "Aren't you afraid?"
    voice_abyss "Non hai paura?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:268
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_18ab85ae:

    # voice_abyss "Do you want to end up like them?"
    voice_abyss "Vuoi finire come loro?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:269
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a8ccd353:

    # voice_abyss "Why do you keep going if you know you're going to die?"
    voice_abyss "Perché continui ad andare avanti se sai che stai per morire?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:276
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_fd4e27cc:

    # voice_abyss "If you don't stop, the light I gave you will be lost forever..."
    voice_abyss "Se non ti fermi, la luce che ti ho dato andrà perduta per sempre..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:315
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_c16118d4:

    # voice_abyss ".{cps=1.5}..{/cps}"
    voice_abyss ".{cps=1.5}..{/cps}"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:324
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_1d4ebd8c:

    # voice_abyss "This path is the most dangerous of all."
    voice_abyss "Questo percorso è il più pericoloso di tutti."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:325
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_6e3a8b95:

    # voice_abyss "Once you cross a certain threshold, there will be no turning back..."
    voice_abyss "Una volta varcata una certa soglia, non si potrà più tornare indietro..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:332
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_da50d547:

    # voice_abyss "Why?"
    voice_abyss "Perché?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:333
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_dfe05c32:

    # voice_abyss "What makes you think you can win?"
    voice_abyss "Cosa ti fa pensare di poter vincere?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:368
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_0e44a372:

    # voice_abyss "How disappointing..."
    voice_abyss "Che delusione..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:369
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_26650cfd:

    # voice_abyss "I thought you'd be smarter than that."
    voice_abyss "Pensavo che saresti stato più intelligente di così."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:404
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_18ab1fcd:

    # voice_abyss "Your pathetic light is no match for the darkness of the world." with dis_std
    voice_abyss "La tua patetica luce non può competere con l'oscurità del mondo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:435
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_36d336e6:

    # voice_abyss "I warned you, but you didn't listen to me..." with dis_std
    voice_abyss "Ti avevo avvertito, ma non mi hai ascoltato..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:450
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_f5ffc538:

    # voice_abyss "There's no hope..." with dis_std
    voice_abyss "Non c'è speranza..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:481
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_b3fc57e2:

    # voice_abyss "It's a meaningless effort..." with dis_std
    voice_abyss "E' uno sforzo senza senso..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:512
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_e60fda4e:

    # voice_abyss "What a pity..." with dis_std
    voice_abyss "Che peccato..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:514
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_d2f9db32:

    # voice_abyss "Are you prepared{#female} to accept your defeat?"
    voice_abyss "Sei pronto{#female} ad accettare la tua sconfitta?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:516
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_4ee55e7d:

    # voice_abyss "Are you prepared{#male} to accept your defeat?"
    voice_abyss "Sei pronto{#male} ad accettare la tua sconfitta?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:523
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_3901e617:

    # voice_abyss "Where are you going?"
    voice_abyss "Dove stai andando?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:524
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_7119310c:

    # voice_abyss "Do you really think you stand a chance using a different light?"
    voice_abyss "Pensi davvero di avere una possibilità utilizzando una luce diversa?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:538
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_2139f835:

    # voice_abyss "There's nothing you can do..." with dis_std
    voice_abyss "Non c'è niente che tu possa fare..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:544
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_b2f39ae8:

    # voice_abyss "No light can handle so much darkness..." with dis_std
    voice_abyss "Nessuna luce può sopportare così tanta oscurità..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:546
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_2caa43b2:

    # voice_abyss "You are brave{#female}, I'll give you that."
    voice_abyss "Sei coraggioso{#female}, te lo ammetto."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:548
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_6c799739:

    # voice_abyss "You are brave{#male}, I'll give you that."
    voice_abyss "Sei coraggioso{#male}, te lo ammetto."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:549
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_341265a0:

    # voice_abyss "But others stronger and smarter than you already tried... and failed."
    voice_abyss "Ma altri più forti e più intelligenti di quelli che hai già provato... e hanno fallito."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:560
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_88df5171:

    # voice_abyss "You're alone{#female}..." with dis_std_med
    voice_abyss "Sei solo{#female}..." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:562
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_faf18143:

    # voice_abyss "You're alone{#male}..." with dis_std_med
    voice_abyss "Sei solo{#male}..." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:563
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_7804a7cd:

    # voice_abyss "And no one can help you."
    voice_abyss "E nessuno può aiutarti."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:566
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_4a0e1c4c:

    # voice_abyss "Because the light you {i}use{/i} doesn't matter..." with dis_std_med
    voice_abyss "Perché la luce che {i}usi{/i} non ha importanza..." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:570
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_ff6a6c12:

    # voice_abyss "This darkness will always corrupt it." with dis_std
    voice_abyss "Questa oscurità lo corromperà sempre." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:576
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_fb47f88c:

    # voice_abyss "Your defeat was inevitable." with dis_std_med
    voice_abyss "La tua sconfitta era inevitabile." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:578
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_732622e4:

    # voice_abyss "Did you expect a different outcome? How naive{#female}..."
    voice_abyss "Ti aspettavi un risultato diverso? Che ingenuo{#female}..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:580
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_b444e539:

    # voice_abyss "Did you expect a different outcome? How naive{#male}..."
    voice_abyss "Ti aspettavi un risultato diverso? Che ingenuo{#male}..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:581
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_8adda0fc:

    # voice_abyss "This is the fate that awaits anyone who dares to face the darkness of the world."
    voice_abyss "Questo è il destino che attende chiunque osi affrontare l'oscurità del mondo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:582
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_3d6c3594:

    # voice_abyss "There was never any good or evil, nor justice or injustice. Only those who live in ignorance believe in such childish ideas."
    voice_abyss "Non c’è mai stato né bene né male, né giustizia né ingiustizia. Solo coloro che vivono nell’ignoranza credono in idee così infantili."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:583
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_422f0b1f:

    # voice_abyss "The only one thing you can expect is..."
    voice_abyss "L'unica cosa che puoi aspettarti è..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:586
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_a9e6cee8:

    # voice_abyss "Darkness."
    voice_abyss "Oscurità."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:587
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_9a249196:

    # voice_abyss "And this harsh truth will haunt you forever..."
    voice_abyss "E questa dura verità ti perseguiterà per sempre..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:593
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_eabb5595:

    # voice_abyss "Deep down, you know this darkness can't be defeated by light." with dis_std_med
    voice_abyss "Nel profondo, sai che questa oscurità non può essere sconfitta dalla luce." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:594
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_7b872187:

    # voice_abyss "Some things are just impossible. The sooner you accept this, the sooner you'll stop your suffering..."
    voice_abyss "Alcune cose sono semplicemente impossibili. Prima lo accetterai, prima smetterai di soffrire..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:595
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_dee8cc7c:

    # voice_abyss "But I know you won't."
    voice_abyss "Ma so che non lo farai."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:596
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_3603b41b:

    # voice_abyss "For that reason, an agonizing and miserable existence awaits."
    voice_abyss "Per questo motivo lo attende un’esistenza agonizzante e miserabile."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:597
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_bbe2bd80:

    # voice_abyss "I'm sorry for you..."
    voice_abyss "Mi dispiace per te..."

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:138
    old "{sc=2}{size=*1.3}This darkness is alive...{/size}{/sc}{# prologue; hands}"
    new "{sc=2}{size=*1.3}Questa oscurità è viva...{/size}{/sc}{# prologue; hands}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:143
    old "{sc=2}{size=*1.3}Its millions of hearts beat strongly...{/size}{/sc}{# prologue; hands}"
    new "{sc=2}{size=*1.3}I suoi milioni di cuori battono forte...{/size}{/sc}{# prologue; hands}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:148
    old "{sc=2}{size=*1.3}Its veins extend beyond time...{/size}{/sc}{# prologue; hands}"
    new "{sc=2}{size=*1.3}Le sue vene si estendono oltre il tempo...{/size}{/sc}{# prologue; hands}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:153
    old "{sc=2}{size=*1.3}AND YOU ARE THE OXYGEN IT DEVOURS!{/size}{/sc}{# prologue; hands}"
    new "{sc=2}{size=*1.3}E TU SEI L'OSSIGENO CHE DIVORA!{/size}{/sc}{# prologue; hands}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:283
    old "KEEP YOUR\nBALANCE{#action; almost falling}"
    new "MANTIENI IL TUO\nSALDO{#action; almost falling}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:339
    old "JUMP{#action}"
    new "SALTA{#action}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:381
    old "DODGE{#action; dark hands}"
    new "SCHIVARE{#action; dark hands}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:260
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_4c48da1a:

    # voice_abyss "Do you want to end up like them?" with dis_std_med
    voice_abyss "" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:264
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_751bf5f2:

    # voice_abyss "If you don't stop, the light I gave you will be lost forever..." with dis_std_med
    voice_abyss "" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s04_darkness_of_the_world/script.rpy:311
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s04_darkness_of_the_world_725f114b:

    # voice_abyss "Why?" with dis_std_med
    voice_abyss "" with dis_std_med

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
