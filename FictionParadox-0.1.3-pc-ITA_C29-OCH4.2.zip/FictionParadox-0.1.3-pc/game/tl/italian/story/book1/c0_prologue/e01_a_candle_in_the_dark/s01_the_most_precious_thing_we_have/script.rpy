﻿
# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:17
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e6934761:

    # voice_abyss "Many believe darkness devoured the world..."
    voice_abyss "Molti credono che l’oscurità abbia divorato il mondo…"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:19
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e4064654:

    # voice_abyss "Many believe darkness devoured the world..." with dis_std_med
    voice_abyss "Molti credono che l’oscurità abbia divorato il mondo…" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:20
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_af2d9d37:

    # voice_abyss "Although, in reality, the world was already like this from the beginning."
    voice_abyss "Anche se, in realtà, il mondo era già così fin dall'inizio."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:21
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_6da352a9:

    # voice_abyss "Very few are aware of what that means. And even among those who know, the norm is to do nothing about it."
    voice_abyss "Pochissimi sono consapevoli di cosa significhi. E anche tra coloro che sanno, la norma è non fare nulla al riguardo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:22
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_5b1636ab:

    # voice_abyss "But you are not like them, right?"
    voice_abyss "Ma tu non sei come loro, vero?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:23
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_38198f21:

    # voice_abyss "I can sense it..."
    voice_abyss "Lo sento..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:24
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_00e162fe:

    # voice_abyss "That darkness torments you.{w} It haunts you.{w} It doesn't let you live."
    voice_abyss "Quell'oscurità ti tormenta.{w} Ti perseguita.{w} Non ti lascia vivere."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:25
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_94a61e71:

    # voice_abyss "It was only a matter of time before you ended up here..."
    voice_abyss "Era solo questione di tempo prima che tu finissi qui..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:26
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_5f4e207c:

    # voice_abyss "Now, reveal yourself."
    voice_abyss "Ora rivelati."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:45
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d2b9d84f:

    # voice_abyss "This{#female} is you...?" with dis_std
    voice_abyss "Questo{#female} sei tu...?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:47
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a8105d31:

    # voice_abyss "This{#male} is you...?" with dis_std
    voice_abyss "Questo{#male} sei tu...?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:48
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_53977a6c:

    # voice_abyss "I wasn't expecting such a weak body. Don't you value your life?"
    voice_abyss "Non mi aspettavo un corpo così debole. Non dai valore alla tua vita?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:49
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7844bcf7:

    # voice_abyss "Because sooner or later, at some point in the future..."
    voice_abyss "Perché prima o poi, ad un certo punto del futuro..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:52
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_1f72d491:

    # voice_abyss "...it will end."
    voice_abyss "... finirà."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:54
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7426c8d8:

    # voice_abyss "Forever."
    voice_abyss "Per sempre."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:55
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a1b3959d:

    # voice_abyss "Every second that passes, you are a little closer to death. There's nothing you can do to avoid it."
    voice_abyss "Ogni secondo che passa sei sempre più vicino alla morte. Non c'è niente che puoi fare per evitarlo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:56
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a7409498:

    # voice_abyss "Terrifying, isn't it?"
    voice_abyss "Terrificante, non è vero?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:57
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_3b1cf3bb:

    # voice_abyss "That's the reason why everyone tries to find meaning in life."
    voice_abyss "Questo è il motivo per cui tutti cercano di trovare un significato nella vita."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:58
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7b47cab6:

    # voice_abyss "It's a journey through uncertainty..."
    voice_abyss "È un viaggio nell'incertezza..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:73
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7399e798:

    # voice_abyss "This light could be useful for your journey." with dis_std
    voice_abyss "Questa luce potrebbe esserti utile per il tuo viaggio." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:74
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_3e15e330:

    # voice_abyss "It was built by wise people who were looking for answers, just like you."
    voice_abyss "È stato costruito da persone sagge che cercavano risposte, proprio come te."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:75
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a4983faa:

    # voice_abyss "Don't be afraid. Come closer."
    voice_abyss "Non aver paura. Avvicinati."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:80
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_3319db4a:

    # voice_abyss "Listen carefully..." with dis_std
    voice_abyss "Ascolta attentamente..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:81
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_edfdb7e7:

    # voice_abyss "Life is a delicate process. It offers moments of joy and sorrow, testing our limits with every step."
    voice_abyss "La vita è un processo delicato. Offre momenti di gioia e di dolore, mettendo alla prova i nostri limiti ad ogni passo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:82
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_5a14ccb3:

    # voice_abyss "But to live is to move forward, even when the path is uncertain."
    voice_abyss "Ma vivere è andare avanti, anche quando il percorso è incerto."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:84
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7caf7d3f:

    # voice_abyss "Are you willing{#female} to move forward?"
    voice_abyss "Sei disposto{#female} ad andare avanti?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:86
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e3177448:

    # voice_abyss "Are you willing{#male} to move forward?"
    voice_abyss "Sei disposto{#male} ad andare avanti?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:87
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_500d8c6e:

    # voice_abyss "If that's the case, take this light with you and let it guide you until the end."
    voice_abyss "Se è così, porta questa luce con te e lascia che ti guidi fino alla fine."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:94
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_8ff05629:

    # system "Hello! Welcome{#female} to Fiction Paradox{#translated}." with dis_std
    system "Ciao! Benvenuto{#female} in Fiction Paradox{#translated}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:96
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_35af1953:

    # system "Hello! Welcome{#female} to Fiction Paradox{#not-translated}." with dis_std
    system "Ciao! Benvenuto{#female} in Fiction Paradox{#not-translated}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:99
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_2d8ba65a:

    # system "Hello! Welcome{#male} to Fiction Paradox{#translated}." with dis_std
    system "Ciao! Benvenuto{#male} in Fiction Paradox{#translated}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:101
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_3fdd2912:

    # system "Hello! Welcome{#male} to Fiction Paradox{#not-translated}." with dis_std
    system "Ciao! Benvenuto{#male} in Fiction Paradox{#not-translated}." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:102
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_166c0c9a:

    # system "This game is a visual novel, so the story is told through dialogues, images and music."
    system "Questo gioco è un romanzo visivo, quindi la storia è raccontata attraverso dialoghi, immagini e musica."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:104
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_4b145a69:

    # system "The quick menu you opened in the lower left corner shows different icons. Hover your mouse over them in order to see what they do."
    system "Il menu rapido che hai aperto nell'angolo in basso a sinistra mostra diverse icone. Passa il mouse sopra di loro per vedere cosa fanno."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:108
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_6989853d:

    # system "When you click on the bottom left icon, you can see the quick menu. Hover your mouse over each icon in order to see what they do."
    system "Quando fai clic sull'icona in basso a sinistra, puoi visualizzare il menu rapido. Passa il mouse su ciascuna icona per vedere cosa fanno."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:112
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_8afb40e3:

    # system "Hiding the quick menu is as easy as clicking on the bottom icon again."
    system "Nascondere il menu rapido è facile come fare nuovamente clic sull'icona in basso."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:113
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_50e3a635:

    # system "You can also open the game menu by doing right click with the mouse. You can save your progress there!"
    system "Puoi anche aprire il menu di gioco facendo clic con il tasto destro del mouse. Puoi salvare i tuoi progressi lì!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:114
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_9140fe10:

    # system "Please, take a look to the Preferences screen. Before continuing, adjust the volume, the interface, and other settings to your liking."
    system "Per favore, dai un'occhiata alla schermata Preferenze. Prima di continuare, regola il volume, l'interfaccia e le altre impostazioni a tuo piacimento."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:115
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_aa6ab09d:

    # system "For the best experience, we suggest keeping the audio enabled. Makes the experience more immersive!"
    system "Per una migliore esperienza, suggeriamo di mantenere l'audio abilitato. Rende l'esperienza più coinvolgente!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:116
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_263ed269:

    # system "You can also hide the entire interface at any time by pressing \"H\". A full list of controls is available in Preferences."
    system "Puoi anche nascondere l'intera interfaccia in qualsiasi momento premendo \'H\'. Un elenco completo dei controlli è disponibile in Preferenze."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:117
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_2156e9ed:

    # system "Have fun! :D"
    system "Divertiti! :D"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:133
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_73232f2b:

    # unknown "{act}emerging in front of you{/act}" with dis_std
    unknown "{act}emergendo davanti a te{/act}" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:139
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d8099801:

    # voice_abyss "Not everyone has a light that guides them." with dis_std
    voice_abyss "Non tutti hanno una luce che li guida." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:141
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d0fd6d84:

    # voice_abyss "If you feel grateful{#female} for having one, you can share it with others."
    voice_abyss "Se ti senti grato{#female} per averne uno, puoi condividerlo con gli altri."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:143
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_ce2bfc52:

    # voice_abyss "If you feel grateful{#male} for having one, you can share it with others."
    voice_abyss "Se ti senti grato{#male} per averne uno, puoi condividerlo con gli altri."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:163
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_9bc888f2:

    # voice_abyss "I created these beings just for you..." with dis_std
    voice_abyss "Ho creato questi esseri solo per te..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:165
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_48954db1:

    # voice_abyss "These are the two most common bodies of your species, right? I thought you would feel more comfortable{#female} this way."
    voice_abyss "Questi sono i due corpi più comuni della tua specie, giusto? Pensavo ti saresti sentito più a tuo agio{#female} così."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:167
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_fa20bceb:

    # voice_abyss "These are the two most common bodies of your species, right? I thought you would feel more comfortable{#male} this way."
    voice_abyss "Questi sono i due corpi più comuni della tua specie, giusto? Pensavo ti saresti sentito più a tuo agio{#male} così."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:168
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_ed252031:

    # voice_abyss "Of course, they are not real humans. They don't even have a name..."
    voice_abyss "Naturalmente non sono veri esseri umani. Non hanno nemmeno un nome..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:173
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e23aa305:

    # voice_abyss "But I'm sure you do." with dis_std
    voice_abyss "Ma sono sicuro che lo fai." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:179
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_94526563:

    # voice_abyss "Tell me, what's your name?"
    voice_abyss "Dimmi, come ti chiami?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:193
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_8d02d719:

    # voice_abyss "And your surname?" with dis_std
    voice_abyss "E il tuo cognome?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:206
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_b18dce25:

    # voice_abyss "“[mc.name!t] [mc.surname!t]”. Is that your full name?" with dis_std
    voice_abyss "“[mc.name!t] [mc.surname!t]”. È il tuo nome completo?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:213
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_2e684781:

    # voice_abyss "Then, let's try again." with dis_std
    voice_abyss "Allora riproviamo." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:216
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_43e7159c:

    # voice_abyss "Very well, [mc.name!t]..."
    voice_abyss "Molto bene, [mc.name!t]..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:218
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a0e433e5:

    # voice_abyss "Very well, [mc.name!t]..." with dis_std
    voice_abyss "Molto bene, [mc.name!t]..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:221
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_0a0b24d5:

    # voice_abyss "I assume you are surrounded{#female} by other humans in your world. It must be difficult to form real bonds among so much darkness..."
    voice_abyss "Presumo che tu sia circondato{#female} da altri umani nel tuo mondo. Deve essere difficile formare veri legami in mezzo a tanta oscurità..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:223
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_21551956:

    # voice_abyss "I assume you are surrounded{#male} by other humans in your world. It must be difficult to form real bonds among so much darkness..."
    voice_abyss "Presumo che tu sia circondato{#male} da altri umani nel tuo mondo. Deve essere difficile formare veri legami in mezzo a tanta oscurità..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:224
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_88381f45:

    # voice_abyss "Friendship? Love? Life partners? Words can be tricky. We confuse our fantasies with reality all the time."
    voice_abyss "Amicizia? Amore? Compagni di vita? Le parole possono essere complicate. Confondiamo continuamente le nostre fantasie con la realtà."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:225
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_ebd1c57d:

    # voice_abyss "But when bonds are authentic, even physical appearance becomes irrelevant. You just want to share experiences and enjoy life together."
    voice_abyss "Ma quando i legami sono autentici, anche l’aspetto fisico diventa irrilevante. Vuoi solo condividere esperienze e goderti la vita insieme."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:226
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d2402ca4:

    # voice_abyss "However..."
    voice_abyss "Tuttavia..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:231
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_bbfce83c:

    # voice_abyss "In this journey, you must choose." with dis_std
    voice_abyss "In questo viaggio devi scegliere." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:232
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_deeaca13:

    # voice_abyss "Tell me, which body do you find more attractive when interacting with other people?"
    voice_abyss "Dimmi, quale corpo trovi più attraente quando interagisci con altre persone?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:241
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_0db95f74:

    # voice_abyss "Hmmm, I see..." with dis_std
    voice_abyss "Hmmm, capisco..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:288
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d1e25c2b:

    # humanoid1 "Thank you for sharing your light with me, [mc.name!t]."
    humanoid1 "Grazie per aver condiviso la tua luce con me, [mc.name!t]."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:289
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_908019e9:

    # humanoid1 "You are a nice person."
    humanoid1 "Sei una brava persona."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:292
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a876584c:

    # humanoid1 "{act}looks at the candle{/act}" with dis_std_med
    humanoid1 "{act}guarda la candela{/act}" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:295
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_dd257387:

    # humanoid1 "It is not the first time that a light like this has guided someone."
    humanoid1 "Non è la prima volta che una luce come questa guida qualcuno."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:296
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7fb7e34c:

    # humanoid1 "In comparison with the immense darkness of the world, it may seem insignificant."
    humanoid1 "In confronto all’immensa oscurità del mondo, può sembrare insignificante."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:297
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_0c6ab56a:

    # humanoid1 "But it's the most precious thing we have..."
    humanoid1 "Ma è la cosa più preziosa che abbiamo..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:306
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_5af5742f:

    # humanoid1 "Keep moving forward, [mc.name!t]."
    humanoid1 "Continua ad andare avanti, [mc.name!t]."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:326
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e6beaa34:

    # voice_abyss "Keep walking." with dis_std
    voice_abyss "Continua a camminare." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:327
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_ddfac6a2:

    # voice_abyss "We'll talk again when you're near the end."
    voice_abyss "Ne riparleremo quando sarai vicino alla fine."

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:183
    old "My name is [mc.default_name!t]{#q: What's your name?}"
    new "Il mio nome è [mc.default_name!t]{#q: What's your name?}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:185
    old "My name is... (custom){#q: What's your name?}"
    new "Il mio nome è... (personalizzato){#q: What's your name?}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:186
    old "Write your name: (default is [mc.name!t])"
    new "Scrivi il tuo nome: (il valore predefinito è [mc.name!t])"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:196
    old "My surname is [mc.default_surname!t]{#q: And your surname?}"
    new "Il mio cognome è [mc.default_surname!t]{#q: And your surname?}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:198
    old "My surname is... (custom){#q: And your surname?}"
    new "Il mio cognome è... (personalizzato){#q: And your surname?}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:199
    old "Write your surname: (default is [mc.surname!t])"
    new "Scrivi il tuo cognome: (il valore predefinito è [mc.surname!t])"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:210
    old "Yes{#q: Is that your full name?}"
    new "Sì{#q: Is that your full name?}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:212
    old "No{#q: Is that your full name?}"
    new "No{#q: Is that your full name?}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:83
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_c325156d:

    # voice_abyss "Before you go, what's your name?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:117
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_27001343:

    # voice_abyss "Then, let's try again. What's your name?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:129
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_fd4a97b6:

    # voice_abyss "Are you interested{#female} in the pleasures of sex?"
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:131
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7cb98b27:

    # voice_abyss "Are you interested{#male} in the pleasures of sex?"
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:140
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a9f56658:

    # voice_abyss "Would you like to get pregnant{#female} in the end of your journey?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:142
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_e41552da:

    # voice_abyss "Would you like to see pregnancies in the end of your journey?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:153
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_7d97840b:

    # voice_abyss "How do you want to experience your adventure?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:162
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_197f831c:

    # voice_abyss "That was all." with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:164
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_d5e48fc6:

    # voice_abyss "It's a shame you're so impatient{#female}..."
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:166
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_90437c52:

    # voice_abyss "It's a shame you're so impatient{#male}..."
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:167
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_336fe5cb:

    # voice_abyss "But it doesn't matter, because you already know what's the most precious thing we have, right?"
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:258
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_240656b2:

    # voice_abyss "If that's the case, take this light with you, and let it guide you until the end."
    voice_abyss ""

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:273
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_83d7b502:

    # system "This game is a visual novel, so the story is told through dialogue, images and music."
    system "Questo gioco è un romanzo visivo, quindi la storia è raccontata attraverso dialoghi, immagini e musica."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:277
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_63213925:

    # system "The quick menu you opened in the lower left corner shows different icons."
    system "Il menu rapido che hai aperto nell'angolo in basso a sinistra mostra diverse icone."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:281
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_44f4d5e2:

    # system "When you tap on the bottom left icon, you can see the quick menu."
    system "Quando tocchi l'icona in basso a sinistra, puoi visualizzare il menu rapido."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:284
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_3a3d4dbc:

    # system "On the right, you can go back to the previous dialogue, skip dialogues, and enable auto-advance mode, in that order."
    system "A destra, puoi tornare al dialogo precedente, saltare i dialoghi e abilitare la modalità di avanzamento automatico, in questo ordine."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:285
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_272b8c2c:

    # system "On the left, you can hide the interface, open the game menu, and close the quick menu."
    system "A sinistra puoi nascondere l'interfaccia, aprire il menu di gioco e chiudere il menu rapido."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:287
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_071b15c2:

    # system "You can go back to the previous dialogue, skip dialogues, enable auto-advance mode, hide the interface, open the game menu, and close the quick menu, in that order."
    system "Puoi tornare al dialogo precedente, saltare i dialoghi, abilitare la modalità di avanzamento automatico, nascondere l'interfaccia, aprire il menu di gioco e chiudere il menu rapido, in quest'ordine."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:300
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_b0366c65:

    # system "Hiding the quick menu is as easy as tapping on the bottom left icon again."
    system "Nascondere il menu rapido è facile come toccare nuovamente l'icona in basso a sinistra."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:305
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_567e80ef:

    # system "Remember that you can save your progress anytime on the game menu!"
    system "Ricorda che puoi salvare i tuoi progressi in qualsiasi momento nel menu di gioco!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:308
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_524aa5e5:

    # system "Please, take a look at the Preferences screen. Before continuing, adjust the volume, the interface, and other settings to your liking."
    system "Per favore, dai un'occhiata alla schermata Preferenze. Prima di continuare, regola il volume, l'interfaccia e le altre impostazioni a tuo piacimento."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:309
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_b26ae127:

    # system "For the best experience, we suggest keeping the audio enabled. It makes the experience more immersive!"
    system "Per una migliore esperienza, suggeriamo di mantenere l'audio abilitato. Rende l'esperienza più coinvolgente!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:311
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_b016b335:

    # system "Don't forget that you can hide the entire interface at any time by tapping on the eye icon from the quick menu."
    system "Non dimenticare che puoi nascondere l'intera interfaccia in qualsiasi momento toccando l'icona a forma di occhio dal menu rapido."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:390
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_8d02d719_1:

    # voice_abyss "And your surname?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:403
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_b18dce25_1:

    # voice_abyss "“[mc.name!t] [mc.surname!t]”. Is that your full name?" with dis_std
    voice_abyss "" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:415
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s01_the_most_precious_thing_we_have_a0e433e5_1:

    # voice_abyss "Very well, [mc.name!t]..." with dis_std
    voice_abyss "" with dis_std

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:71
    old "Keep dreaming{#skip-prologue}"
    new "Continua a sognare{#skip-prologue}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:73
    old "Wake up (skip Prologue){#skip-prologue}"
    new "Sveglia (salta il prologo){#skip-prologue}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:134
    old "Yes{#prologue-enable-nsfw-content}"
    new "Sì{#prologue-enable-nsfw-content}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:149
    old "No (disable adult content){#prologue-enable-nsfw-content}"
    new "No (disabilita contenuti per adulti){#prologue-enable-nsfw-content}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:156
    old "Novel mode{#choose-game-mode}"
    new "Modalità romanzo{#choose-game-mode}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/script.rpy:158
    old "Game mode (adds actions and puzzles){#choose-game-mode}"
    new "Modalità gioco (aggiunge azioni ed enigmi){#choose-game-mode}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
