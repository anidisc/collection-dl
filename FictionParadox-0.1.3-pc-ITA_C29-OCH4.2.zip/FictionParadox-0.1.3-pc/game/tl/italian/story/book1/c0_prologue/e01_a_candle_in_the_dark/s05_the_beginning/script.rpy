﻿
translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:93
    old "Naventu presents{#initial-credits}"
    new "Naventu presenta{#initial-credits}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:97
    old "Direction & Writing{#initial-credits}"
    new "Regia e Scrittura{#initial-credits}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:97
    old "Dakno{#initial-credits}"
    new "Dakno{#initial-credits}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:105
    old "3D Art & Design{#initial-credits}"
    new "Arte e design 3D{#initial-credits}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:118
    old "Music{#initial-credits}"
    new "Musica{#initial-credits}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s05_the_beginning/script.rpy:130
    old "Programming{#initial-credits}"
    new "Programmazione{#initial-credits}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
