﻿
# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:55
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_fc649c4e:

    # humanoid2 "Thank you, beautiful{#female}."
    humanoid2 "Grazie, bella{#female}."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:57
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_98dec4fc:

    # humanoid2 "Thank you, handsome{#male}."
    humanoid2 "Grazie, bello{#male}."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:58
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_4bfdb7d2:

    # humanoid2 "Do you mind if we have a little chat in the pool?"
    humanoid2 "Ti dispiace se facciamo una piccola chiacchierata in piscina?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:61
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_bad064f0:

    # humanoid2 "Come on, don't be shy{#female}..." with dis_std_long
    humanoid2 "Dai, non essere timido{#female}..." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:63
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_d020e9fe:

    # humanoid2 "Come on, don't be shy{#male}..." with dis_std_long
    humanoid2 "Dai, non essere timido{#male}..." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:64
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_1561818f:

    # humanoid2 "Just dip your feet in. There's no need to get your clothes wet."
    humanoid2 "Basta immergere i piedi. Non è necessario bagnare i vestiti."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:72
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_32d1aaef:

    # humanoid2 "Sometimes it's important to take a little break..." with dis_std
    humanoid2 "A volte è importante prendersi una piccola pausa..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:77
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_167324cf:

    # humanoid2 "{act}gets into the pool{/act}" with dis_std_med
    humanoid2 "{act}entra in piscina{/act}" with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:80
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_4055cf22:

    # humanoid2 "{bt=5}Mmmmmmmmm...{/bt}" with dis_std_long
    humanoid2 "{bt=5}Mmmmmmmmm...{/bt}" with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:83
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_0e6aa6f8:

    # humanoid2 "{bt=5}What a nice warmth...{/bt}"
    humanoid2 "{bt=5}Che bel calore...{/bt}"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:93
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_5e75563f:

    # humanoid2 "Water caresses the skin like a patient lover... Its warmth invites us to lower the barriers, to be ourselves."
    humanoid2 "L'acqua accarezza la pelle come un'amante paziente... Il suo calore ci invita ad abbassare le barriere, ad essere noi stessi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:94
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_00e1d72e:

    # humanoid2 "It is a reminder of the pleasures that make our existence more than a simple transit. After all, we only live once, right?"
    humanoid2 "È un ricordo dei piaceri che rendono la nostra esistenza più di un semplice transito. Dopotutto, viviamo solo una volta, giusto?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:100
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_34841895:

    # humanoid2 "You humans have such a fascinating body..."
    humanoid2 "Voi umani avete un corpo così affascinante..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:101
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_4d2d4ec7:

    # humanoid2 "Even a rough imitation like me can perceive the vast array of sensations at your disposal."
    humanoid2 "Anche un'imitazione approssimativa come me può percepire la vasta gamma di sensazioni a tua disposizione."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:102
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_e285b686:

    # humanoid2 "In fact, there is one sensation that..."
    humanoid2 "In effetti, c'è una sensazione che..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:106
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_cf5ca8a0:

    # humanoid2 "MY GOD, how pleasurable it is! I can't even find the words to describe it!"
    humanoid2 "MIO DIO, quanto è piacevole! Non riesco nemmeno a trovare le parole per descriverlo!"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:109
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_f301ba0b:

    # humanoid2 "It's... as if the entire universe was coursing through you. Like you're tapping into something sacred, something buried deep inside." with dis_std_med
    humanoid2 "È... come se l'intero universo ti scorresse dentro. Come se stessi attingendo a qualcosa di sacro, qualcosa sepolto nel profondo." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:110
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_42debe98:

    # humanoid2 "You know what I mean, right?"
    humanoid2 "Sai cosa intendo, vero?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:114
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_73e138e0:

    # humanoid2 "{size=44}SEX!!!{/size}"
    humanoid2 "{size=44}SESSO!!!{/size}"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:117
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_cd4b9341:

    # humanoid2 "Although not everyone seeks it, nor needs it." with dis_std_med
    humanoid2 "Anche se non tutti lo cercano, né ne hanno bisogno." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:121
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_b7bf673e:

    # system "The following choice will enable or disable all the sexual and explicit content of the game, and will be permanent."
    system "La scelta successiva abiliterà o disabiliterà tutti i contenuti sessuali ed espliciti del gioco e sarà permanente."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:143
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_b581bb49:

    # humanoid2 "I know you want it..."
    humanoid2 "So che lo vuoi..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:145
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_b8b62719:

    # humanoid2 "I knew you would say that..."
    humanoid2 "Sapevo che avresti detto così..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:149
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_46f1149e:

    # humanoid2 "{act}comes out of water{/act}" with dis_std
    humanoid2 "{act}esce dall'acqua{/act}" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:152
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_8c9b8c29:

    # humanoid2 "With that innocent appearance, no one would suspect you." with dis_std_long
    humanoid2 "Con quell'aspetto innocente, nessuno sospetterebbe di te." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:153
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_9f60b2a8:

    # humanoid2 "But you can't fool me."
    humanoid2 "Ma non puoi ingannarmi."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:157
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_56782734:

    # humanoid2 "{act}lifting your shirt{/act} I can see what's behind this careless little body..." with scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence__lift_shirt_dissolve
    humanoid2 "{act}sollevando la maglietta{/act} Posso vedere cosa c'è dietro questo corpicino sbadato..." with scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence__lift_shirt_dissolve

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:158
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_1eff0f67:

    # humanoid2 "{act}sensual voice{/act} Did I catch you off guard?"
    humanoid2 "{act}voce sensuale{/act} Ti ho colto di sorpresa?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:159
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_18a5da05:

    # humanoid2 "You are invaded by dirty thoughts at the slightest stimulus."
    humanoid2 "Sei invaso da pensieri sporchi al minimo stimolo."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:163
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_7f78947b:

    # humanoid2 "{act}whispering{/act} What a bad girl..." with dis_std_long
    humanoid2 "{act}sussurra{/act} Che cattiva ragazza..." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:165
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_b1765083:

    # humanoid2 "{act}whispering{/act} What a bad boy..." with dis_std_long
    humanoid2 "{act}sussurra{/act} Che cattivo ragazzo..." with dis_std_long

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:166
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_75a022e9:

    # humanoid2 "{act}whispering{/act} I'm dying to know all the things you'll do in the future."
    humanoid2 "{act}sussurrare{/act} Non vedo l'ora di sapere tutte le cose che farai in futuro."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:176
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_cbe3506e:

    # humanoid2 "Really?" with dis_std
    humanoid2 "Veramente?" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:177
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_3eb91375:

    # humanoid2 "I didn't expect that answer."
    humanoid2 "Non mi aspettavo quella risposta."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:180
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_8ec5b02e:

    # humanoid2 "But it's fine, don't worry." with dis_std_med
    humanoid2 "Ma va bene, non preoccuparti." with dis_std_med

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:181
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_9191a242:

    # humanoid2 "You won't see anything explicit from now on."
    humanoid2 "D'ora in poi non vedrai nulla di esplicito."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:184
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_42d54d65:

    # humanoid2 "{think}What a pity...{/think}"
    humanoid2 "{think}Che peccato...{/think}"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:188
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_46f1149e_1:

    # humanoid2 "{act}comes out of water{/act}" with dis_std
    humanoid2 "{act}esce dall'acqua{/act}" with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:192
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_156ff4c4:

    # humanoid2 "I think I know what you're looking for..." with dis_std
    humanoid2 "Penso di sapere cosa stai cercando..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:194
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_d785ec4e:

    # humanoid2 "You want an accomplice{#female} to confront the world. Or perhaps more than one{#female}? Who knows..."
    humanoid2 "Hai bisogno di un complice{#female} per affrontare il mondo. O forse più di uno{#female}? Chi lo sa..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:195
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_181e5cdc:

    # humanoid2 "I'm pretty sure{#female} you'll make an unconventional use of that light."
    humanoid2 "Sono abbastanza sicuro{#female} che farai un uso non convenzionale di quella luce."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:197
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_a83f5313:

    # humanoid2 "You want an accomplice{#male} to confront the world. Or perhaps more than one{#male}? Who knows..."
    humanoid2 "Hai bisogno di un complice{#male} per affrontare il mondo. O forse più di uno{#male}? Chi lo sa..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:198
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_256d0349:

    # humanoid2 "I'm pretty sure{#male} you'll make an unconventional use of that light."
    humanoid2 "Sono abbastanza sicuro{#male} che farai un uso non convenzionale di quella luce."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:200
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_55a670c6:

    # humanoid2 "In fact, I have one last question for you..."
    humanoid2 "In effetti, ho un'ultima domanda per te..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:201
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_842f5ae7:

    # humanoid2 "What are you going to do if you have sex without protection?"
    humanoid2 "Cosa farai se fai sesso senza protezione?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:202
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_014726aa:

    # humanoid2 "In other words..."
    humanoid2 "In altre parole..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:204
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_9264cfa9:

    # humanoid2 "Would you like to get pregnant{#female} in the future?"
    humanoid2 "Ti piacerebbe rimanere incinta{#female} in futuro?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:206
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_27ddaae7:

    # humanoid2 "Would you like to see pregnancies in the future?"
    humanoid2 "Ti piacerebbe vedere gravidanze in futuro?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:208
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_cd67fd33:

    # system "This choice only has implications for the endgame."
    system "Questa scelta ha implicazioni solo per il finale."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:217
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_182ec6f0:

    # humanoid2 "Hmm, I see..."
    humanoid2 "Hmm, capisco..."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:219
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_5fe81d67:

    # humanoid2 "I see..." with dis_std
    humanoid2 "vedo..." with dis_std

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:220
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_27d279bc:

    # humanoid2 "Goodbye, [mc.name!t]."
    humanoid2 "Arrivederci, [mc.name!t]."

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:221
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_9ba21be6:

    # humanoid2 "It was a pleasure to meet you."
    humanoid2 "È stato un piacere conoscerti"

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:126
    old "I want to see sexual and explicit scenes in my adventure{#mc-config}"
    new "Voglio vedere scene sessuali ed esplicite nella mia avventura{#mc-config}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:130
    old "I'm not interested{#female} in explicit content{#mc-config}"
    new "Non sono interessato{#female} ai contenuti espliciti{#mc-config}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:133
    old "I'm not interested{#male} in explicit content{#mc-config}"
    new "Non sono interessato{#male} ai contenuti espliciti{#mc-config}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:212
    old "Yes, I want to have children"
    new "Sì, voglio avere figli"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:214
    old "No, I don't want to have children"
    new "No, non voglio avere figli"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:198
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_7266efd4:

    # humanoid2 "Would you like to get pregnant{#female} in the end of your journey?"
    humanoid2 "Ti piacerebbe rimanere incinta{#female} alla fine del tuo viaggio?"

# game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:200
translate italian scene__book1__c0_prologue__e01_a_candle_in_the_dark__s02_pleasures_of_existence_68481fbf:

    # humanoid2 "Would you like to see pregnancies in the end of your journey?"
    humanoid2 "Ti piacerebbe vedere delle gravidanze alla fine del tuo viaggio?"

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:122
    old "I like sex{#mc-config}"
    new "Mi piace il sesso{#mc-config}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:126
    old "I'm not interested{#female} (disable adult content){#mc-config}"
    new "Non sono interessato{#female} (disabilita contenuti per adulti){#mc-config}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s02_pleasures_of_existence/script.rpy:129
    old "I'm not interested{#male} (disable adult content){#mc-config}"
    new "Non sono interessato{#male} (disabilita contenuti per adulti){#mc-config}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
