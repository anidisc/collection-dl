﻿
translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/event.rpy:4
    old "A Candle in the Dark{#story-event}"
    new "Una candela nell'oscurità{#story-event}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
