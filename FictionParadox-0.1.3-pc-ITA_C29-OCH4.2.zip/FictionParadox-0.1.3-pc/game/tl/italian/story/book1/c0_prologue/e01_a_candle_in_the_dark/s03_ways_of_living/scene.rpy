﻿
translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/scene.rpy:6
    old "Ways of Living{#story-scene}"
    new "Modi di vivere{#story-scene}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
