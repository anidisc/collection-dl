﻿
translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:25
    old "CLICK ON\nYOUR BODY{#screen}"
    new "CLICCA SU\nIL TUO CORPO{#screen}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:54
    old "CLICK ON THE\nBODY YOU LIKE{#screen}"
    new "CLICCA SUL\nBODY CHE TI PIACE{#screen}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:63
    old "COMING SOON{#screen}"
    new "PROSSIMAMENTE{#screen}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.

translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:114
    old "Tap the screen to continue{#screen-continue-hint}"
    new "Tocca lo schermo per continuare{#screen-continue-hint}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:118
    old "Click or press Space to continue{#screen-continue-hint}"
    new "Fare clic o premere la barra spaziatrice per continuare{#screen-continue-hint}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:148
    old "TAP ON\nYOUR BODY{#screen}"
    new "TOCCA\nIL TUO CORPO{#screen}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:180
    old "TAP ON\nTHE BODY\nYOU LIKE{#screen}"
    new "TOCCA\nIL CORPO\nTI PIACE{#screen}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:189
    old "MEN{#screen}"
    new "UOMINI{#screen}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s01_the_most_precious_thing_we_have/screens.rpy:197
    old "BISEXUAL ROUTE{#screen}"
    new "ITINERARIO BISESSUALE{#screen}"

#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
