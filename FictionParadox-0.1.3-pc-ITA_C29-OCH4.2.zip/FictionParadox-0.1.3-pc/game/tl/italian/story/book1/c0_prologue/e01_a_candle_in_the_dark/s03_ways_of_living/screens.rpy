﻿
translate italian strings:

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/screens.rpy:32
    old "NOVEL MODE{#prologue}"
    new "MODALITÀ ROMANZO{#prologue}"

    # game/story/book1/c0_prologue/e01_a_candle_in_the_dark/s03_ways_of_living/screens.rpy:41
    old "GAME MODE{#prologue}"
    new "MODALITÀ GIOCO{#prologue}"

#Used Programme Bad75 Renpy Translate 2.3 Ultimate
#OneClick Version 2.3 Ultimate 2025
#Translator CEP_29.
#Used Programme BAD75 OneClick HERMES 4.2
#OneClick HERMES 4.2 2026
#Translator CEP_29.
