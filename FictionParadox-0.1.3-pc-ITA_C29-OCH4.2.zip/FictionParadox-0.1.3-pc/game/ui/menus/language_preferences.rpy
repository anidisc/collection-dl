

## Screen ######################################################################

screen language_preferences_content():
    modal True

    vbox:
        spacing 20
        vbox:
            style_prefix "radio"
            label _("Language{#preferences-screen}")

            for lang_code, lang_name in {
                None: "🇬🇧 English",
                "es": "🇪🇸 Español",
                "italian": "🇮🇹 {bt=4}{color=#00ff00}Ital{/color}iano{color=#f00}_IFT{/color}{/bt}",
                "fr": "🇫🇷 Français",
                "zh": "🇨🇳 {font=fonts/CangErYuYangTi-W03.ttf}中文{/font}",
            }.items():
                textbutton lang_name:
                    action Language(lang_code)

        if _preferences.language is not None:
            vbox:
                style_prefix "radio"
                label _("Game title{#preferences-screen}")
                textbutton "Fiction Paradox- ITA_Cep29 OneClick 4.2 HERMES":
                    action SetField(persistent, "use_translated_title", False)
                textbutton _("Fiction Paradox- ITA_Cep29 OneClick 4.2 HERMES{#game-title}"):
                    action SetField(persistent, "use_translated_title", True)

screen language_preferences():
    tag game_menu
    modal True

    use preferences_menu("language_preferences"):
        frame:
            top_padding 10
            right_padding 40
            bottom_padding 40
            left_padding 40
            use language_preferences_content
