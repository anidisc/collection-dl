
define gui.initial_warning_text = _p("""
All the characters in the story are fictional and over the age of 18. Any resemblance to real life people or events is entirely coincidental.\n
This game contains explicit depictions of nudity, sex, violence and sensitive topics. By selecting CONTINUE, you certify that you meet the legal age of your jurisdiction to consume this kind of material.\n
""")

## Styles ######################################################################

style titlechoice:
    xminimum 760
    xmaximum 760
    yminimum 400
    ymaximum 400
    activate_sound audio.ui_initial_warning_close

style titlechoice_text:
    font gui.global_font_title
    align (0.5, 0.07)
    size 40
    idle_color gui.button_text_idle_color
    color gui.button_text_insensitive_color
    hover_color gui.button_text_hover_color
    selected_hover_color gui.button_text_selected_color
    selected_idle_color gui.button_text_selected_color

style langchoice_button:
    xmaximum 500
    xminimum 500
    ymaximum 60
    yminimum 60

style langchoice_button_text:
    font gui.global_font_title
    size 40
    align (0.5, 0.5)

style langchoice_button_text:
    variant "small"
    font gui.global_font_title
    size 50
    align (0.5, 0.5)

style initialwarn_button:
    xmaximum 500
    xminimum 500
    ymaximum 60
    yminimum 60

style initialwarn_button_text:
    font gui.global_font_title
    size 40
    align (0.5, 0.5)

style initialwarn_button_text:
    variant "small"
    font gui.global_font_title
    size 50
    align (0.5, 0.5)


## Screen ######################################################################

transform initial_warning_animation:
    on show:
        alpha 0.0
        linear 0.2 alpha 1.0
    on hide:
        alpha 1.0
        linear 0.1 alpha 0.3
        linear 0.1 alpha 1.0
        linear 0.1 alpha 0.3
        linear 0.1 alpha 1.0
        linear 0.5 alpha 0.0

screen splashscreen_translated_title_choice():
    modal True

    on "show" action Function(sfx.play, audio.ui_initial_warning_open)

    frame:
        area (0, 0, 1920, 1080)
        at initial_warning_animation

        add "ui/menus/images/fp_logo_title_screen_english.png" xpos 130 ypos 507
        add "ui/menus/images/fp_logo_title_screen_translated.png" xpos 1090 ypos 507

        vbox:
            area(0, 250, 1920, 150)
            text _("Which title do you prefer for the game?{#splashscreen}"):
                size 60
                xalign 0.5
            text _("(you can change it in Preferences){#splashscreen}"):
                xalign 0.5
                if renpy.variant("small"):
                    size 40
                else:
                    size 30

        hbox:
            area(100, 400, 760, 400)
            textbutton _("ORIGINAL{#splashscreen-title-logo}"):
                style "titlechoice"
                action [
                    Function(main_ui.splashscreen.choose_original_title),
                    Return(),
                ]

        hbox:
            area(1060, 400, 760, 400)
            textbutton _("TRANSLATED{#splashscreen-title-logo}"):
                style "titlechoice"
                activate_sound audio.ui_initial_warning_close
                action [
                    Function(main_ui.splashscreen.choose_translated_title),
                    Return(),
                ]

screen splashscreen_language_choice():
    modal True

    on "show" action Function(sfx.play, audio.ui_initial_warning_open)

    frame:
        area (0, 0, 1920, 1080)
        at initial_warning_animation
        vbox:
            align (0.5, 0.5)

            vbox:
                style_prefix "langchoice"
                spacing 30

                for lang_code, lang_name in {
                    None: "🇬🇧 ENGLISH",
                    "es": "🇪🇸 ESPAÑOL",
                    "italian": "🇮🇹 {bt=4}{color=#00ff00}Ital{/color}iano{color=#f00}_IFT{/color}{/bt}",
                    "fr": "🇫🇷 FRANÇAIS",
                    "zh": "🇨🇳 {font=fonts/CangErYuYangTi-W03.ttf}{size=*1.1}中文{/size}{/font}",
                }.items():
                    textbutton lang_name:
                        activate_sound audio.ui_initial_warning_close
                        action [
                            Function(main_ui.splashscreen.choose_language, lang_code),
                            Return(),
                        ]

init python in splashscreen_context:
    stop_seeing_initial_warning = False

screen splashscreen_warning():
    modal True

    on "show" action Function(sfx.play, audio.ui_initial_warning_open)

    frame:
        area (0, 0, 1920, 1080)
        at initial_warning_animation
        vbox:
            align (0.5, 0.5)
            vbox:
                if renpy.variant("small"):
                    xmaximum 1700
                    xminimum 1700
                else:
                    xmaximum 1000
                    xminimum 1000
                xalign 0.5
                text gui.initial_warning_text

            hbox:
                style_prefix "initialwarn"
                spacing 10
                xalign 0.5

                textbutton _("CONTINUE{#splashscreen}"):
                    activate_sound audio.ui_initial_warning_close
                    action Return()
                textbutton _("EXIT GAME{#splashscreen}"):
                    action Quit(confirm=False)

            null height 40

            vbox:
                style_prefix "check"
                xalign 0.5
                if renpy.variant("small"):
                    xsize 1200
                else:
                    xsize 800
                textbutton _("Don't show this screen again.{#splashscreen}"):
                    xalign 0.5
                    text_xalign 0.5
                    action ToggleField(
                        splashscreen_context,
                        "stop_seeing_initial_warning",
                    )

label splashscreen:
    # We ensure Naventu's logo will be shown during game start.
    $ persistent.show_naventu_logo = True

    scene bg_black

    if persistent.show_initial_language_choice:
        call screen splashscreen_language_choice
        pause 1.1
        if _preferences.language is not None:
            call screen splashscreen_translated_title_choice
            pause 1.1
        $ persistent.show_initial_language_choice = False

    if persistent.show_initial_warning:
        call screen splashscreen_warning
        if splashscreen_context.stop_seeing_initial_warning:
            $ persistent.show_initial_warning = False
        pause 0.8
